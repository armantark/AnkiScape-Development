#!/usr/bin/env python3
"""Driver-only MacBook canary; inject SSH 255 after a real local shell launch."""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import importlib.util
import json
import shlex
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

EXPECTED_RUNNER_SHA256 = "5de9414af35bb4688810d7d3f9b3331b205988b74a30706de6eca07af2de5e42"


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: process-canary.py /absolute/path/to/tools/run_remote_tests.py")
    runner_path = Path(sys.argv[1]).resolve(strict=True)
    assert hashlib.sha256(runner_path.read_bytes()).hexdigest() == EXPECTED_RUNNER_SHA256
    spec = importlib.util.spec_from_file_location("canary_remote_runner", runner_path)
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    real_run = subprocess.run

    with tempfile.TemporaryDirectory(prefix="ankiscape-single-launch-canary-") as temporary:
        root = Path(temporary)
        source, remote = root / "source", root / "remote"
        mirror, venv = remote / "ankiscape_fork", remote / "venv"
        source.mkdir()
        venv.mkdir(parents=True)
        (source / "canary.txt").write_text("before\n")
        lock_path = root / "mirror.lock"
        started_path, release_path = root / "starts.jsonl", root / "release"
        worker_path = root / "worker.py"
        worker_path.write_text(
            "import json, os, signal, sys, time\n"
            "from pathlib import Path\n"
            "signal.alarm(8)\n"
            "starts, release = map(Path, sys.argv[1:])\n"
            "with starts.open('a') as stream:\n"
            "    stream.write(json.dumps({'pid': os.getpid()}) + '\\n')\n"
            "    stream.flush()\n"
            "while not release.exists(): time.sleep(0.01)\n"
            "print('bounded canary worker completed', flush=True)\n"
        )
        lane_command = shlex.join((sys.executable, str(worker_path), str(started_path), str(release_path)))
        launches, syncs, mutations = [], [], []

        def local_transport(command, **kwargs):
            if tuple(command[:len(runner.SSH)]) == runner.SSH:
                remote_command = command[-1]
                if not remote_command.startswith("cat "):
                    mutations.append(remote_command)
                completed = real_run(("/bin/sh", "-c", remote_command), timeout=10, **kwargs)
                if remote_command.startswith("nohup "):
                    launches.append(remote_command)
                    assert completed.returncode == 0, completed
                    # The shell has actually launched. This is deliberate fault injection.
                    return subprocess.CompletedProcess(command, 255, completed.stdout, "INJECTED disconnect after local detached launch")
                return completed
            if command[0] == "rsync":
                destination = f"{runner.HOST}:{mirror}/"
                assert command[-1] == destination, command
                syncs.append(tuple(command))
                return real_run((*command[:-1], f"{mirror}/"), timeout=10, **kwargs)
            raise AssertionError(f"unexpected transport command: {command!r}")

        with contextlib.ExitStack() as patches:
            for name, value in (
                ("REMOTE_ROOT", remote), ("REMOTE_REPO", mirror), ("REMOTE_VENV", venv),
                ("LOCAL_MIRROR_LOCK_PATH", lock_path),
            ):
                patches.enter_context(patch.object(runner, name, value))
            patches.enter_context(patch.object(runner, "_remote_lane_command", return_value=lane_command))
            patches.enter_context(patch.object(runner.subprocess, "run", side_effect=local_transport))
            with lock_path.open("a+") as lock:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
                pending = None
                try:
                    runner._sync(source)
                    try:
                        runner._stream_remote_run("plain", timeout=0.05, poll_interval=0.01)
                    except TimeoutError:
                        pass
                    else:
                        raise AssertionError("worker must remain pending until explicitly released")
                    pending_path = runner._pending_path()
                    original_record = pending_path.read_bytes()
                    pending = json.loads(original_record)
                    assert Path(pending["log_path"]).parent == remote / "reports"
                    assert Path(pending["report_path"]).parent == remote / "reports"
                    assert pending["run_id"] in launches[0]
                    deadline = time.monotonic() + 3
                    while not started_path.exists() and time.monotonic() < deadline:
                        time.sleep(0.01)
                    starts = started_path.read_text().splitlines()
                    assert len(starts) == 1, starts
                    assert len(launches) == 1, launches
                    assert len(syncs) == 1, syncs
                    (source / "canary.txt").write_text("after\n")
                    before_mutations = list(mutations)
                    try:
                        runner._sync(source)
                    except RuntimeError as error:
                        assert "sync blocked" in str(error), error
                    else:
                        raise AssertionError("unresolved run permitted sync")
                    assert pending_path.read_bytes() == original_record
                    assert (mirror / "canary.txt").read_text() == "before\n"
                    assert mutations == before_mutations
                    assert len(syncs) == 1
                    release_path.touch()
                    deadline = time.monotonic() + 5
                    code = None
                    while code is None and time.monotonic() < deadline:
                        code = runner._completion_report(pending["report_path"])
                        if code is None:
                            time.sleep(0.01)
                    assert code == 0, code
                    runner._sync(source)
                    assert not pending_path.exists()
                    assert (mirror / "canary.txt").read_text() == "after\n"
                    assert len(syncs) == 2
                    assert len(launches) == 1
                    assert started_path.read_text().splitlines() == starts
                    assert Path(pending["report_path"]).read_text().strip() == "0"
                    assert "bounded canary worker completed" in Path(pending["log_path"]).read_text()
                    print(json.dumps({
                        "status": "PASS", "runner_sha256": EXPECTED_RUNNER_SHA256,
                        "fault": "INJECTED exit 255 after actual local detached shell launch; no network SSH",
                        "run_id": pending["run_id"], "starts": 1, "syncs": 2,
                        "blocked_copy_while_pending": True, "same_run_report_exit": code,
                        "worker_alarm_seconds": 8,
                    }, sort_keys=True))
                finally:
                    # Release the bounded worker even when an assertion fails before completion.
                    release_path.touch()
                    if pending is None and runner._pending_path().exists():
                        pending = json.loads(runner._pending_path().read_text())
                    if pending is not None:
                        report_path = Path(pending["report_path"])
                        deadline = time.monotonic() + 10
                        while not report_path.exists() and time.monotonic() < deadline:
                            time.sleep(0.01)
                    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


if __name__ == "__main__":
    main()
