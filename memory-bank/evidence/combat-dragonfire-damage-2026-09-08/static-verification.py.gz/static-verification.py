from pathlib import Path
import ast
import gzip
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
from unittest.mock import patch

if sys.flags.optimize or 'PYTHONOPTIMIZE' in os.environ:
    raise SystemExit('Static verification requires assertions enabled.')
root = Path.cwd()
ev = root / 'memory-bank/evidence/combat-dragonfire-damage-2026-09-08'
pins = json.loads((ev / 'static-instrument-pins.json').read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
attempts = []


def audit(event, values):
    if event == 'import' and values[0].split('.')[0] in {'ankiscape', 'pkg_alias', 'tests'}:
        attempts.append(values[0])
        raise RuntimeError('Product import forbidden in static verification.')


sys.addaudithook(audit)
gate_path = Path(pins['gate']['path'])
assert sha(gate_path.read_bytes()) == pins['gate']['sha256']
for row in pins['tools'].values():
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
spec = importlib.util.spec_from_file_location('_static_slop_gate', gate_path)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
assert {key: getattr(gate, key) for key in pins['gate']['thresholds']} == pins['gate']['thresholds']
files = list(pins['candidate_sources'])
product_files = [
    'logic_pure/logic_pure_combat_engine.py',
    'logic_pure/logic_pure_combat_specials.py',
]
inventory_path = ev / 'source-inventory.json.gz'
assert sha(inventory_path.read_bytes()) == pins['inventory_sha256']
inventory = json.loads(gzip.decompress(inventory_path.read_bytes()))
sources_before = {name: sha((root / name).read_bytes()) for name in inventory}
assert sources_before == inventory, 'Source inventory differs before static verification.'
candidates_before = {name: sha((root / name).read_bytes()) for name in files}
assert candidates_before == pins['candidate_sources']
assert sha((ev / 'manifest.json').read_bytes()) == pins['manifest_sha256']
raw = []
run_tool = gate.run_tool


def capture(argv, tool):
    result = run_tool(argv, tool)
    row = {
        'argv': argv,
        'tool': tool,
        'exit_code': result.returncode,
        'stdout': result.stdout,
        'stderr': result.stderr,
    }
    if tool == 'complexipy':
        directory = Path(argv[argv.index('--output') + 1])
        row['reports'] = {path.name: path.read_text() for path in directory.glob('*.json')}
    raw.append(row)
    return result


with tempfile.TemporaryDirectory(prefix='dragonfire-damage-static-') as directory:
    scratch = Path(directory)
    base, candidate = scratch / 'base', scratch / 'candidate'
    base.mkdir()
    candidate.mkdir()
    baselines = {
        product_files[0]: gzip.decompress((ev / 'baseline-engine.py.gz').read_bytes()),
        product_files[1]: gzip.decompress((ev / 'baseline-specials.py.gz').read_bytes()),
    }
    for name, value in baselines.items():
        path = base / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
    for name in files:
        path = candidate / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((root / name).read_bytes())
    ast_files = {}
    for tree in (base, candidate):
        for path in tree.rglob('*.py'):
            ast.parse(path.read_bytes(), filename=str(path))
            ast_files[str(path.relative_to(scratch))] = sha(path.read_bytes())
    assert {name: sha(value) for name, value in baselines.items()} == pins['baseline_sources']
    for name, snapshot in [
        (product_files[0], 'candidate-engine.py.gz'),
        (product_files[1], 'candidate-specials.py.gz'),
    ]:
        snapshot_bytes = (ev / snapshot).read_bytes()
        assert sha(snapshot_bytes) == pins['snapshots'][snapshot]
        assert gzip.decompress(snapshot_bytes) == (candidate / name).read_bytes()
    patch_bytes = (ev / 'product.diff').read_bytes()
    assert sha(patch_bytes) == pins['patch_sha256']
    restore = scratch / 'restore'
    for name, value in baselines.items():
        path = restore / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
    patch_path = scratch / 'product.diff'
    patch_path.write_bytes(patch_bytes)
    restoration = {}
    for label, flags, expected in [
        ('forward', [], pins['candidate_sources']),
        ('reverse', ['-R'], pins['baseline_sources']),
    ]:
        command = ['patch', *flags, '-p1', '--batch', '-i', str(patch_path)]
        process = subprocess.run(command, cwd=restore, capture_output=True, text=True)
        row = {
            'tool': 'patch',
            'direction': label,
            'argv': command,
            'exit_code': process.returncode,
            'stdout': process.stdout,
            'stderr': process.stderr,
        }
        raw.append(row)
        (ev / 'static-raw.json.gz').write_bytes(
            gzip.compress(json.dumps(raw, indent=2).encode(), mtime=0)
        )
        assert process.returncode == 0, row
        observed = {name: sha((restore / name).read_bytes()) for name in product_files}
        restoration[label] = {'observed': observed, 'expected': {name: expected[name] for name in product_files}}
        assert observed == restoration[label]['expected']
    metrics = {}
    with patch.object(gate, 'run_tool', side_effect=capture):
        for label, tree in [('base', base), ('candidate', candidate)]:
            metrics[label] = {
                name: function(tree)
                for name, function in [
                    ('ccn', gate.ccn_by_function),
                    ('cognitive', gate.cognitive_by_function),
                    ('halstead', gate.halstead_by_function),
                    ('layout', gate.pep8_layout_findings),
                ]
            }
    failures = {
        name: gate.ratchet(metrics['candidate'][name], metrics['base'][name], limit)
        for name, limit in [
            ('ccn', gate.CCN_MAX),
            ('cognitive', gate.COGNITIVE_MAX),
            ('halstead', gate.HALSTEAD_MAX),
        ]
    }
    failures['layout'] = gate.layout_ratchet(metrics['candidate']['layout'], metrics['base']['layout'])
    base_lines = gate.line_counts(base, files)
    candidate_lines = gate.line_counts(candidate, files)
    failures['file_growth'] = [
        (name, count)
        for name, count in candidate_lines.items()
        if count > gate.FILE_LINES_MAX and count > base_lines.get(name, 0)
    ]
    sources_after = {name: sha((root / name).read_bytes()) for name in inventory}
    candidates_after = {name: sha((root / name).read_bytes()) for name in files}
    assert sources_after == inventory, 'Source inventory differs after static verification.'
    assert candidates_after == pins['candidate_sources']
    modules = sorted(
        name for name in sys.modules
        if name.split('.')[0] in {'ankiscape', 'pkg_alias', 'tests'}
    )
    assert not modules, modules
    result = {
        'ast_files': ast_files,
        'restoration': restoration,
        'sources_before': sources_before,
        'sources_after': sources_after,
        'candidate_sources_before': candidates_before,
        'candidate_sources_after': candidates_after,
        'product_modules': modules,
        'status': 'PASS' if not any(failures.values()) else 'FAIL',
        'metrics': {
            label: {
                kind: {'|'.join(key): value for key, value in values.items()}
                for kind, values in table.items()
            }
            for label, table in metrics.items()
        },
        'lines': {'base': base_lines, 'candidate': candidate_lines},
        'failures': failures,
        'gate_sha256': pins['gate']['sha256'],
        'thresholds': pins['gate']['thresholds'],
        'product_import_attempts': attempts,
        'python': sys.executable,
        'python_version': sys.version,
    }
    (ev / 'static-metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    (ev / 'static-raw.json.gz').write_bytes(
        gzip.compress(json.dumps(raw, indent=2).encode(), mtime=0)
    )
    assert not any(failures.values()), failures
    assert not attempts
    print(json.dumps({
        'status': result['status'],
        'failures': failures,
        'sources': candidates_after,
        'lines': result['lines'],
    }, indent=2))
