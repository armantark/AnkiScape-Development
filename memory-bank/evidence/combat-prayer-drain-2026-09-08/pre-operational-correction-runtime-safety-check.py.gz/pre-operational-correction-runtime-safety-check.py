"""Exercise prayer-drain runtime safety stops without product imports or remote calls."""

import argparse
from contextlib import TemporaryDirectory
import gzip
import json
from pathlib import Path
import sys
import types


def load_harness(path):
    namespace = {"__name__": "prayer_drain_runtime_harness_under_test"}
    raw = gzip.decompress(path.read_bytes())
    exec(compile(raw, "runtime-harness.py", "exec"), namespace)
    return types.SimpleNamespace(**namespace)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--harness", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    before = sorted(
        name
        for name in sys.modules
        if name == "pkg_alias" or name.split(".")[0] in {"ankiscape", "tests"}
    )
    harness = load_harness(args.harness)
    results = []
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        pending = root / "pending.json"
        pending.write_text(json.dumps({"run_id": "existing", "log_path": "log", "report_path": "report"}))

        class ExistingPending:
            def _pending_path(self):
                return pending

        try:
            harness.assert_no_pending(ExistingPending())
        except RuntimeError as error:
            results.append({"case": "existing-pending", "stopped": True, "error": str(error)})
        else:
            raise AssertionError("existing pending work did not stop the run")

        mismatched = root / "mismatched"
        (mismatched / harness.EVIDENCE).mkdir(parents=True)
        (mismatched / harness.INVENTORY).write_bytes(b"not-the-pinned-inventory")
        try:
            harness.local_sources(mismatched)
        except ValueError as error:
            results.append({"case": "inventory-mismatch", "stopped": True, "error": str(error)})
        else:
            raise AssertionError("inventory mismatch did not stop before remote setup")

        launch_output = root / "launch"
        launch_output.mkdir()
        launch_pending = root / "launch-pending.json"
        expected = {
            "run_id": "plain-stub-proof",
            "log_path": "/stub/log",
            "report_path": "/stub/report",
        }
        stub = types.SimpleNamespace()
        stub._pending_path = lambda: launch_pending
        stub._remote_lane_command = lambda lane: "unpatched"
        launch_seen = {"value": False}

        def original_ssh(text, *, label, repeat_safe=False):
            identity = json.loads((launch_output / "identity.json").read_text())
            if identity != {"lane": "plain", "kind": "focused", "pending": expected}:
                raise AssertionError("identity was not durable before the launch call")
            launch_seen["value"] = True
            return ""

        def stream(lane, *, timeout, poll_interval):
            launch_pending.write_text(json.dumps(expected))
            stub._ssh("stub launch", label="remote lane launch")
            return 0, "stub log"

        stub._ssh = original_ssh
        stub._stream_remote_run = stream
        invocation = types.SimpleNamespace(
            output=launch_output,
            lane="plain",
            kind="focused",
            timeout=1,
        )
        code, log = harness.launch_one(invocation, stub, "stub command")
        if (code, log, launch_seen["value"]) != (0, "stub log", True):
            raise AssertionError("stub launch did not complete as expected")
        results.append(
            {
                "case": "identity-before-launch",
                "stopped": False,
                "identity_durable_before_launch": True,
                "remote_calls": 0,
            }
        )
    after = sorted(
        name
        for name in sys.modules
        if name == "pkg_alias" or name.split(".")[0] in {"ankiscape", "tests"}
    )
    if after != before:
        raise AssertionError(f"product import set changed: {before} -> {after}")
    report = {
        "status": "PASS",
        "inert": True,
        "remote_calls": 0,
        "product_imports_before": before,
        "product_imports_after": after,
        "cases": results,
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
