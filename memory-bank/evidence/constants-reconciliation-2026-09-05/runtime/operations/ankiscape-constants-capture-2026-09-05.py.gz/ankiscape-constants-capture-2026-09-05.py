#!/usr/bin/env python3
"""Capture the frozen constants split after the parent prepares the MacBook mirror."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import sys

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
BASELINE = ROOT.parent / 'reports/cut-gem-baseline-6438d422'
DISCOVERY_BASELINE = ROOT.parent / 'reports/ghosts-prerequisite-baseline-ygs2eavk'
EXPECTED = {'core/constants.py': '9447fe97f3256121f654c3708b59cea50574e142ed924d5108d7ceb54c2810eb',
 'core/constants_parts/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
 'core/constants_parts/activity_assets.py': '2810226e148b356f903069e8af933689f7c1929f22f8268449797d50cba2ad98',
 'core/constants_parts/activity_updates.py': '3c007e355daddf0d4486c498c43bbc07b0cd294c2abd8de839b1d5a4c1f36629',
 'core/constants_parts/combat_minigame_sources.py': 'd9375acc342d5c74d59d675cac3ea2ba0f95b91a1a7e5fbea5ed651624422751',
 'core/constants_parts/competitive_minigame_sources.py': '0e799da9ddc013ec1069a13f5b8d5ee20b2c4713be1fc12dd70c5b031f31841f',
 'core/constants_parts/distraction_sources.py': '739970ee6b6130b7271a5ad19211060082254b3b0dcfb7b2d5d5dc30701e21aa',
 'core/constants_parts/equipment_sources.py': '15bfbcf97a686a21d38f5757afd021770255a4e9213942d1612acf030b84471b',
 'core/constants_parts/landmark_and_boss_sources.py': 'e371ad624c14f750600bee48bd126c86d064ad5a4057ea2e45d8509a539b8bfe',
 'core/constants_parts/paths.py': '663e416d4a0b4f2583a08be3d96454ceb714bfb517919d4589b0cf62c84bd647',
 'core/constants_parts/public_exports.py': '42d2f9f3987bc39833ccd9ecac4598bbeeb356898db324d755fb2d98ed8049a9',
 'core/constants_parts/quest_items.py': 'c461a9d119db2008f151e43b389ae3a66eb903bfc3f21ad3a0051ea4e2afe68f',
 'core/constants_parts/registry_sources.py': '3d0eed80d9770ccb65030f26a5666df946ce7f1b0a7e76c076b71999a95fd7a2',
 'core/constants_parts/skill_assets.py': '30b533eeed70ebca4e8940711cc97b44f0e1f388a975f4edcf40a5d392e3a74f',
 'core/constants_parts/skill_catalog.py': '084fe08384faef54d30f469da3f317a970244e23a57b63502801fdf0b61232b8',
 'core/constants_parts/skill_minigame_sources.py': 'd12c67191ee909066249fb0dbbde83880f3b1b4e75eb090382f731a7136d5c88',
 'core/constants_parts/skill_sources.py': '0486b918d292ff9b6c71e9b6457f5fece6176af74c9445743e85cb378f9102d6',
 'core/constants_parts/utility_sources.py': 'cd321cea899da6ece635ff9cabaa0756206bf227d0b415ebd9614403c2cb8930',
 'tests/test_module_surface.py': '8cb6d028d1623c72367f34b61194993221270283bd79e0aaf020198f078d4fec',
 'tools/module_surface.py': 'a66948b912691279dc951ac9e5aa0c144b75a351c9b1bb46b88f67d85ebcf1e5',
 'run_tests.py': '4ce89f5dd8c70693977140fbc42bef571cdcada3d97e61671d0e873f0653bb33'}
MODULES = ['core/constants.py',
 'data/quest_data.py',
 'data/combat_data.py',
 'data/slayer_data.py',
 'logic_pure/logic_pure_combat_engine.py',
 'tests/test_combat_enemy_roster.py',
 'logic/shop_logic.py',
 'ui/ui_tab_shop.py',
 'data/achievement_diary_catalog.py',
 'runtime/runtime_actions_carried.py',
 'runtime/runtime_actions_activities.py']
BASELINE_SHA256 = {'plain-core_constants.py.stdout': '90bc427f383db2fac70328dd3a2040a551138b5a066bbc3e374c57a58a1eb20b',
 'plain-data_quest_data.py.stdout': '3eb1d304475e198035ba767ec2e33e7e9f892dd62de47edab6565f4332899d95',
 'plain-data_combat_data.py.stdout': '9e282ee1308fc98a3df3307a313cf119f03eefb2f975fb2c271c400d0f0c613a',
 'plain-data_slayer_data.py.stdout': '957fae47446ed8518154a44c426940fd4c661d352700cfb12437ae30b05d42b7',
 'plain-logic_pure_logic_pure_combat_engine.py.stdout': '635563a81165945ceab475eb324b9fdf39a47fe890ff22db50a9953a0002b6aa',
 'plain-tests_test_combat_enemy_roster.py.stdout': 'aad6cf638c0eb7bc92e3450020bb8bbe826cb9b3ec4136432612ea2aa8edf4a9',
 'plain-logic_shop_logic.py.stdout': '3c8a9dd028c3c289779db511235b0378941a0ffda21ff22e1fdf26fa96c9f731',
 'plain-ui_ui_tab_shop.py.stdout': '7f4d49ff91c87fe94b948b7de2c5e4e3ba13a03a3bd879ca8b48fa3a4a21db56',
 'plain-data_achievement_diary_catalog.py.stdout': '8c365ea6ed137687749aabfb2884a227efd9f5666f20b60b76b5930ba9a8bc77',
 'plain-runtime_runtime_actions_carried.py.stdout': '92851ad09407cec6bc926438f238a23293f6987684e83c011e52bc1779fb26e9',
 'plain-runtime_runtime_actions_activities.py.stdout': '708cbb4cb237b2b34a313f26d80167c131138a9cce0a35f25e0f6ef848e989c4',
 'qt-core_constants.py.stdout': '90bc427f383db2fac70328dd3a2040a551138b5a066bbc3e374c57a58a1eb20b',
 'qt-data_quest_data.py.stdout': '3eb1d304475e198035ba767ec2e33e7e9f892dd62de47edab6565f4332899d95',
 'qt-data_combat_data.py.stdout': '9e282ee1308fc98a3df3307a313cf119f03eefb2f975fb2c271c400d0f0c613a',
 'qt-data_slayer_data.py.stdout': '957fae47446ed8518154a44c426940fd4c661d352700cfb12437ae30b05d42b7',
 'qt-logic_pure_logic_pure_combat_engine.py.stdout': '635563a81165945ceab475eb324b9fdf39a47fe890ff22db50a9953a0002b6aa',
 'qt-tests_test_combat_enemy_roster.py.stdout': 'aad6cf638c0eb7bc92e3450020bb8bbe826cb9b3ec4136432612ea2aa8edf4a9',
 'qt-logic_shop_logic.py.stdout': '3c8a9dd028c3c289779db511235b0378941a0ffda21ff22e1fdf26fa96c9f731',
 'qt-ui_ui_tab_shop.py.stdout': 'e64a1222fe9ac15f5d13070fe28c6d7510e035106c93a7611c04fb76c276fcd3',
 'qt-data_achievement_diary_catalog.py.stdout': '8c365ea6ed137687749aabfb2884a227efd9f5666f20b60b76b5930ba9a8bc77',
 'qt-runtime_runtime_actions_carried.py.stdout': '92851ad09407cec6bc926438f238a23293f6987684e83c011e52bc1779fb26e9',
 'qt-runtime_runtime_actions_activities.py.stdout': '708cbb4cb237b2b34a313f26d80167c131138a9cce0a35f25e0f6ef848e989c4',
 'qt-__init__.py.stdout': '8426b0a445bf8134afd99391e4029d8fb32bd4b6c010d080fbe16117905ccfb0'}
NEW_TESTS = ['test_module_surface.ModuleSurfaceTest.test_constants_parts_import_standalone',
 'test_module_surface.ModuleSurfaceTest.test_constants_export_order']
FULL_TESTS = ['test_module_surface.ModuleSurfaceTest.test_first_wave_digests',
 'test_module_surface.ModuleSurfaceTest.test_constants_parts_import_standalone',
 'test_module_surface.ModuleSurfaceTest.test_constants_export_order',
 'test_module_surface.ModuleSurfaceTest.test_public_normalization_preserves_sequence_order_and_sorts_unordered_values',
 'test_module_surface.ModuleSurfaceTest.test_unsupported_values_are_explicitly_unrepresentable',
 'test_module_surface.ModuleSurfaceTest.test_root_initializer_is_reported_as_unavailable_without_aqt',
 'test_module_surface.ModuleSurfaceTest.test_root_initializer_digest_under_qt']
DISCOVERY_SHA256 = '0cf05aa2519522896ae1435810c22cbe96d9894675711749cba5e1f96ecd211d'
RECORD_PATTERN = r'^(test_\S+) \(([^\n]+)\)(?:\n([^\n]*))? \.\.\. (.+)$'
ALLOWED_FULL_SKIP = {
    'test_module_surface.ModuleSurfaceTest.test_root_initializer_is_reported_as_unavailable_without_aqt':
        'root initializer requires aqt; use the offscreen Qt interpreter',
}


EXPECTED_PARTS = sorted(name for name in EXPECTED if name.startswith('core/constants_parts/'))
CANARY_SCRIPT = Path('/tmp/ankiscape-constants-ownership-canary-2026-09-05.py')
CANARY_SHA256 = '8192da12509728bf7b08c464fbc35634793163cdfa43285f2ff9681af9ed86d1'
CANARY_ASSERTIONS = {
    'facade-import': "'ankiscape.core.constants' not in sys.modules",
    'equipment-alias': 'data is not module._BASE_EQUIPMENT_DATA',
    'equipment-mutation': 'module._BASE_EQUIPMENT_DATA == base',
}


def part_inventory():
    return sorted(str(path.relative_to(ROOT)) for path in (ROOT / 'core/constants_parts').rglob('*.py'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def binding(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def source_hashes():
    return {name: sha((ROOT / name).read_bytes()) if (ROOT / name).is_file() else None
            for name in EXPECTED}


def payload_integrity(path):
    record = {'path': str(path), 'valid': False}
    try:
        raw = path.read_bytes()
        body, footer = raw.rsplit(b'MODULE_SURFACE_SHA256: ', 1)
        digest = sha(body)
        record.update(bytes=len(raw), file_sha256=sha(raw), body_sha256=digest,
                      valid=footer == (digest + '\n').encode())
        if not record['valid']:
            record['error'] = 'Footer must contain the exact body digest and one newline'
    except (OSError, ValueError) as error:
        record['error'] = repr(error)
    return record


def check_tests(record, out, expected_ids, descriptions):
    check = {'lane': record['lane'], 'mode': record['mode'], 'valid': False, 'outcomes': []}
    try:
        assert record['exit_code'] == 0 and record['status'] == 'finished', 'Test subprocess failed'
        assert (out / record['stdout']).read_bytes() == b'', 'Unexpected test stdout'
        text = (out / record['stderr']).read_text()
        cursor = 0
        skips = 0
        for match in re.finditer(RECORD_PATTERN, text, re.MULTILINE):
            assert text[cursor:match.start()].strip() == '', 'Unmatched text before a test record'
            method, test_id, description, status = match.groups()
            assert test_id in expected_ids and method == test_id.rsplit('.', 1)[-1], 'Unexpected test identity'
            if description is not None:
                assert descriptions[test_id] == description, 'Printed description differs from the source docstring'
            if status != 'ok':
                assert record['mode'] == 'module-surface' and test_id in ALLOWED_FULL_SKIP, 'Unexpected non-passing test outcome'
                assert status.startswith('skipped '), 'Expected the existing plain-root skip only'
                assert ast.literal_eval(status[len('skipped '):]) == ALLOWED_FULL_SKIP[test_id], 'Skip reason differs from the existing test contract'
                skips += 1
            check['outcomes'].append({'test_id': test_id, 'description': description, 'status': status})
            cursor = match.end()
        ids = [row['test_id'] for row in check['outcomes']]
        assert Counter(ids) == Counter(expected_ids) and len(set(ids)) == len(expected_ids), 'Test selection is incomplete or duplicated'
        tail = re.fullmatch(r'\n\n-{70}\nRan ([0-9]+) tests in ([0-9]+\.[0-9]+)s\n\nOK(?: \(skipped=([0-9]+)\))?\n', text[cursor:])
        assert tail and int(tail[1]) == len(expected_ids) and int(tail[3] or 0) == skips, 'Unmatched output or inconsistent unittest summary'
        check.update(valid=True, tests=len(ids), skips=skips, seconds=tail[2], unmatched_records=0,
                     selected_ids_sha256=sha(('\n'.join(sorted(ids)) + '\n').encode()))
    except (AssertionError, OSError, ValueError, KeyError, SyntaxError) as error:
        check['error'] = repr(error)
    return check


def main():
    out = Path(tempfile.mkdtemp(prefix='constants-verification-', dir=ROOT.parent / 'reports'))
    print(str(out), flush=True)
    actual = source_hashes()
    write_json(out / 'source-hashes.json', {'expected': EXPECTED, 'actual': actual})
    write_json(out / 'capture.json', {
        'started_utc': datetime.now(timezone.utc).isoformat(), 'repo': str(ROOT),
        'script_sha256': sha(Path(__file__).read_bytes()), 'baseline': str(BASELINE),
        'discovery_baseline': str(DISCOVERY_BASELINE), 'source_snapshot_kind': 'Frozen source-hash manifest; integration commit was pending at authoring',
        'preserved_split_commit': '0246e1fc0306d558648b511ca79813e01e46b036',
        'integration_main_commit': '814b4d591df4525e0bda4a1f858baf6345ed4d38',
        'author_static_manifest_sha256': '62570531c49eab9fc59e88ab1f107720e6a95b15c83211db3d34094244ff0565',
        'baseline_product_compatibility': 'Parent-approved existing 6438d422 payloads are the product baseline for main814; discovery separately uses the main814 Ghosts prerequisite baseline.',
        'new_test_selectors': NEW_TESTS, 'full_module_selector': 'test_module_surface.',
        'excluded_tests': [], 'expected_full_module_ids': FULL_TESTS,
        'timeout_seconds_per_process': 300,
        'timeout_cleanup': 'Each job owns a new process group; a timeout kills that group, including nested interpreter_cases children.',
        'interpreter_semantics': 'Each existing test retains interpreter_cases(), which can spawn both interpreters internally. The capture does not replace, patch, or weaken that behavior.',
        'runtime_ownership_canaries': 'Three disposable process fixtures per lane execute the exact frozen standalone snippet and must fail at their intended assertion only.',
    })
    errors = []
    if actual != EXPECTED:
        write_json(out / 'source-hashes-after.json', source_hashes())
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': ['Source hash mismatch; no runtime commands launched'], 'subprocess_count': 0})
        return 2
    try:
        inventory = part_inventory()
        write_json(out / 'part-inventory.json', {'expected': EXPECTED_PARTS, 'actual': inventory})
        assert len(EXPECTED_PARTS) == 17 and inventory == EXPECTED_PARTS, 'Part inventory differs; stale activity_base or another unbound file is forbidden'
        assert len([name for name in inventory if not name.endswith('/__init__.py')]) == 16
        assert sha(CANARY_SCRIPT.read_bytes()) == CANARY_SHA256, 'Frozen ownership-canary script changed'
        tree = ast.parse((ROOT / 'tests/test_module_surface.py').read_text())
        modules = list(next(ast.literal_eval(node.value) for node in tree.body
                            if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'FIRST_WAVE_DIGESTS' for target in node.targets)))
        assert modules == MODULES, 'The complete current measuring module inventory differs'
        methods = {f'test_module_surface.{cls.name}.{node.name}': node
                   for cls in tree.body if isinstance(cls, ast.ClassDef)
                   for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}
        assert set(methods) == set(FULL_TESTS) and set(NEW_TESTS) <= set(methods), 'The frozen seven-test inventory differs'
        standalone = methods[NEW_TESTS[0]]
        snippet_value = next(node.value for node in standalone.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'script' for target in node.targets))
        snippet = '\n'.join(ast.literal_eval(snippet_value.args[0]))
        snippet_sha256 = sha(snippet.encode())
        snippet_tree = ast.parse(snippet)
        canary_lines = {case: min(node.lineno for node in ast.walk(snippet_tree) if isinstance(node, ast.Assert) and ast.unparse(node.test) == assertion) for case, assertion in CANARY_ASSERTIONS.items()}
        descriptions = {test_id: (ast.get_docstring(node) or '').split('\n', 1)[0] for test_id, node in methods.items()}
        qt_python = ROOT.parent / '.venv-qt/bin/python'
        internal_qt = ROOT / '.venv-qt/bin/python'
        interpreter_layout = {'outer_plain': '/opt/homebrew/bin/python3', 'outer_qt': str(qt_python),
                              'internal_qt': str(internal_qt), 'internal_qt_resolved': str(internal_qt.resolve()),
                              'outer_qt_resolved': str(qt_python.resolve())}
        write_json(out / 'interpreter-layout.json', interpreter_layout)
        assert Path('/opt/homebrew/bin/python3').is_file() and qt_python.is_file(), 'A required interpreter is unavailable'
        assert internal_qt.is_file() and internal_qt.resolve() == qt_python.resolve(), 'Existing interpreter_cases() needs the mirror Qt link to the approved Qt interpreter; capture does not create it'
        required_names = [lane + '-' + module.replace('/', '_') + '.stdout'
                          for lane in ('plain', 'qt')
                          for module in [*MODULES, *(['__init__.py'] if lane == 'qt' else [])]]
        assert len(required_names) == 23 and set(required_names) == set(BASELINE_SHA256)
        available = {path.name for path in BASELINE.glob('*.py.stdout')}
        assert available - set(required_names) <= {'plain-__init__.py.stdout'}, 'Unexpected baseline payload files'
        excluded = []
        control = BASELINE / 'plain-__init__.py.stdout'
        if control.exists():
            excluded.append({**binding(control), 'role': 'Unavailable plain-root control outside the required 23 payloads'})
            assert control.read_bytes() == b'', 'Plain-root baseline control must be empty'
        write_json(out / 'baseline-files.json', {'required': required_names, 'available': sorted(available), 'excluded': excluded})
        baseline_checks = [payload_integrity(BASELINE / name) for name in required_names]
        write_json(out / 'baseline-integrity.json', baseline_checks)
        assert all(row['valid'] and row['file_sha256'] == BASELINE_SHA256[Path(row['path']).name] for row in baseline_checks), 'A required baseline payload failed its pinned raw hash or strict footer'
        baseline_ids = {}
        baseline_discovery = []
        for lane in ('plain', 'qt'):
            path = DISCOVERY_BASELINE / (lane + '-discovery.stdout')
            raw = path.read_bytes()
            ids = raw.decode().splitlines()
            assert sha(raw) == DISCOVERY_SHA256 and len(ids) == len(set(ids)) == 5567, 'Main814 discovery baseline hash or inventory differs'
            assert not set(ids) & set(NEW_TESTS), 'A new test is already in the baseline'
            stderr = DISCOVERY_BASELINE / (lane + '-discovery.stderr')
            assert stderr.read_bytes() == b'', 'Unexpected baseline discovery stderr'
            baseline_ids[lane] = ids
            baseline_discovery.append({'lane': lane, 'stdout': binding(path), 'stderr': binding(stderr), 'tests': len(ids)})
        write_json(out / 'baseline-discovery.json', baseline_discovery)
    except (AssertionError, OSError, ValueError, StopIteration, SyntaxError) as error:
        write_json(out / 'source-hashes-after.json', source_hashes())
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': [repr(error)], 'scope': 'Preflight failed; no runtime commands launched', 'subprocess_count': 0})
        return 2
    results = []
    surfaces = []
    tests = []
    discoveries = []
    canaries = []
    canary_failed = False
    source_failed = False
    for lane, python in [('plain', '/opt/homebrew/bin/python3'), ('qt', str(qt_python))]:
        env = {**os.environ, 'PATH': '/opt/homebrew/bin:/usr/bin:/bin', 'QT_QPA_PLATFORM': 'offscreen',
               'ANKISCAPE_GAME_MAIN': str(ROOT.parent / 'sources/game-main'),
               'ANKISCAPE_DARKAN_WORLD_SERVER': str(ROOT.parent / 'sources/darkan-world-server')}
        env.pop('PYTHONPATH', None)
        if lane == 'plain':
            env['PYTHONPATH'] = str(ROOT.parent / 'plain-site')
        jobs = [('canary-' + case, [str(CANARY_SCRIPT), case]) for case in CANARY_ASSERTIONS]
        jobs += [('named-tests', ['run_tests.py', *NEW_TESTS, '--verbosity', '2']),
                ('module-surface', ['run_tests.py', 'test_module_surface.', '--verbosity', '2']),
                ('discovery', ['run_tests.py', '--list', '--max-results', '10000'])]
        jobs += [(module.replace('/', '_'), ['tools/module_surface.py', module])
                 for module in [*MODULES, *(['__init__.py'] if lane == 'qt' else [])]]
        for mode, args in jobs:
            name = lane + '-' + mode
            record = {'lane': lane, 'mode': mode, 'argv': [python, *args], 'exit_code': None,
                      'stdout': name + '.stdout', 'stderr': name + '.stderr', 'status': 'running',
                      'source_hashes_before': source_hashes(), 'source_hashes_after': None, 'launched': False}
            results.append(record)
            write_json(out / 'results.json', results)
            if record['source_hashes_before'] != EXPECTED:
                record['status'] = 'blocked-before-launch'
                source_failed = True
                errors.append(name + ': source hash mismatch before launch; remaining jobs stopped')
                write_json(out / 'results.json', results)
                break
            with (out / record['stdout']).open('wb') as stdout, (out / record['stderr']).open('wb') as stderr:
                try:
                    process = subprocess.Popen(record['argv'], cwd=ROOT, env=env,
                                               stdout=stdout, stderr=stderr, start_new_session=True)
                    record['launched'] = True
                    try:
                        record['exit_code'] = process.wait(timeout=300)
                        record['status'] = 'finished'
                    except subprocess.TimeoutExpired as error:
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        record.update(exit_code=process.wait(), status='error', error=repr(error),
                                      timeout_process_group=process.pid)
                except OSError as error:
                    record.update(status='error', error=repr(error))
            record['stdout_binding'] = binding(out / record['stdout'])
            record['stderr_binding'] = binding(out / record['stderr'])
            record['source_hashes_after'] = source_hashes()
            write_json(out / 'results.json', results)
            if record['source_hashes_after'] != EXPECTED:
                source_failed = True
                errors.append(name + ': source hash mismatch after job; remaining jobs stopped')
                break
            if record['exit_code'] != 0 or record['status'] != 'finished':
                errors.append(name + ': subprocess did not finish successfully')
            if mode.startswith('canary-'):
                case = mode[len('canary-'):]
                check = {'lane': lane, 'case': case, 'valid': False}
                try:
                    assert record['exit_code'] == 0 and record['status'] == 'finished', 'Canary subprocess failed'
                    assert (out / record['stderr']).read_bytes() == b'', 'Unexpected canary stderr'
                    observed = json.loads((out / record['stdout']).read_text())
                    expected = {'status': 'PASS', 'case': case, 'caught': 'AssertionError',
                                'assertion': CANARY_ASSERTIONS[case], 'assertion_line': canary_lines[case],
                                'script_sha256': snippet_sha256,
                                'test_sha256': EXPECTED['tests/test_module_surface.py'],
                                'original_base_unchanged': True}
                    assert observed == expected, 'Canary evidence does not identify the exact intended failure'
                    check.update(valid=True, evidence=observed)
                except (AssertionError, OSError, ValueError) as error:
                    check['error'] = repr(error)
                    errors.append(name + ': ' + check['error'])
                    canary_failed = True
                canaries.append(check)
                write_json(out / 'ownership-canaries.json', canaries)
                if canary_failed:
                    break
            elif mode in ('named-tests', 'module-surface'):
                check = check_tests(record, out, NEW_TESTS if mode == 'named-tests' else FULL_TESTS, descriptions)
                tests.append(check)
                write_json(out / 'test-verification.json', tests)
                if not check['valid']:
                    errors.append(name + ': ' + check['error'])
            elif mode == 'discovery':
                ids = (out / record['stdout']).read_text().splitlines()
                selected_full = [test_id for test_id in ids if 'test_module_surface.' in test_id.casefold()]
                selected_new = [test_id for test_id in ids if any(selector.casefold() in test_id.casefold() for selector in NEW_TESTS)]
                check = {'lane': lane, 'baseline_tests': len(baseline_ids[lane]), 'candidate_tests': len(ids),
                         'expected_additions': NEW_TESTS, 'full_module_ids': selected_full, 'named_test_ids': selected_new,
                         'ordered_baseline_preserved': [test_id for test_id in ids if test_id not in NEW_TESTS] == baseline_ids[lane]}
                check['valid'] = (record['exit_code'] == 0 and (out / record['stderr']).read_bytes() == b''
                                  and len(ids) == len(set(ids)) == 5569
                                  and Counter(ids) == Counter(baseline_ids[lane]) + Counter(NEW_TESTS)
                                  and Counter(selected_full) == Counter(FULL_TESTS)
                                  and Counter(selected_new) == Counter(NEW_TESTS)
                                  and check['ordered_baseline_preserved'])
                discoveries.append(check)
                write_json(out / 'discovery-verification.json', discoveries)
                if not check['valid']:
                    errors.append(name + ': discovery differs from main814 plus exactly two new test IDs')
            else:
                path = out / record['stdout']
                check = {'file': path.name, 'candidate': payload_integrity(path), 'baseline': binding(BASELINE / path.name)}
                check['byte_equal'] = path.read_bytes() == (BASELINE / path.name).read_bytes()
                check['valid'] = (record['exit_code'] == 0 and check['candidate']['valid'] and check['byte_equal']
                                  and check['baseline']['sha256'] == BASELINE_SHA256[path.name])
                surfaces.append(check)
                write_json(out / 'surface-equality.json', surfaces)
                if not check['valid']:
                    errors.append(name + ': candidate is not byte-identical to its pinned baseline payload')
            print(name, record['exit_code'], record['status'], flush=True)
        if canary_failed or source_failed:
            break
    final_inventory = part_inventory()
    write_json(out / 'part-inventory-after.json', final_inventory)
    if final_inventory != EXPECTED_PARTS:
        errors.append('Part inventory changed during capture')
    final_hashes = source_hashes()
    write_json(out / 'source-hashes-after.json', final_hashes)
    if final_hashes != EXPECTED:
        errors.append('Source files changed during capture')
    if len(surfaces) != 23 or {row['file'] for row in surfaces} != set(BASELINE_SHA256):
        errors.append('Required 23-payload inventory differs')
    if len(results) != 35 or len(tests) != 4 or len(discoveries) != 2 or len(canaries) != 6:
        errors.append('Required command inventory differs')
    verdict = {'status': 'FAIL' if errors else 'PASS', 'errors': errors,
               'finished_utc': datetime.now(timezone.utc).isoformat(), 'surface_count': len(surfaces),
               'subprocess_count': sum(record['launched'] for record in results), 'ownership_canary_count': len(canaries),
               'scope': 'Frozen-source named tests, complete measuring module, selective ownership canaries, exact discovery, and byte-identical surfaces only; independent review, full branch/repository gates, and exact merged-tree gate remain separate.'}
    write_json(out / 'verification.json', verdict)
    print(json.dumps(verdict), flush=True)
    return int(bool(errors))


if __name__ == '__main__':
    if sys.argv[1:] == ['--source-hash-canary']:
        EXPECTED = {**EXPECTED, 'core/constants.py': '0' * 64}
    elif sys.argv[1:]:
        raise ValueError('Unknown capture argument')
    raise SystemExit(main())
