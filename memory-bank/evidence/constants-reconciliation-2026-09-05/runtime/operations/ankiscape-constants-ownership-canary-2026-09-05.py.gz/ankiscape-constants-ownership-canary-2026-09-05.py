#!/usr/bin/env python3
"""Exercise one existing ownership assertion with an isolated disposable fixture."""
import ast
import hashlib
import importlib
import json
from pathlib import Path
import sys
import types

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
TEST_SHA256 = '8cb6d028d1623c72367f34b61194993221270283bd79e0aaf020198f078d4fec'
ASSERTIONS = {
    'facade-import': "'ankiscape.core.constants' not in sys.modules",
    'equipment-alias': 'data is not module._BASE_EQUIPMENT_DATA',
    'equipment-mutation': 'module._BASE_EQUIPMENT_DATA == base',
}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ASSERTIONS:
        raise ValueError('Choose exactly one defined canary case')
    case = sys.argv[1]
    source = ROOT / 'tests/test_module_surface.py'
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != TEST_SHA256:
        raise RuntimeError('Frozen test source changed; no project imports performed')
    tree = ast.parse(raw)
    method = next(node for cls in tree.body if isinstance(cls, ast.ClassDef) and cls.name == 'ModuleSurfaceTest'
                  for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == 'test_constants_parts_import_standalone')
    value = next(node.value for node in method.body if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == 'script' for target in node.targets))
    if not (isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute)
            and isinstance(value.func.value, ast.Constant) and value.func.value.value == '\n'
            and value.func.attr == 'join' and len(value.args) == 1 and not value.keywords):
        raise RuntimeError('The existing standalone script no longer has its frozen literal form')
    script = '\n'.join(ast.literal_eval(value.args[0]))
    script_tree = ast.parse(script)
    matching = sorted(node.lineno for node in ast.walk(script_tree)
                      if isinstance(node, ast.Assert) and ast.unparse(node.test) == ASSERTIONS[case])
    expected_count = 2 if case == 'facade-import' else 1
    if len(matching) != expected_count:
        raise RuntimeError('The intended ownership assertion is missing or ambiguous')
    expected_line = matching[0]
    filename = str(source) + '::standalone-script'
    code = compile(script, filename, 'exec')
    sys.path.insert(0, str(ROOT))
    import pkg_alias
    leaf = 'activity_updates' if case == 'facade-import' else 'skill_assets'
    module_name = 'ankiscape.core.constants_parts.' + leaf
    module = importlib.import_module(module_name)
    if 'ankiscape.core.constants' in sys.modules:
        raise RuntimeError('Setup already loaded the facade; canary is not selective')
    original_base = original_base_snapshot = None
    if case == 'facade-import':
        sys.modules['ankiscape.core.constants'] = types.ModuleType('ankiscape.core.constants')
    else:
        original_base = module._BASE_EQUIPMENT_DATA
        original_base_snapshot = original_base.copy()
        fixture_base = original_base.copy()
        module._BASE_EQUIPMENT_DATA = fixture_base
        original_helper = module._equipment_data_before_diaries
        if case == 'equipment-alias':
            module._equipment_data_before_diaries = lambda: fixture_base
        else:
            marker = object()

            def mutate_fixture_after_assembly():
                data = original_helper()
                fixture_base[marker] = marker
                return data

            module._equipment_data_before_diaries = mutate_fixture_after_assembly
    sys.argv = ['-c', module_name]
    try:
        exec(code, {'__name__': '__main__'})
    except AssertionError as error:
        frames = []
        trace = error.__traceback__
        while trace:
            frames.append((trace.tb_frame.f_code.co_filename, trace.tb_lineno))
            trace = trace.tb_next
        if frames[-1] != (filename, expected_line) or error.args:
            raise RuntimeError('Canary failed at an unrelated assertion') from error
        if original_base is not None and original_base != original_base_snapshot:
            raise RuntimeError('Original equipment base was modified') from error
        print(json.dumps({'status': 'PASS', 'case': case, 'caught': 'AssertionError',
                          'assertion': ASSERTIONS[case], 'assertion_line': expected_line,
                          'script_sha256': hashlib.sha256(script.encode()).hexdigest(),
                          'test_sha256': TEST_SHA256, 'original_base_unchanged': True}), flush=True)
        return 0
    raise RuntimeError('Canary did not fail at its intended ownership assertion')


if __name__ == '__main__':
    raise SystemExit(main())
