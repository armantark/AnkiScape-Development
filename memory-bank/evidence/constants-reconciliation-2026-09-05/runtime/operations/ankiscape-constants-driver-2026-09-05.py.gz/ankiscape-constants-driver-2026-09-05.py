#!/usr/bin/env python3
"""Run reviewed constants evidence under the canonical MacBook mirror guard."""
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

CANONICAL = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
CANDIDATE = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/8/ankiscape_fork')
CAPTURE = Path('/tmp/ankiscape-constants-capture-2026-09-05.py')
BINDINGS = Path('/tmp/ankiscape-constants-bindings-2026-09-05.json')
BINDINGS_SHA256 = '185ab53b2bf475f4022c1172112b1281c319fb46a6d6b2a520324a9e22d78658'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def verify_local(bindings, expected=None):
    head = subprocess.check_output(['git', '-C', str(CANDIDATE), 'rev-parse', 'HEAD'], text=True).strip()
    if head != bindings['candidate_head']:
        raise RuntimeError('Candidate HEAD changed; no remote commands launched')
    expected = bindings['candidate'] if expected is None else expected
    if {name: sha(CANDIDATE / name) for name in expected} != expected:
        raise RuntimeError('Frozen source bindings changed; no remote commands launched')
    inventory = sorted(str(path.relative_to(CANDIDATE)) for path in (CANDIDATE / 'core/constants_parts').rglob('*.py'))
    if inventory != bindings['part_inventory']:
        raise RuntimeError('Constants part inventory changed; no remote commands launched')
    manifest = bindings['static_manifest']
    if sha(CANDIDATE / manifest['path']) != manifest['sha256']:
        raise RuntimeError('Static manifest changed; no remote commands launched')


def local_canary(bindings):
    wrong = {**bindings['candidate'], 'core/constants.py': '0' * 64}
    try:
        verify_local(bindings, wrong)
    except RuntimeError as error:
        if str(error) != 'Frozen source bindings changed; no remote commands launched':
            raise
        return {'status': 'PASS', 'canary': str(error), 'remote_commands_launched': 0}
    raise RuntimeError('Source-hash canary failed to stop')


def report_path(output, runner):
    report = Path(output.splitlines()[0])
    if report.parent != runner.REMOTE_ROOT / 'reports' or not report.name.startswith('constants-verification-'):
        raise RuntimeError(f'Unexpected capture report path: {report}')
    return report


def main():
    if sys.argv[1:] not in ([], ['--source-hash-canary']):
        raise RuntimeError('Unknown arguments; no remote commands launched')
    if sha(BINDINGS) != BINDINGS_SHA256:
        raise RuntimeError('Bindings changed; no remote commands launched')
    bindings = json.loads(BINDINGS.read_text())
    for path, digest in bindings['uploads'].items():
        if sha(Path(path)) != digest:
            raise RuntimeError('Frozen upload differs; no remote commands launched: ' + path)
    if sha(CANONICAL / 'tools/run_remote_tests.py') != bindings['runner_sha256']:
        raise RuntimeError('Canonical runner changed; no remote commands launched')
    verify_local(bindings)
    local_guard = local_canary(bindings)
    if sys.argv[1:] == ['--source-hash-canary']:
        print(json.dumps(local_guard), flush=True)
        return 0
    spec = importlib.util.spec_from_file_location('constants_remote_runner', CANONICAL / 'tools/run_remote_tests.py')
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    summary = Path(tempfile.mkdtemp(prefix='constants-driver-')) / 'capture.json'
    record = {'status': 'RUNNING', 'local_source_hash_canary': local_guard, 'bindings_sha256': BINDINGS_SHA256}
    summary.write_text(json.dumps(record, indent=2) + '\n')
    runner.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with runner.LOCAL_MIRROR_LOCK_PATH.open('a+', encoding='utf-8') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            runner._reconcile_pending_run()
            runner._preflight('plain')
            runner._preflight('qt')
            verify_local(bindings)
            uploads = {**bindings['uploads'], str(BINDINGS): BINDINGS_SHA256}
            runner._run_with_retries(
                ('rsync', '-a', '-e', runner.RSYNC_SSH, *uploads, f'{runner.HOST}:/tmp/'),
                label='upload reviewed constants capture and canary')
            remote_hashes = runner._ssh(
                'shasum -a 256 ' + ' '.join(shlex.quote(path) for path in uploads),
                label='constants upload hash check', repeat_safe=True)
            observed = {line.split(maxsplit=1)[1].strip(): line.split(maxsplit=1)[0]
                        for line in remote_hashes.splitlines()}
            if observed != uploads:
                raise RuntimeError('Uploaded constants bindings differ; sync blocked')
            runner._sync(CANDIDATE)
            command = '/opt/homebrew/bin/python3 ' + shlex.quote(str(CAPTURE))
            runner._remote_lane_command = lambda lane: command + ' --source-hash-canary'
            code, output = runner._stream_remote_run('constants-source-canary-2026-09-05', timeout=300, poll_interval=5)
            record['remote_source_hash_canary'] = {'exit_code': code, 'output': output}
            summary.write_text(json.dumps(record, indent=2) + '\n')
            if code != 2:
                raise RuntimeError(f'Remote source canary expected exit 2, received {code}')
            canary_report = report_path(output, runner)
            verdict = json.loads(runner._ssh(
                'cat ' + shlex.quote(str(canary_report / 'verification.json')) + ' && test ! -e '
                + shlex.quote(str(canary_report / 'results.json')),
                label='constants source canary evidence', repeat_safe=True))
            if verdict != {'status': 'FAIL', 'errors': ['Source hash mismatch; no runtime commands launched'], 'subprocess_count': 0}:
                raise RuntimeError(f'Source canary evidence differs: {verdict}')
            record['remote_source_hash_canary'].update(report=str(canary_report), verification=verdict)
            summary.write_text(json.dumps(record, indent=2) + '\n')
            verify_local(bindings)
            runner._remote_lane_command = lambda lane: command
            code, output = runner._stream_remote_run('constants-capture-2026-09-05', timeout=3600, poll_interval=5)
            record['capture'] = {'exit_code': code, 'output': output}
            summary.write_text(json.dumps(record, indent=2) + '\n')
            if code != 0:
                raise RuntimeError(f'Constants capture failed: {code}; local record: {summary}')
            report = report_path(output, runner)
            verdict = json.loads(runner._ssh(
                'cat ' + shlex.quote(str(report / 'verification.json')),
                label='constants terminal verification read', repeat_safe=True))
            if (verdict.get('status') != 'PASS' or verdict.get('errors') != []
                    or verdict.get('subprocess_count') != 35 or verdict.get('surface_count') != 23
                    or verdict.get('ownership_canary_count') != 6):
                raise RuntimeError(f'Constants evidence did not pass: {verdict}')
            verify_local(bindings)
            record['capture'].update(report=str(report), verification=verdict)
            record['status'] = 'PASS'
            summary.write_text(json.dumps(record, indent=2) + '\n')
        except Exception as error:
            record.update(status='FAIL', error=repr(error))
            summary.write_text(json.dumps(record, indent=2) + '\n')
            raise
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
    print(json.dumps({'status': 'PASS', 'local_record': str(summary), 'report': str(report), 'verification': verdict}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
