#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  claude_prompt.sh [--model MODEL] [--effort LEVEL] [--output-format FORMAT] [--cwd DIR]
                   [--read-only-tools | --allow-edits] [--dry-run] [--] [PROMPT...]

Reads PROMPT from arguments, or from stdin when no prompt arguments are given.
Resolves Claude Code without requiring the shell PATH to already contain `claude`.
Runs the AI Usage Widget quota preflight immediately before contacting Claude.
EOF
}

model="${CLAUDE_MODEL:-}"
effort="${CLAUDE_EFFORT:-}"
output_format="${CLAUDE_OUTPUT_FORMAT:-text}"
cwd=""
dry_run=0
tool_mode="none"
prompt_parts=()

while [[ $# -gt 0 ]]; do
  case "$1" in
    --model)
      [[ $# -ge 2 ]] || { echo "missing value for --model" >&2; exit 2; }
      model="$2"
      shift 2
      ;;
    --effort)
      [[ $# -ge 2 ]] || { echo "missing value for --effort" >&2; exit 2; }
      effort="$2"
      shift 2
      ;;
    --output-format)
      [[ $# -ge 2 ]] || { echo "missing value for --output-format" >&2; exit 2; }
      output_format="$2"
      shift 2
      ;;
    --cwd)
      [[ $# -ge 2 ]] || { echo "missing value for --cwd" >&2; exit 2; }
      cwd="$2"
      shift 2
      ;;
    --dry-run)
      dry_run=1
      shift
      ;;
    --read-only-tools)
      tool_mode="read"
      shift
      ;;
    --allow-edits)
      tool_mode="write"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    --)
      shift
      prompt_parts+=("$@")
      break
      ;;
    *)
      prompt_parts+=("$1")
      shift
      ;;
  esac
done

CLAUDE_CMD=()

resolve_claude() {
  if [[ -n "${CLAUDE_BIN:-}" ]]; then
    if [[ -x "$CLAUDE_BIN" ]]; then
      CLAUDE_CMD=("$CLAUDE_BIN")
      return 0
    fi
    echo "CLAUDE_BIN is set but is not executable: $CLAUDE_BIN" >&2
    return 1
  fi

  if command -v claude >/dev/null 2>&1; then
    CLAUDE_CMD=("$(command -v claude)")
    return 0
  fi

  local candidate
  for candidate in \
    "/opt/homebrew/bin/claude" \
    "/usr/local/bin/claude" \
    "$HOME/.local/bin/claude" \
    "$HOME/.npm-global/bin/claude"; do
    if [[ -x "$candidate" ]]; then
      CLAUDE_CMD=("$candidate")
      return 0
    fi
  done

  local npm_root=""
  npm_root="$(npm root -g 2>/dev/null || true)"
  if [[ -n "$npm_root" ]]; then
    for candidate in \
      "$npm_root/@anthropic-ai/claude-code/bin/claude" \
      "$npm_root/@anthropic-ai/claude-code/bin/claude.js" \
      "$npm_root/@anthropic-ai/claude-code/bin/claude.exe"; do
      if [[ -f "$candidate" ]]; then
        CLAUDE_CMD=("node" "$candidate")
        return 0
      fi
    done
  fi

  if command -v npx >/dev/null 2>&1; then
    CLAUDE_CMD=("npx" "-y" "@anthropic-ai/claude-code")
    return 0
  fi

  echo "Could not find Claude Code. Install @anthropic-ai/claude-code or set CLAUDE_BIN." >&2
  return 1
}

if [[ ${#prompt_parts[@]} -gt 0 ]]; then
  prompt="${prompt_parts[*]}"
else
  if [[ -t 0 ]]; then
    echo "prompt is required on argv or stdin" >&2
    usage >&2
    exit 2
  fi
  prompt="$(cat)"
fi

if ! [[ "$prompt" =~ [^[:space:]] ]]; then
  echo "prompt is empty" >&2
  exit 2
fi

if [[ -z "$model" ]]; then
  echo "model is required; inspect quotas and pass --model fable, opus, or sonnet" >&2
  exit 2
fi

resolve_claude

args=(-p "$prompt")
if [[ -n "$model" ]]; then
  args+=(--model "$model")
fi
if [[ -n "$effort" ]]; then
  args+=(--effort "$effort")
fi
if [[ -n "$output_format" ]]; then
  args+=(--output-format "$output_format")
fi
case "$tool_mode" in
  none)
    args+=(--tools "")
    ;;
  read)
    args+=(--permission-mode plan --tools "Read,Glob,Grep")
    ;;
  write)
    args+=(--permission-mode acceptEdits --tools "Read,Glob,Grep,Edit,Write")
    ;;
esac

if [[ -n "$cwd" ]]; then
  cd "$cwd"
fi

if [[ "$dry_run" -eq 1 ]]; then
  printf 'cwd=%q\n' "${PWD}"
  printf 'cmd='
  printf '%q ' "${CLAUDE_CMD[@]}" "${args[@]}"
  printf '\n'
  exit 0
fi

script_dir="/Users/ArmanTarkhanian1/.codex/skills/ask-claude/scripts"
quota="$("$script_dir/claude_quota.py" --compact --require-fresh)" || {
  echo "Claude call canceled because a fresh quota snapshot was unavailable." >&2
  exit 1
}
printf 'Claude quota preflight: %s\n' "$quota" >&2

output_file="$(mktemp "${TMPDIR:-/tmp}/ask-claude-output.XXXXXX")"
trap 'rm -f "$output_file"' EXIT HUP INT TERM

set +e
"${CLAUDE_CMD[@]}" "${args[@]}" | tee "$output_file"
provider_status=${PIPESTATUS[0]}
set -e
if [[ "$provider_status" -ne 0 ]]; then
  exit "$provider_status"
fi
python3 "$script_dir/validate_claude_output.py" \
  --model "$model" \
  --output-format "$output_format" \
  "$output_file"
