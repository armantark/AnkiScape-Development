"""Static-only structural and installed-gate verification for P13."""

import ast
from collections import Counter
import difflib
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[3]
EVIDENCE = Path(__file__).resolve().parent
PINS = json.loads((EVIDENCE / "initial-pins.json").read_text())
FILES = (
    "logic_pure/logic_pure_combat_engine.py",
    "tests/combat/test_enemy_unequip_transaction.py",
    "tools/combat/compare_enemy_unequip_transaction.py",
    "tools/combat/check_enemy_unequip_guards.py",
)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def named_definition(tree, name):
    return next(
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        and node.name == name
    )


def is_unequip_branch(node):
    return (
        isinstance(node, ast.If)
        and isinstance(node.test, ast.Compare)
        and isinstance(node.test.left, ast.Name)
        and node.test.left.id == "attack_kind"
        and len(node.test.comparators) == 1
        and isinstance(node.test.comparators[0], ast.Constant)
        and node.test.comparators[0].value == "unequip"
    )


def statement_lists(node):
    for _field, value in ast.iter_fields(node):
        if isinstance(value, list) and value and all(
            isinstance(item, ast.stmt) for item in value
        ):
            yield value
        if isinstance(value, list):
            for item in value:
                if isinstance(item, ast.AST):
                    yield from statement_lists(item)
        elif isinstance(value, ast.AST):
            yield from statement_lists(value)


def structural_proof(baseline_bytes, candidate_bytes):
    baseline = ast.parse(baseline_bytes)
    candidate = ast.parse(candidate_bytes)
    baseline_burst = named_definition(baseline, "apply_combat_burst_pure")
    candidate_burst = named_definition(candidate, "apply_combat_burst_pure")
    helper = named_definition(candidate, "_combat_apply_enemy_unequip_special")
    baseline_branch = next(node for node in ast.walk(baseline_burst) if is_unequip_branch(node))
    candidate_branch = next(node for node in ast.walk(candidate_burst) if is_unequip_branch(node))
    baseline_other = [
        ast.dump(node, include_attributes=False)
        for node in baseline.body
        if not (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            and node.name == "apply_combat_burst_pure"
        )
    ]
    candidate_other = [
        ast.dump(node, include_attributes=False)
        for node in candidate.body
        if not (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            and node.name
            in {"apply_combat_burst_pure", "_combat_apply_enemy_unequip_special"}
        )
    ]
    helper_prefix = [ast.dump(node, include_attributes=False) for node in helper.body[:-1]]
    branch_prefix = [
        ast.dump(node, include_attributes=False) for node in baseline_branch.body[:-2]
    ]
    baseline_event = baseline_branch.body[-2].value.args[0]
    helper_return = helper.body[-1]
    event_equal = (
        isinstance(helper_return, ast.Return)
        and isinstance(helper_return.value, ast.Tuple)
        and ast.dump(helper_return.value.elts[1], include_attributes=False)
        == ast.dump(baseline_event, include_attributes=False)
    )
    call_sites = [
        node
        for node in ast.walk(candidate_burst)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "_combat_apply_enemy_unequip_special"
    ]
    sync_calls = [
        node
        for node in ast.walk(helper)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "sync_equipment_instances_pure"
    ]
    containing = next(body for body in statement_lists(candidate_burst) if candidate_branch in body)
    index = containing.index(candidate_branch)
    ordered_prefix = containing[index - 4:index]
    ordering = (
        len(ordered_prefix) == 4
        and isinstance(ordered_prefix[0], ast.AugAssign)
        and isinstance(ordered_prefix[0].target, ast.Name)
        and ordered_prefix[0].target.id == "next_enemy_attack"
        and isinstance(ordered_prefix[1], ast.Assign)
        and isinstance(ordered_prefix[1].value, ast.Call)
        and isinstance(ordered_prefix[1].value.func, ast.Name)
        and ordered_prefix[1].value.func.id == "_combat_select_enemy_attack_pure"
        and is_unequip_branch(candidate_branch)
    )
    helper_names = {
        node.id for node in ast.walk(helper) if isinstance(node, ast.Name)
    }
    caller_shape = (
        len(candidate_branch.body) == 3
        and isinstance(candidate_branch.body[0], ast.Assign)
        and isinstance(candidate_branch.body[1], ast.Expr)
        and isinstance(candidate_branch.body[2], ast.Break)
    )
    result = {
        "status": "PASS",
        "baseline_sha256": sha(baseline_bytes),
        "candidate_sha256": sha(candidate_bytes),
        "other_definitions_and_module_statements_unchanged": baseline_other
        == candidate_other,
        "moved_transaction_AST_equal": helper_prefix == branch_prefix,
        "event_mapping_AST_equal": event_equal,
        "helper_calls": len(call_sites),
        "sync_calls_in_helper": len(sync_calls),
        "caller_keeps_schedule_then_selection": ordering,
        "caller_keeps_event_append_and_break": caller_shape,
        "helper_has_no_rng_or_loop_control_state": not helper_names
        & {"rng", "attack_spec", "attack_kind", "enemy_specials", "next_enemy_attack"},
    }
    assert all(
        value
        for key, value in result.items()
        if key
        not in {
            "baseline_sha256",
            "candidate_sha256",
            "helper_calls",
            "sync_calls_in_helper",
        }
    ), result
    assert result["helper_calls"] == result["sync_calls_in_helper"] == 1, result
    return result


def main():
    attempts = []

    def audit(event, values):
        if event == "import" and values[0].split(".")[0] in {
            "ankiscape",
            "pkg_alias",
            "tests",
        }:
            attempts.append(values[0])
            raise RuntimeError("Product import forbidden in static verification.")

    sys.addaudithook(audit)
    gate_path = Path(PINS["gate"]["path"])
    assert sha(gate_path.read_bytes()) == PINS["gate"]["sha256"]
    for row in PINS["tools"].values():
        assert sha(Path(row["path"]).read_bytes()) == row["sha256"]
    spec = importlib.util.spec_from_file_location("_static_slop_gate", gate_path)
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    assert {
        key: getattr(gate, key) for key in PINS["gate"]["thresholds"]
    } == PINS["gate"]["thresholds"]
    baseline_bytes = gzip.decompress((EVIDENCE / "baseline-engine.py.gz").read_bytes())
    candidate_bytes = (ROOT / FILES[0]).read_bytes()
    assert sha(baseline_bytes) == PINS["baseline_sha256"]
    proof = structural_proof(baseline_bytes, candidate_bytes)
    raw = []
    original_run_tool = gate.run_tool

    def capture(argv, tool):
        result = original_run_tool(argv, tool)
        row = {
            "argv": argv,
            "tool": tool,
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
        if tool == "complexipy":
            directory = Path(argv[argv.index("--output") + 1])
            row["reports"] = {
                path.name: path.read_text() for path in directory.glob("*.json")
            }
        raw.append(row)
        return result

    with tempfile.TemporaryDirectory(prefix="enemy-unequip-static-") as directory:
        scratch = Path(directory)
        base = scratch / "base"
        candidate = scratch / "candidate"
        (base / FILES[0]).parent.mkdir(parents=True)
        (base / FILES[0]).write_bytes(baseline_bytes)
        for name in FILES:
            (candidate / name).parent.mkdir(parents=True, exist_ok=True)
            (candidate / name).write_bytes((ROOT / name).read_bytes())
        metrics = {}
        with patch.object(gate, "run_tool", side_effect=capture):
            for label, tree in (("base", base), ("candidate", candidate)):
                metrics[label] = {
                    "ccn": gate.ccn_by_function(tree),
                    "cognitive": gate.cognitive_by_function(tree),
                    "halstead": gate.halstead_by_function(tree),
                    "layout": gate.pep8_layout_findings(tree),
                }
        failures = {
            name: gate.ratchet(
                metrics["candidate"][name], metrics["base"][name], limit
            )
            for name, limit in (
                ("ccn", gate.CCN_MAX),
                ("cognitive", gate.COGNITIVE_MAX),
                ("halstead", gate.HALSTEAD_MAX),
            )
        }
        failures["layout"] = gate.layout_ratchet(
            metrics["candidate"]["layout"], metrics["base"]["layout"]
        )
        base_lines = gate.line_counts(base, FILES)
        candidate_lines = gate.line_counts(candidate, FILES)
        failures["file_growth"] = [
            (name, count)
            for name, count in candidate_lines.items()
            if count > gate.FILE_LINES_MAX and count > base_lines.get(name, 0)
        ]
    serial_metrics = {
        label: {
            kind: {
                "|".join(key): value for key, value in values.items()
            }
            if not isinstance(values, Counter)
            else {"|".join(key): value for key, value in values.items()}
            for kind, values in table.items()
        }
        for label, table in metrics.items()
    }
    result = {
        "status": "PASS" if not any(failures.values()) else "FAIL",
        "source_sha256": {
            path: sha((ROOT / path).read_bytes()) for path in FILES
        },
        "metrics": serial_metrics,
        "lines": {"base": base_lines, "candidate": candidate_lines},
        "failures": failures,
        "gate_sha256": PINS["gate"]["sha256"],
        "thresholds": PINS["gate"]["thresholds"],
        "product_import_attempts": attempts,
        "python": sys.executable,
        "python_version": sys.version,
    }
    (EVIDENCE / "structural-proof.json").write_text(
        json.dumps(proof, indent=2) + "\n"
    )
    (EVIDENCE / "static-metrics.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    (EVIDENCE / "static-raw.json.gz").write_bytes(
        gzip.compress(json.dumps(raw, indent=2).encode(), mtime=0)
    )
    (EVIDENCE / "candidate-engine.py.gz").write_bytes(
        gzip.compress(candidate_bytes, mtime=0)
    )
    patch_text = "".join(
        difflib.unified_diff(
            baseline_bytes.decode().splitlines(keepends=True),
            candidate_bytes.decode().splitlines(keepends=True),
            fromfile="a/logic_pure/logic_pure_combat_engine.py",
            tofile="b/logic_pure/logic_pure_combat_engine.py",
        )
    ).encode()
    (EVIDENCE / "engine-full.diff.gz").write_bytes(
        gzip.compress(patch_text, mtime=0)
    )
    assert not any(failures.values()), failures
    assert not attempts
    print(
        json.dumps(
            {
                "status": result["status"],
                "failures": failures,
                "sources": result["source_sha256"],
                "lines": result["lines"],
                "structural_proof": proof,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
