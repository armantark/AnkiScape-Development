"""Exercise carried-keep-settlement runtime safety stops without product imports or remote calls."""

import argparse
import base64
import gzip
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import types
from unittest.mock import patch


def load_harness(path):
    module = types.ModuleType("carried_keep_settlement_runtime_harness_under_test")
    raw = gzip.decompress(path.read_bytes())
    exec(compile(raw, "runtime-harness.py", "exec"), module.__dict__)
    return module


def invocation(root, output):
    return types.SimpleNamespace(
        root=root,
        output=output,
        lane="plain",
        kind="focused",
        timeout=1,
    )


def failed_comparison_is_retained(harness, root):
    output = root / "failed-comparison"
    output.mkdir()
    args = invocation(root, output)
    args.kind = "comparison"
    identity = {"run_id": "failed-stub", "log_path": "/stub/log", "report_path": "/stub/report"}
    raw = gzip.compress(json.dumps({"status": "FAIL", "cases": [{"route_pass": False}]}).encode())
    stub = types.SimpleNamespace(
        REMOTE_ROOT=root, REMOTE_REPO=root, REMOTE_GAME_MAIN=root,
        REMOTE_DARKAN=root, REMOTE_PLAIN_SITE=root,
        _pending_path=lambda: root / "absent-pending",
        _preflight=lambda lane: None, _sync=lambda source: None,
        _reconcile_pending_run=lambda: None,
    )

    def ssh(text, *, label, repeat_safe=False):
        if label.endswith("exact-run report"):
            return "1\n"
        if label.endswith("comparison bytes"):
            return base64.b64encode(raw).decode()
        raise AssertionError(f"unexpected inert SSH label: {label}")

    stub._ssh = ssh
    harness.save(output / "identity.json", {"pending": identity})
    with patch.object(harness, "local_sources", return_value={}), patch.object(
        harness, "capture_guard"
    ), patch.object(harness, "launch_one", return_value=(1, "failed stub log")):
        try:
            harness.run_one(args, stub, {})
        except RuntimeError as error:
            if "exact run failed with exit 1" not in str(error):
                raise
        else:
            raise AssertionError("failed comparison was accepted")
    if (output / "comparison.json.gz").read_bytes() != raw:
        raise AssertionError("failed comparison bytes were not retained exactly")
    if (output / "accepted.json").exists():
        raise AssertionError("failed comparison wrote acceptance")
    return {"case": "failed-comparison-retained", "exact_bytes_retained": True,
            "accepted": False, "actual_remote_calls": 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--harness", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    before = sorted(
        name
        for name in sys.modules
        if name == "pkg_alias" or name.split(".")[0] in {"ankiscape", "tests"}
    )
    harness = load_harness(args.harness)
    results = []
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        pending = root / "pending.json"

        class StubRemote:
            def __init__(self):
                self.calls = []

            def _pending_path(self):
                return pending

            def _preflight(self, lane):
                self.calls.append("preflight")

            def _sync(self, source):
                self.calls.append("sync")

        existing = StubRemote()
        pending.write_text(
            json.dumps(
                {"run_id": "existing", "log_path": "log", "report_path": "report"}
            )
        )
        try:
            harness.run_one(
                invocation(root / "unused", root / "existing-output"),
                existing,
                {"sentinel": "hash"},
            )
        except RuntimeError as error:
            if existing.calls:
                raise AssertionError("existing pending work allowed remote setup")
            results.append(
                {"case": "run-one-existing-pending", "stopped": True, "error": str(error)}
            )
        else:
            raise AssertionError("run_one did not stop for existing pending work")
        pending.unlink()

        mismatched = root / "mismatched"
        (mismatched / harness.EVIDENCE).mkdir(parents=True)
        (mismatched / harness.INVENTORY).write_bytes(b"not-the-pinned-inventory")
        bad_source = StubRemote()
        try:
            harness.run_one(
                invocation(mismatched, root / "bad-source-output"),
                bad_source,
                {"sentinel": "hash"},
            )
        except ValueError as error:
            if bad_source.calls:
                raise AssertionError("bad local source allowed remote setup")
            results.append(
                {"case": "run-one-bad-source", "stopped": True, "error": str(error)}
            )
        else:
            raise AssertionError("run_one did not stop for a bad local inventory")

        racing = StubRemote()

        def dangerous_reconcile():
            racing.calls.append("dangerous-reconcile")
            pending.unlink()

        def racing_sync(source):
            racing.calls.append("sync")
            pending.write_text(
                json.dumps(
                    {"run_id": "racing", "log_path": "log", "report_path": "report"}
                )
            )
            racing._reconcile_pending_run()

        racing._reconcile_pending_run = dangerous_reconcile
        racing._sync = racing_sync
        with patch.object(harness, "local_sources", return_value={"sentinel": "hash"}):
            try:
                harness.run_one(
                    invocation(root / "pinned", root / "racing-output"),
                    racing,
                    {"sentinel": "hash"},
                )
            except RuntimeError as error:
                if racing.calls != ["preflight", "sync"]:
                    raise AssertionError(f"unexpected racing-pending calls: {racing.calls}")
                if not pending.exists():
                    raise AssertionError("strict sync guard cleared the racing pending record")
                results.append(
                    {
                        "case": "run-one-pending-during-sync",
                        "stopped": True,
                        "pending_preserved": True,
                        "error": str(error),
                    }
                )
            else:
                raise AssertionError("run_one allowed pending work that appeared during sync")
        pending.unlink()

        launch_output = root / "launch"
        launch_output.mkdir()
        launch_pending = root / "launch-pending.json"
        expected = {
            "run_id": "plain-stub-proof",
            "log_path": "/stub/log",
            "report_path": "/stub/report",
        }
        launch_stub = types.SimpleNamespace()
        launch_stub._pending_path = lambda: launch_pending
        launch_stub._remote_lane_command = lambda lane: "unpatched"
        launch_seen = {"value": False}

        def original_ssh(text, *, label, repeat_safe=False):
            identity = json.loads((launch_output / "identity.json").read_text())
            if identity != {"lane": "plain", "kind": "focused", "pending": expected}:
                raise AssertionError("identity was not durable before the launch call")
            launch_seen["value"] = True
            return ""

        def stream(lane, *, timeout, poll_interval):
            launch_pending.write_text(json.dumps(expected))
            launch_stub._ssh("stub launch", label="remote lane launch")
            return 0, "stub log"

        launch_stub._ssh = original_ssh
        launch_stub._stream_remote_run = stream
        code, log = harness.launch_one(
            invocation(root, launch_output),
            launch_stub,
            "stub command",
        )
        if (code, log, launch_seen["value"]) != (0, "stub log", True):
            raise AssertionError("stub launch did not complete as expected")
        results.append(
            {
                "case": "identity-before-launch",
                "identity_durable_before_launch": True,
                "actual_remote_calls": 0,
            }
        )
        results.append(failed_comparison_is_retained(harness, root))
    after = sorted(
        name
        for name in sys.modules
        if name == "pkg_alias" or name.split(".")[0] in {"ankiscape", "tests"}
    )
    if after != before:
        raise AssertionError(f"product import set changed: {before} -> {after}")
    report = {
        "status": "PASS",
        "inert": True,
        "actual_remote_calls": 0,
        "product_imports_before": before,
        "product_imports_after": after,
        "cases": results,
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
