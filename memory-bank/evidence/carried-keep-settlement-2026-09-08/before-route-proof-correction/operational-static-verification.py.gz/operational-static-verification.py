"""Measure pinned selector sources with fixed instruments and no product imports."""

import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
from unittest.mock import patch

root = Path(sys.argv[1]).resolve()
evidence = root / "memory-bank/evidence/carried-keep-settlement-2026-09-08"
pins = json.loads((evidence / "static-instrument-pins.json").read_text())
pins["sources"] = {
    name: hashlib.sha256(gzip.decompress((evidence / (name + ".gz")).read_bytes())).hexdigest()
    for name in ("runtime-harness.py", "runtime-safety-check.py")
}
raw_inventory = (evidence / "source-inventory.json.gz").read_bytes()
assert hashlib.sha256(raw_inventory).hexdigest() == pins["inventory_sha256"]
inventory = json.loads(gzip.decompress(raw_inventory))["files"]
attempts = []


def forbid_product(event, arguments):
    if event == "import" and arguments[0].split(".")[0] in {"ankiscape", "pkg_alias", "tests"}:
        attempts.append(arguments[0])
        raise RuntimeError("Product import forbidden in static verification.")


sys.addaudithook(forbid_product)
for name, expected in inventory.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for name, tool in pins["tools"].items():
    assert Path(shutil.which(name)).resolve() == Path(tool["resolved_path"])
    assert hashlib.sha256(Path(tool["path"]).read_bytes()).hexdigest() == tool["sha256"]
gate_path = Path(pins["gate"]["path"])
assert hashlib.sha256(gate_path.read_bytes()).hexdigest() == pins["gate"]["sha256"]
spec = importlib.util.spec_from_file_location("_fixed_selector_gate", gate_path)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
assert {name: getattr(gate, name) for name in pins["gate"]["thresholds"]} == pins["gate"]["thresholds"]
assert gate.PEP8_LAYOUT_CODES == pins["gate"]["layout_codes"]
raw = []
original_run = gate.run_tool


def capture(argv, tool):
    result = original_run(argv, tool)
    row = {"argv": argv, "tool": tool, "exit_code": result.returncode,
           "stdout": result.stdout, "stderr": result.stderr}
    if tool == "complexipy":
        output = Path(argv[argv.index("--output") + 1])
        row["reports"] = {path.name: path.read_text() for path in output.glob("*.json")}
    raw.append(row)
    (evidence / "operational-static-measurements.raw.json.gz").write_bytes(
        gzip.compress(json.dumps(raw, indent=2).encode(), mtime=0)
    )
    return result


baselines = {name: "original-" + name + ".gz" for name in pins["sources"]}
metrics = {}
with tempfile.TemporaryDirectory(prefix="selector-fixed-static-") as temporary:
    trees = {label: Path(temporary) / label for label in ("base", "candidate")}
    for label, tree in trees.items():
        for name in pins["sources"]:
            target = tree / name
            target.parent.mkdir(parents=True, exist_ok=True)
            if label == "candidate":
                target.write_bytes(gzip.decompress((evidence / (name + ".gz")).read_bytes()))
            elif name in baselines:
                target.write_bytes(gzip.decompress((evidence / baselines[name]).read_bytes()))
        with patch.object(gate, "run_tool", side_effect=capture):
            metrics[label] = {name: function(tree) for name, function in (
                ("ccn", gate.ccn_by_function), ("cognitive", gate.cognitive_by_function),
                ("halstead", gate.halstead_by_function), ("layout", gate.pep8_layout_findings),
            )}
    failures = {name: gate.ratchet(metrics["candidate"][name], metrics["base"][name], limit)
                for name, limit in (("ccn", gate.CCN_MAX), ("cognitive", gate.COGNITIVE_MAX),
                                    ("halstead", gate.HALSTEAD_MAX))}
    failures["layout"] = gate.layout_ratchet(metrics["candidate"]["layout"], metrics["base"]["layout"])
    lines = {label: gate.line_counts(tree, list(pins["sources"])) for label, tree in trees.items()}
    failures["file_growth"] = [(name, count) for name, count in lines["candidate"].items()
                               if count > gate.FILE_LINES_MAX and count > lines["base"].get(name, 0)]
for name, expected in inventory.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
assert hashlib.sha256(gate_path.read_bytes()).hexdigest() == pins["gate"]["sha256"]
report = {"status": "FAIL" if any(failures.values()) else "PASS", "failures": failures,
          "lines": lines, "sources": pins["sources"], "gate": pins["gate"], "tools": pins["tools"],
          "inventory_sha256": pins["inventory_sha256"], "source_entries_verified": len(inventory),
          "product_import_attempts": attempts,
          "metrics": {label: {kind: {"|".join(key): value for key, value in values.items()}
                                for kind, values in table.items()} for label, table in metrics.items()}}
(evidence / "operational-static-measurements.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "failures": failures, "lines": lines}, indent=2))
if any(failures.values()):
    raise SystemExit(1)
