import json
import runpy
import sys

attempts = []

def audit(event, args):
    if event == "import" and args[0].split(".")[0] in {"ankiscape", "pkg_alias", "tests"}:
        attempts.append(args[0])
        raise RuntimeError("Product import attempted during source preflight.")

sys.addaudithook(audit)
sys.argv = sys.argv[1:]
try:
    runpy.run_path(sys.argv[0], run_name="__main__")
finally:
    loaded = sorted(name for name in sys.modules if name.split(".")[0] in {"ankiscape", "pkg_alias", "tests"})
    print(json.dumps({"product_import_attempts": attempts, "product_modules_loaded": loaded}))
