from pathlib import Path
import ast
import copy
import csv
import gzip
import hashlib
import io
import json

root = Path.cwd()
scratch = Path('/tmp/ankiscape-enemy-attack-static-2026-09-05')
ev = root / 'memory-bank/evidence/combat-enemy-attack-rolls-2026-09-05'
raw = json.loads((scratch / 'static-raw.json').read_text())
files = {
    'baseline': scratch / 'baseline.py',
    'engine': root / 'logic_pure/logic_pure_combat_engine.py',
    'tests': root / 'tests/combat/test_enemy_attack_rolls.py',
    'probe': root / 'tools/combat/compare_enemy_attack_rolls.py',
}
metrics = {}
for label, path in files.items():
    values = {}
    for row in csv.reader(io.StringIO(raw[label]['lizard']['stdout'])):
        values[row[7]] = {'ccn': int(row[1]), 'physical_lines': int(row[4])}
    for row in raw[label]['complexipy']['reports']['complexipy-results.json']:
        values.setdefault(row['function_name'], {})['cognitive'] = row['complexity']
    radon = next(iter(json.loads(raw[label]['radon']['stdout']).values()))
    for name, row in radon['functions'].items():
        values.setdefault(name, {})['halstead_difficulty'] = row['difficulty']
    metrics[label] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'lines': len(path.read_text().splitlines()), 'metrics': values}

def definitions(node, prefix=''):
    result = {}
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            name = prefix + child.name
            result[name] = child
            result.update(definitions(child, name + '.'))
        else:
            result.update(definitions(child, prefix))
    return result

base_tree = ast.parse(files['baseline'].read_text())
after_tree = ast.parse(files['engine'].read_text())
base_defs, after_defs = definitions(base_tree), definitions(after_tree)
dump = lambda value: ast.dump(value, include_attributes=False)
changed = [name for name in base_defs if dump(base_defs[name]) != dump(after_defs[name])]
added = sorted(set(after_defs) - set(base_defs))
assert changed == ['apply_combat_burst_pure']
assert added == ['_combat_enemy_attack_rolls']
assert all(name in after_defs for name in base_defs)
assert [dump(n) for n in base_tree.body if not isinstance(n, (ast.FunctionDef, ast.ClassDef))] == [dump(n) for n in after_tree.body if not isinstance(n, (ast.FunctionDef, ast.ClassDef))]
helper = after_defs['_combat_enemy_attack_rolls']
assert [arg.arg for arg in helper.args.args] == ['data', 'enemy', 'combat_class', 'style_id', 'player_totals', 'enemy_totals', 'prayer_effects', 'enemy_attack_factor', 'weakening_equipment', 'weakening_active']
assert [n.id for n in helper.body[-1].value.elts] == ['enemy_attack_roll', 'player_defence_roll', 'enemy_accuracy', 'enemy_max_hit']

def targets(node):
    if not isinstance(node, ast.Assign):
        return []
    return [n.id for target in node.targets for n in ast.walk(target) if isinstance(n, ast.Name)]

base_burst = base_defs['apply_combat_burst_pure']
initial = base_burst.body
first = next(i for i, node in enumerate(initial) if targets(node) == ['enemy_style'])
last = next(i for i, node in enumerate(initial) if targets(node) == ['protective_equipment', 'protection_active'])
weak_names = ['weakening_equipment', 'weakening_active']
initial_formula = [node for node in initial[first:last] if targets(node) != weak_names]
assert [dump(n) for n in initial_formula] == [dump(n) for n in helper.body[:-1]]
retaliation = next(node for node in ast.walk(base_burst) if isinstance(node, ast.If) and any(targets(child) == ['attack_enemy'] for child in node.body)).body
first = next(i for i, node in enumerate(retaliation) if targets(node) == ['enemy_style'])
last = next(i for i, node in enumerate(retaliation) if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == '_combat_advance_dragonfire_effects')
class RenameEnemy(ast.NodeTransformer):
    def visit_Name(self, node):
        if node.id == 'attack_enemy':
            node.id = 'enemy'
        return node
normal_retaliation = [RenameEnemy().visit(copy.deepcopy(n)) for n in retaliation[first:last]]
assert [dump(n) for n in normal_retaliation] == [dump(n) for n in helper.body[:-1]]
for burst in [base_burst, after_defs['apply_combat_burst_pure']]:
    assert sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == '_combat_weakening_equipment_state' for n in ast.walk(burst)) == 1
assert sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == '_combat_enemy_attack_rolls' for n in ast.walk(after_defs['apply_combat_burst_pure'])) == 2
summary = {'status': 'PASS', 'metrics': metrics, 'existing_definition_count': len(base_defs), 'unchanged_existing_definitions': sorted(set(base_defs) - set(changed)), 'changed_existing_definitions': changed, 'added_definitions': added, 'other_module_statements_unchanged': True, 'helper_matches_initial_formula_without_once_sampled_weakening_lookup': True, 'helper_matches_retaliation_formula_after_enemy_name_normalization': True, 'weakening_lookup_count_before_after': [1, 1], 'helper_call_count': 2}
(ev / 'static-metrics.json').write_text(json.dumps(summary, indent=2) + '\n')
for path in [scratch / 'static-raw.json', Path(__file__)]:
    (ev / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for label in ['baseline', 'engine']:
    print(label, metrics[label]['lines'], metrics[label]['metrics']['apply_combat_burst_pure'])
print('helper', metrics['engine']['metrics']['_combat_enemy_attack_rolls'])
print('existing_definitions', len(base_defs), 'unchanged', len(base_defs) - len(changed))
for label in ['tests', 'probe']:
    print(label, {key: max(row.get(key, 0) for row in metrics[label]['metrics'].values()) for key in ['ccn', 'cognitive', 'halstead_difficulty']})
