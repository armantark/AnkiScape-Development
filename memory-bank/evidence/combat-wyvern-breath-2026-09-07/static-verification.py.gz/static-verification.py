from pathlib import Path
import ast, gzip, hashlib, importlib.util, json, os, subprocess, sys, tempfile
from unittest.mock import patch

if sys.flags.optimize or 'PYTHONOPTIMIZE' in os.environ:
    raise SystemExit('Static verification requires assertions enabled.')
root = Path.cwd()
ev = root / 'memory-bank/evidence/combat-wyvern-breath-2026-09-07'
pins = json.loads((ev / 'static-instrument-pins.json').read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
attempts = []
def audit(event, values):
    if event == 'import' and values[0].split('.')[0] in {'ankiscape', 'pkg_alias', 'tests'}:
        attempts.append(values[0])
        raise RuntimeError('Product import forbidden in static verification.')
sys.addaudithook(audit)
gate_path = Path(pins['gate']['path'])
assert sha(gate_path.read_bytes()) == pins['gate']['sha256']
for row in pins['tools'].values():
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
spec = importlib.util.spec_from_file_location('_static_slop_gate', gate_path)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
assert {key: getattr(gate, key) for key in pins['gate']['thresholds']} == pins['gate']['thresholds']
files = ['logic_pure/logic_pure_combat_engine.py', 'logic_pure/logic_pure_combat_specials.py', 'tools/combat/compare_wyvern_breath.py', 'tools/combat/check_wyvern_breath_guards.py']
inventory_path = ev / 'source-inventory.json.gz'
assert sha(inventory_path.read_bytes()) == pins['inventory_sha256']
inventory = json.loads(gzip.decompress(inventory_path.read_bytes()))
sources_before = {name: sha((root / name).read_bytes()) for name in inventory}
assert sources_before == inventory, 'Source inventory differs before static verification.'
assert sha((ev / 'manifest.json').read_bytes()) == pins['manifest_sha256']
raw = []
run_tool = gate.run_tool
def capture(argv, tool):
    result = run_tool(argv, tool)
    row = {'argv': argv, 'tool': tool, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    if tool == 'complexipy':
        directory = Path(argv[argv.index('--output') + 1])
        row['reports'] = {p.name: p.read_text() for p in directory.glob('*.json')}
    raw.append(row)
    return result

with tempfile.TemporaryDirectory(prefix='wyvern-breath-static-') as directory:
    scratch = Path(directory)
    base, candidate = scratch / 'base', scratch / 'candidate'
    base.mkdir()
    candidate.mkdir()
    (base / files[0]).parent.mkdir(parents=True)
    (base / files[0]).write_bytes(gzip.decompress((ev / 'baseline-engine.py.gz').read_bytes()))
    for name in files:
        (candidate / name).parent.mkdir(parents=True, exist_ok=True)
        (candidate / name).write_bytes((root / name).read_bytes())
    ast_files = {}
    for tree in (base, candidate):
        for path in tree.rglob('*.py'):
            ast.parse(path.read_bytes(), filename=str(path))
            ast_files[str(path.relative_to(scratch))] = sha(path.read_bytes())
    baseline_bytes = (base / files[0]).read_bytes()
    candidate_bytes = (candidate / files[0]).read_bytes()
    assert sha(baseline_bytes) == pins['baseline_sha256']
    assert sha(candidate_bytes) == pins['candidate_sha256']
    assert sha((candidate / files[1]).read_bytes()) == pins['specials_sha256']
    patch_bytes = gzip.decompress((ev / 'product-full.diff.gz').read_bytes())
    assert sha(patch_bytes) == pins['patch_sha256']
    restore = scratch / 'restore'
    (restore / files[0]).parent.mkdir(parents=True)
    (restore / files[0]).write_bytes(baseline_bytes)
    patch_path = scratch / 'engine.diff'
    patch_path.write_bytes(patch_bytes)
    restoration = {}
    for label, flags, expected in [('forward', [], candidate_bytes), ('reverse', ['-R'], baseline_bytes)]:
        command = ['patch', *flags, '-p1', '--batch', '-i', str(patch_path)]
        process = subprocess.run(command, cwd=restore, capture_output=True, text=True)
        row = {'tool': 'patch', 'direction': label, 'argv': command,
               'exit_code': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr}
        raw.append(row)
        (ev / 'static-raw.json.gz').write_bytes(gzip.compress(json.dumps(raw, indent=2).encode(), mtime=0))
        assert process.returncode == 0, row
        restored = (restore / files[0]).read_bytes()
        restoration[label] = {'sha256': sha(restored), 'expected_sha256': sha(expected)}
        assert restored == expected, restoration[label]
        specials = restore / files[1]
        if label == 'forward':
            assert specials.read_bytes() == (candidate / files[1]).read_bytes()
            restoration[label]['specials_sha256'] = sha(specials.read_bytes())
        else:
            assert not specials.exists(), 'Reverse restoration must remove the added module.'
            restoration[label]['specials'] = 'ABSENT'
    metrics = {}
    with patch.object(gate, 'run_tool', side_effect=capture):
        for label, tree in [('base', base), ('candidate', candidate)]:
            metrics[label] = {name: function(tree) for name, function in [('ccn', gate.ccn_by_function), ('cognitive', gate.cognitive_by_function), ('halstead', gate.halstead_by_function), ('layout', gate.pep8_layout_findings)]}
    failures = {name: gate.ratchet(metrics['candidate'][name], metrics['base'][name], limit) for name, limit in [('ccn', gate.CCN_MAX), ('cognitive', gate.COGNITIVE_MAX), ('halstead', gate.HALSTEAD_MAX)]}
    failures['layout'] = gate.layout_ratchet(metrics['candidate']['layout'], metrics['base']['layout'])
    base_lines, candidate_lines = gate.line_counts(base, files), gate.line_counts(candidate, files)
    failures['file_growth'] = [(name, count) for name, count in candidate_lines.items() if count > gate.FILE_LINES_MAX and count > base_lines.get(name, 0)]
    sources_after = {name: sha((root / name).read_bytes()) for name in inventory}
    assert sources_after == inventory, 'Source inventory differs after static verification.'
    modules = sorted(name for name in sys.modules if name.split('.')[0] in {'ankiscape', 'pkg_alias', 'tests'})
    assert not modules, modules
    result = {'ast_files': ast_files, 'restoration': restoration, 'sources_before': sources_before, 'sources_after': sources_after, 'product_modules': modules, 'status': 'PASS' if not any(failures.values()) else 'FAIL', 'source_sha256': {p: sha((root / p).read_bytes()) for p in files}, 'metrics': {label: {kind: {'|'.join(key): value for key, value in values.items()} for kind, values in table.items()} for label, table in metrics.items()}, 'lines': {'base': base_lines, 'candidate': candidate_lines}, 'failures': failures, 'gate_sha256': pins['gate']['sha256'], 'thresholds': pins['gate']['thresholds'], 'product_import_attempts': attempts, 'python': sys.executable, 'python_version': sys.version}
    (ev / 'static-metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    (ev / 'static-raw.json.gz').write_bytes(gzip.compress(json.dumps(raw, indent=2).encode(), mtime=0))
    assert not any(failures.values()), failures
    assert not attempts
    print(json.dumps({'status': result['status'], 'failures': failures, 'sources': result['source_sha256'], 'lines': result['lines']}, indent=2))
