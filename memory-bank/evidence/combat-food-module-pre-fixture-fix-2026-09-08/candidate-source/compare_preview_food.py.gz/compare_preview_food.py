"""Compare complete combat previews with the frozen canonical engine."""

import argparse
import base64
from copy import deepcopy
import gzip
import hashlib
import json
import os
from pathlib import Path
import pickle
import sys
import types


BASELINE_COMMIT = "6dacde5486c72e73ca170c039bf8207dec22ac81"
BASELINE_ENGINE_SHA256 = (
    "5f641672a316655fa63a25ce9ea5d24a80645f362f338df1929a8808a253936b"
)
BASELINE_ENGINE_STORED_SHA256 = (
    "1e3f72610e12711057b32af3e07bfbdb41be10b17228036750ff390fdadd90b6"
)
BASELINE_SUPPLIES_SHA256 = (
    "c49dca01ceca5432424a870403109bdea656b363ea804d2d769e9ebc024afbcc"
)
BASELINE_SUPPLIES_STORED_SHA256 = (
    "503aed6ea0c3510268ef45d75573e945e23baf04536d76aac4eafc0f309bdf4b"
)
BASELINE_MODEL_SHA256 = (
    "ae8a62d3120eb27b2bc8869c63eb84bfd586f1dd29e6e914d03973c1ebe0ad64"
)
BASELINE_MODEL_STORED_SHA256 = (
    "ef0bacc967010c3ad6bf51812ebfc10f1a3e52b7505bb0959925c6049322bca8"
)
ENGINE_PATH = "logic_pure/logic_pure_combat_engine.py"
SUPPLIES_PATH = "logic_pure/logic_pure_combat_supplies.py"
MODEL_PATH = "logic_pure/logic_pure_combat_model.py"
FOOD_PATH = "logic_pure/logic_pure_combat_food.py"
TEST_PATH = "tests/combat/test_preview_food.py"


def source_guard(root, inventory, inventory_sha256):
    inventory_bytes = inventory.read_bytes()
    if hashlib.sha256(inventory_bytes).hexdigest() != inventory_sha256:
        raise ValueError("Inventory hash differs; product imports not started.")
    expected = json.loads(gzip.decompress(inventory_bytes))
    for required in (
        ENGINE_PATH,
        SUPPLIES_PATH,
        MODEL_PATH,
        FOOD_PATH,
        TEST_PATH,
    ):
        if required not in expected:
            raise ValueError(
                f"Inventory omits {required}; product imports not started."
            )
    actual = {}
    for name, pin in expected.items():
        source = root / name
        if not source.is_file():
            raise ValueError(
                f"Source missing: {name}; product imports not started."
            )
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        if digest != pin:
            raise ValueError(
                f"Source differs: {name}; product imports not started."
            )
        actual[name] = digest

    evidence = root / "memory-bank/evidence/combat-food-module-2026-09-08"
    stored_engine = (evidence / "baseline-engine.py.gz").read_bytes()
    if hashlib.sha256(stored_engine).hexdigest() != BASELINE_ENGINE_STORED_SHA256:
        raise ValueError(
            "Stored engine baseline differs; product imports not started."
        )
    baseline_engine = gzip.decompress(stored_engine)
    if hashlib.sha256(baseline_engine).hexdigest() != BASELINE_ENGINE_SHA256:
        raise ValueError(
            "Engine baseline source differs; product imports not started."
        )

    stored_supplies = (evidence / "baseline-supplies.py.gz").read_bytes()
    if (
        hashlib.sha256(stored_supplies).hexdigest()
        != BASELINE_SUPPLIES_STORED_SHA256
    ):
        raise ValueError(
            "Stored supplies baseline differs; product imports not started."
        )
    if (
        hashlib.sha256(gzip.decompress(stored_supplies)).hexdigest()
        != BASELINE_SUPPLIES_SHA256
    ):
        raise ValueError(
            "Supplies baseline source differs; product imports not started."
        )

    stored_model = (evidence / "baseline-model.py.gz").read_bytes()
    if hashlib.sha256(stored_model).hexdigest() != BASELINE_MODEL_STORED_SHA256:
        raise ValueError(
            "Stored model baseline differs; product imports not started."
        )
    if (
        hashlib.sha256(gzip.decompress(stored_model)).hexdigest()
        != BASELINE_MODEL_SHA256
    ):
        raise ValueError(
            "Model baseline source differs; product imports not started."
        )
    return actual, baseline_engine


def cases():
    from tests.combat.test_preview_food import preview_food_player
    from tests.test_combat_logic import _player

    missing_selection = preview_food_player(inventory={"Shrimps": 1})
    missing_selection.pop("combat_auto_eat_food")
    yield "selection:missing-default", missing_selection, "giant_rat", {
        "outcome": "return",
        "risk_band": "Food advised",
        "state": "Ready",
    }
    yield "selection:empty", preview_food_player(
        inventory={"Shrimps": 1}, combat_auto_eat_food=[]
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Death possible",
        "state": "Ready",
    }
    yield "selection:none", preview_food_player(
        inventory={"Shrimps": 1}, combat_auto_eat_food=None
    ), "giant_rat", {
        "outcome": "raise",
        "exception": "builtins.TypeError",
    }
    yield "catalog:unsupported", preview_food_player(
        inventory={"Burnt fish": 10},
        combat_auto_eat_food=["Burnt fish"],
        combat_supply_loadout={"food": {"Burnt fish": 10}},
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Death possible",
        "state": "Ready",
    }
    yield "source:bank-ready", preview_food_player(
        inventory={"Shrimps": 1}
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Food advised",
        "state": "Ready",
    }
    yield "source:bank-gated-during-encounter", preview_food_player(
        inventory={"Shrimps": 1},
        combat_encounter={"target_id": "giant_rat"},
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Death possible",
        "state": "Fighting",
    }
    yield "source:loadout-during-encounter", preview_food_player(
        inventory={},
        combat_supply_loadout={"food": {"Shrimps": 1}},
        combat_encounter={"target_id": "giant_rat"},
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Food advised",
        "state": "Fighting",
    }
    yield "count:negative-clamped", preview_food_player(
        inventory={"Shrimps": -5},
        combat_supply_loadout={"food": {"Shrimps": -3}},
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Death possible",
        "state": "Ready",
    }
    yield "inventory:invalid-truthy-ready", preview_food_player(
        inventory="truthy invalid inventory"
    ), "giant_rat", {
        "outcome": "raise",
        "exception": "builtins.AttributeError",
    }
    yield "inventory:invalid-truthy-gated", preview_food_player(
        inventory="truthy invalid inventory",
        combat_encounter={"target_id": "giant_rat"},
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Death possible",
        "state": "Fighting",
    }
    yield "selection:unhashable", preview_food_player(
        combat_auto_eat_food=[[]]
    ), "giant_rat", {
        "outcome": "raise",
        "exception": "builtins.TypeError",
    }
    yield "selection:short-circuit-before-unhashable", preview_food_player(
        inventory={"Shrimps": 1}, combat_auto_eat_food=["Shrimps", []]
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Food advised",
        "state": "Ready",
    }
    yield "risk:safe-threshold", preview_food_player(
        combat_lifepoints=100,
        combat_auto_eat_food=[],
    ), "giant_rat", {
        "outcome": "return",
        "risk_band": "Safe",
        "state": "Ready",
    }
    yield "risk:wilderness-overwrite", _player(
        current_combat_target="earth_warrior",
        constitution_level=99,
        combat_lifepoints=990,
        combat_auto_eat_food=[],
        equipment={
            "weapon": "Rune sword",
            "body": "Rune platebody",
            "head": "Rune full helm",
            "shield": "Iron kiteshield",
            "cape": "Cape",
        },
    ), "earth_warrior", {
        "outcome": "return",
        "risk_band": "Wilderness risk",
        "state": "Wilderness risk",
    }
    yield "risk:poison-escalation", _player(
        combat_auto_eat_food=[]
    ), "poison_scorpion", {
        "outcome": "return",
        "risk_band": "Food advised",
        "state": "Ready",
    }


def capture(function, player, target_id):
    from ankiscape.core.constants import EQUIPMENT_DATA
    from ankiscape.data.combat_data import COMBAT_ENEMY_DATA

    supplied_player = deepcopy(player)
    supplied_enemies = deepcopy(COMBAT_ENEMY_DATA)
    supplied_equipment = deepcopy(EQUIPMENT_DATA)
    try:
        result = function(
            supplied_player,
            target_id,
            supplied_enemies,
            supplied_equipment,
        )
    except Exception as error:  # preserve the preview's public failure contract
        outcome = {
            "outcome": "raise",
            "exception": (
                f"{type(error).__module__}.{type(error).__qualname__}"
            ),
            "args": deepcopy(error.args),
            "message": str(error),
        }
    else:
        outcome = {"outcome": "return", "value": deepcopy(result)}
    return {
        **outcome,
        "inputs_unchanged": {
            "player": supplied_player == player,
            "enemies": supplied_enemies == COMBAT_ENEMY_DATA,
            "equipment": supplied_equipment == EQUIPMENT_DATA,
        },
    }


def route_observation(captured):
    if captured["outcome"] == "raise":
        return {
            "outcome": "raise",
            "exception": captured["exception"],
        }
    return {
        "outcome": "return",
        "risk_band": captured["value"]["risk_band"],
        "state": captured["value"]["state"],
    }


def compare(baseline_bytes):
    import pkg_alias  # noqa: F401  (installs the ankiscape package alias)
    from ankiscape.logic_pure import logic_pure_combat_engine as candidate

    baseline = types.ModuleType("ankiscape.logic_pure._frozen_preview_food_engine")
    baseline.__package__ = "ankiscape.logic_pure"
    exec(
        compile(baseline_bytes, "<frozen-preview-food-engine>", "exec"),
        baseline.__dict__,
    )
    rows = []
    for label, player, target_id, expected in cases():
        before = capture(
            baseline.combat_target_preview_pure, player, target_id
        )
        after = capture(candidate.combat_target_preview_pure, player, target_id)
        before_bytes = pickle.dumps(before, protocol=4)
        after_bytes = pickle.dumps(after, protocol=4)
        observed = route_observation(after)
        rows.append(
            {
                "case": label,
                "equal": before == after,
                "pickle_bytes_equal": before_bytes == after_bytes,
                "route_expected": expected,
                "route_observed": observed,
                "route_pass": observed == expected,
                "inputs_unchanged": after["inputs_unchanged"],
                "baseline_pickle_base64": base64.b64encode(
                    before_bytes
                ).decode(),
                "candidate_pickle_base64": base64.b64encode(
                    after_bytes
                ).decode(),
            }
        )
    return rows


def main():
    if sys.flags.optimize or "PYTHONOPTIMIZE" in os.environ:
        raise SystemExit(
            "Optimized interpreter refused; product imports not started."
        )
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[2]
    )
    parser.add_argument("--inventory", required=True, type=Path)
    parser.add_argument("--inventory-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    sources, baseline = source_guard(
        args.root, args.inventory, args.inventory_sha256
    )
    report = {
        "baseline_commit": BASELINE_COMMIT,
        "baseline_engine_sha256": BASELINE_ENGINE_SHA256,
        "baseline_supplies_sha256": BASELINE_SUPPLIES_SHA256,
        "baseline_model_sha256": BASELINE_MODEL_SHA256,
        "inventory_sha256": args.inventory_sha256,
        "sources_before": sources,
        "rng_applicable": False,
    }
    if args.preflight:
        product_modules = sorted(
            name
            for name in sys.modules
            if name == "pkg_alias"
            or name.split(".")[0] in {"ankiscape", "tests"}
        )
        if product_modules:
            raise RuntimeError(
                f"Product imported during preflight: {product_modules}"
            )
        report.update(
            status="PREFLIGHT_PASS",
            product_imported=False,
            product_modules=product_modules,
        )
    else:
        sys.path.insert(0, str(args.root))
        rows = compare(baseline)
        report.update(
            cases=rows,
            status=(
                "PASS"
                if all(
                    row["equal"]
                    and row["pickle_bytes_equal"]
                    and row["route_pass"]
                    and all(row["inputs_unchanged"].values())
                    for row in rows
                )
                else "FAIL"
            ),
        )
    report["sources_after"], _ = source_guard(
        args.root, args.inventory, args.inventory_sha256
    )
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    if report["status"] == "FAIL":
        raise SystemExit("Preview comparison or route assertions failed.")


if __name__ == "__main__":
    main()
