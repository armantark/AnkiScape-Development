from pathlib import Path
import gzip, hashlib, importlib.util, json, sys, tempfile
from unittest.mock import patch

root = Path.cwd()
ev = root / 'memory-bank/evidence/combat-player-attack-rolls-2026-09-07'
pins = json.loads((ev / 'initial-pins.json').read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
attempts = []
def audit(event, values):
    if event == 'import' and values[0].split('.')[0] in {'ankiscape', 'pkg_alias', 'tests'}:
        attempts.append(values[0])
        raise RuntimeError('Product import forbidden in static verification.')
sys.addaudithook(audit)
gate_path = Path(pins['gate']['path'])
assert sha(gate_path.read_bytes()) == pins['gate']['sha256']
for row in pins['tools'].values():
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
spec = importlib.util.spec_from_file_location('_static_slop_gate', gate_path)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
assert {key: getattr(gate, key) for key in pins['gate']['thresholds']} == pins['gate']['thresholds']
files = ['tools/combat/run_player_attack_rolls_remote.py', 'tools/combat/check_player_remote_resume.py']
raw = []
run_tool = gate.run_tool
def capture(argv, tool):
    result = run_tool(argv, tool)
    row = {'argv': argv, 'tool': tool, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    if tool == 'complexipy':
        directory = Path(argv[argv.index('--output') + 1])
        row['reports'] = {p.name: p.read_text() for p in directory.glob('*.json')}
    raw.append(row)
    return result

with tempfile.TemporaryDirectory(prefix='player-roll-static-') as directory:
    scratch = Path(directory)
    base, candidate = scratch / 'base', scratch / 'candidate'
    base.mkdir()
    candidate.mkdir()
    for name in files:
        (candidate / name).parent.mkdir(parents=True, exist_ok=True)
        (candidate / name).write_bytes((root / name).read_bytes())
    metrics = {}
    with patch.object(gate, 'run_tool', side_effect=capture):
        for label, tree in [('base', base), ('candidate', candidate)]:
            metrics[label] = {name: function(tree) for name, function in [('ccn', gate.ccn_by_function), ('cognitive', gate.cognitive_by_function), ('halstead', gate.halstead_by_function), ('layout', gate.pep8_layout_findings)]}
    failures = {name: gate.ratchet(metrics['candidate'][name], metrics['base'][name], limit) for name, limit in [('ccn', gate.CCN_MAX), ('cognitive', gate.COGNITIVE_MAX), ('halstead', gate.HALSTEAD_MAX)]}
    failures['layout'] = gate.layout_ratchet(metrics['candidate']['layout'], metrics['base']['layout'])
    base_lines, candidate_lines = gate.line_counts(base, files), gate.line_counts(candidate, files)
    failures['file_growth'] = [(name, count) for name, count in candidate_lines.items() if count > gate.FILE_LINES_MAX and count > base_lines.get(name, 0)]
    result = {'status': 'PASS' if not any(failures.values()) else 'FAIL', 'source_sha256': {p: sha((root / p).read_bytes()) for p in files}, 'metrics': {label: {kind: {'|'.join(key): value for key, value in values.items()} for kind, values in table.items()} for label, table in metrics.items()}, 'lines': {'base': base_lines, 'candidate': candidate_lines}, 'failures': failures, 'gate_sha256': pins['gate']['sha256'], 'thresholds': pins['gate']['thresholds'], 'product_import_attempts': attempts, 'python': sys.executable, 'python_version': sys.version}
    (ev / 'acceptance-static-metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    (ev / 'acceptance-static-raw.json.gz').write_bytes(gzip.compress(json.dumps(raw, indent=2).encode(), mtime=0))
    assert not any(failures.values()), failures
    assert not attempts
    print(json.dumps({'status': result['status'], 'failures': failures, 'sources': result['source_sha256'], 'lines': result['lines']}, indent=2))
