from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import ast
import hashlib
import json
import re

ROOT = Path('/tmp/quest-report-copy-71kq0ihq')
CONFIG = Path('/tmp/ankiscape-quest-operational-bindings-2026-09-05.json')
DRIVER = Path('/var/folders/rt/xd67_cfj3jg9pkgkc0jnhk300000gr/T/quest-driver-84vmbtkr/capture.json')
BASE = ROOT / 'quest-baseline-3uysacly'
CANDIDATE = ROOT / 'quest-candidate-6r11egtn'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text())


def verify_binding(path, entry):
    raw = path.read_bytes()
    assert len(raw) == entry['bytes'] and digest(raw) == entry['sha256'], str(path)
    return raw


def body(path, marker):
    raw = path.read_bytes()
    value, footer = raw.rsplit(marker, 1)
    assert footer == (digest(value) + '\n').encode(), str(path)
    return value


cfg = read(CONFIG)
assert digest(CONFIG.read_bytes()) == 'ea4687ce5e45b6d95df6011cffd4fe4fc880059ffbb3e0c4896dcabb84894598'
driver = read(DRIVER)
assert driver['status'] == 'PASS' and driver['subprocess_count'] == 41
assert driver['bindings_sha256'] == digest(CONFIG.read_bytes())
assert driver['local_source_hash_canary'] == {'status': 'PASS', 'canary': 'Frozen source bindings changed; no remote commands launched', 'remote_commands_launched': 0}
assert driver['baseline_archive']['status'] == 'PASS' and driver['baseline_archive']['files'] == 6133
remote_inventory = read(ROOT / 'remote-files.json')
copied_files = 0
for remote, expected in remote_inventory.items():
    root = ROOT / Path(remote).name
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    assert actual == set(expected)
    for name, entry in expected.items():
        verify_binding(root / name, entry)
    copied_files += len(expected)
assert copied_files == 112
for name, expected in cfg['candidate_source_hashes'].items():
    assert digest((Path(cfg['candidate_root']) / name).read_bytes()) == expected
for path, expected in cfg['uploads'].items():
    assert digest(Path(path).read_bytes()) == expected
assert digest((Path(cfg['candidate_root']) / cfg['static_manifest']['path']).read_bytes()) == cfg['static_manifest']['sha256']
archive_manifest = read(Path(cfg['baseline_archive']['manifest_path']))
assert digest(Path(cfg['baseline_archive']['manifest_path']).read_bytes()) == cfg['baseline_archive']['manifest_sha256']
archive_hashes = {entry['path']: entry['sha256'] for entry in archive_manifest['files']}
assert len(archive_hashes) == 6133
for name in ('archive-before.json', 'archive-after.json'):
    record = read(BASE / name)
    assert record['status'] == 'PASS' and record['files'] == 6133
    assert record['archive_manifest_sha256'] == cfg['baseline_archive']['manifest_sha256']
    assert record['actual_source_hashes'] == archive_hashes
source_canaries = []
for phase in driver['phases']:
    local = ROOT / Path(phase['report']).name
    assert read(local / 'verification.json') == phase['verification']
    if phase['source_hash_canary']:
        assert phase['exit_code'] == 2 and phase['results_json_absent']
        assert phase['verification'] == {'status': 'FAIL', 'errors': ['Source hash mismatch; no runtime commands launched'], 'subprocess_count': 0}
        assert not (local / 'results.json').exists()
        hashes = read(local / 'source-hashes.json')
        expected = cfg['baseline_source_hashes_or_required_absence'] if phase['phase'] == 'baseline' else cfg['candidate_source_hashes']
        assert hashes['actual'] == expected
        assert hashes['expected'] == {**expected, 'data/quest_data.py': '0' * 64}
        assert read(local / 'source-hashes-after.json') == expected
        source_canaries.append({'phase': phase['phase'], 'exit_code': 2, 'jobs': 0, 'results_json_absent': True})
assert len(source_canaries) == 2
streams = []
all_jobs = []
layouts = {}
for phase, root, expected, parts, count in (
        ('baseline', BASE, cfg['baseline_source_hashes_or_required_absence'], [], 2),
        ('candidate', CANDIDATE, cfg['candidate_source_hashes'], cfg['part_inventory'], 39)):
    results = read(root / 'results.json')
    assert len(results) == count and len({(r['lane'], r['mode']) for r in results}) == count
    assert read(root / 'source-hashes.json') == {'expected': expected, 'actual': expected}
    assert read(root / 'source-hashes-after.json') == expected
    assert read(root / 'part-inventory.json') == {'expected': parts, 'actual': parts}
    assert read(root / 'part-inventory-after.json') == parts
    assert len(expected) == 90
    layouts[phase] = read(root / 'interpreter-layout.json')
    checks = read(root / 'checks.json')
    assert len(checks) == count and all(c['valid'] for c in checks)
    assert {(c['lane'], c['mode']) for c in checks} == {(r['lane'], r['mode']) for r in results}
    for job in results:
        assert job['status'] == 'finished' and job['launched'] is True and job['exit_code'] == 0
        assert job['source_hashes_before'] == job['source_hashes_after'] == expected
        assert job['part_inventory_before'] == job['part_inventory_after'] == parts
        assert job['argv'][0] == layouts[phase][job['lane']]['path']
        for stream in ('stdout', 'stderr'):
            path = root / job[stream]
            assert Path(job[stream + '_binding']['path']).name == path.name
            verify_binding(path, job[stream + '_binding'])
            streams.append({'phase': phase, 'lane': job['lane'], 'mode': job['mode'], 'stream': stream, 'path': str(path), **{k: job[stream + '_binding'][k] for k in ('bytes', 'sha256')}})
        all_jobs.append({'phase': phase, **job})
    raw_files = {p.name for p in root.iterdir() if p.suffix in ('.stdout', '.stderr')}
    assert raw_files == {job[stream] for job in results for stream in ('stdout', 'stderr')}
assert len(all_jobs) == 41 and len(streams) == 82
assert layouts['baseline'] == layouts['candidate']
assert layouts['candidate']['qt']['resolved'] == layouts['candidate']['internal_qt']['resolved']
manifest_file = BASE / 'serializer-baseline.json'
manifest = read(manifest_file)
assert digest(manifest_file.read_bytes()) == driver['serializer_baseline']['manifest_sha256']
assert manifest == driver['serializer_baseline']['manifest']
assert manifest['bindings_sha256'] == digest(CONFIG.read_bytes()) and manifest['source_hashes'] == cfg['baseline_source_hashes_or_required_absence']
assert manifest['main_commit'] == cfg['main_baseline_commit'] and manifest['probe_sha256'] == cfg['serializer_probe']['sha256']
assert manifest['archive_manifest_sha256'] == cfg['baseline_archive']['manifest_sha256']
for name, entry in manifest['evidence_bindings'].items():
    assert Path(entry['path']) == Path(driver['serializer_baseline']['report']) / name
    verify_binding(BASE / name, entry)
serializer_tables = ['quests', 'references', 'quest_unlocks', 'target_unlocks', 'reward_items', 'claims']
serializers = []
for lane in ('plain', 'qt'):
    name = lane + '-serializers.stdout'
    b = verify_binding(BASE / name, manifest['streams'][lane])
    candidate = (CANDIDATE / name).read_bytes()
    assert b == candidate and not (BASE / (lane + '-serializers.stderr')).read_bytes() and not (CANDIDATE / (lane + '-serializers.stderr')).read_bytes()
    value = body(BASE / name, b'QUEST_SERIALIZERS_SHA256: ')
    assert body(CANDIDATE / name, b'QUEST_SERIALIZERS_SHA256: ') == value
    rows = json.loads(value)
    assert [row[0] for row in rows] == serializer_tables and all(len(row) == 3 for row in rows)
    assert digest(value) == manifest['streams'][lane]['body_sha256']
    serializers.append({'lane': lane, 'tables': serializer_tables, 'bytes': len(b), 'sha256': digest(b), 'body_sha256': digest(value), 'whole_file_equal': True})
surfaces = []
for name, expected in cfg['surface_baseline']['files'].items():
    candidate = CANDIDATE / name
    baseline = Path('/tmp/cut-gem-baseline-6438d422') / name
    raw = verify_binding(candidate, expected)
    assert raw == baseline.read_bytes()
    assert digest(body(candidate, b'MODULE_SURFACE_SHA256: ')) == expected['body_sha256']
    assert body(candidate, b'MODULE_SURFACE_SHA256: ') == body(baseline, b'MODULE_SURFACE_SHA256: ')
    surfaces.append({'file': name, **expected, 'whole_file_equal': True})
assert len(surfaces) == 23
canaries = []
for lane in ('plain', 'qt'):
    for case, expected in cfg['canaries'].items():
        p = CANDIDATE / (lane + '-canary-' + case + '.stdout')
        assert read(p) == expected
        assert not p.with_suffix('.stderr').read_bytes()
        canaries.append({'lane': lane, **expected})
assert len(canaries) == 6
suite_ids = {'named-tests': cfg['new_test_ids'], 'quest-tests': cfg['candidate_quest_test_ids'], 'module-surface': cfg['existing_measurement_test_ids']}
expected_skip = 'test_module_surface.ModuleSurfaceTest.test_root_initializer_is_reported_as_unavailable_without_aqt'
skip_reason = 'root initializer requires aqt; use the offscreen Qt interpreter'
test_checks = []
for lane in ('plain', 'qt'):
    for mode, expected in suite_ids.items():
        assert not (CANDIDATE / (lane + '-' + mode + '.stdout')).read_bytes()
        text = (CANDIDATE / (lane + '-' + mode + '.stderr')).read_text()
        records, consumed, skips = [], 0, []
        pattern = re.compile(r'^(test_\S+) \(([^\n]+)\)(?:\n([^\n]*))? \.\.\. (.+)$', re.MULTILINE)
        for match in pattern.finditer(text):
            assert not text[consumed:match.start()].strip()
            method, test_id, description, result = match.groups()
            assert test_id in expected and method == test_id.rsplit('.', 1)[1]
            if description is not None:
                module, cls, fn = test_id.rsplit('.', 2)
                tree = ast.parse((Path(cfg['candidate_root']) / 'tests' / (module.replace('.', '/') + '.py')).read_bytes())
                node = next(n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == cls for n in c.body if isinstance(n, ast.FunctionDef) and n.name == fn)
                assert description == (ast.get_docstring(node) or '').split('\n', 1)[0]
            if result != 'ok':
                assert mode == 'module-surface' and test_id == expected_skip
                assert result.startswith('skipped ') and ast.literal_eval(result[8:]) == skip_reason
                skips.append(test_id)
            records.append(test_id)
            consumed = match.end()
        assert Counter(records) == Counter(expected) and len(set(records)) == len(expected)
        summary = re.fullmatch(r'\n\n-{70}\nRan (\d+) tests in (\d+\.\d+)s\n\nOK(?: \(skipped=(\d+)\))?\n', text[consumed:])
        assert summary and int(summary[1]) == len(expected) and int(summary[3] or 0) == len(skips)
        assert skips == ([expected_skip] if mode == 'module-surface' else [])
        test_checks.append({'lane': lane, 'mode': mode, 'tests': len(records), 'skips': len(skips), 'seconds': summary[2], 'ids_sha256': digest(('\n'.join(sorted(records)) + '\n').encode())})
discoveries = []
for lane in ('plain', 'qt'):
    raw = (CANDIDATE / (lane + '-discovery.stdout')).read_bytes()
    assert not (CANDIDATE / (lane + '-discovery.stderr')).read_bytes()
    ids = raw.decode().splitlines()
    baseline_raw = (Path('/tmp/ghosts-prerequisite-baseline-ygs2eavk') / (lane + '-discovery.stdout')).read_bytes()
    assert digest(baseline_raw) == cfg['discovery_baseline']['stdout_sha256']
    original = baseline_raw.decode().splitlines()
    assert len(ids) == len(set(ids)) == 5570 and len(original) == 5567
    assert set(ids) - set(original) == set(cfg['new_test_ids'])
    assert [test_id for test_id in ids if test_id not in cfg['new_test_ids']] == original
    selected = [test_id for test_id in ids if any(selector.casefold() in test_id.casefold() for selector in cfg['quest_test_selectors'])]
    assert Counter(selected) == Counter(cfg['candidate_quest_test_ids'])
    discoveries.append({'lane': lane, 'baseline': 5567, 'candidate': 5570, 'sha256': digest(raw), 'ordered_baseline_preserved': True, 'additions': cfg['new_test_ids']})
result = {'status': 'PASS', 'verified_utc': datetime.now(timezone.utc).isoformat(), 'copied_report_root': str(ROOT), 'driver_record': {'path': str(DRIVER), 'bytes': DRIVER.stat().st_size, 'sha256': digest(DRIVER.read_bytes())}, 'operational_bindings_sha256': digest(CONFIG.read_bytes()), 'remote_copy_files': copied_files, 'job_count': len(all_jobs), 'raw_stream_count': len(streams), 'source_bindings_per_job': 90, 'before_after_hash_and_part_snapshots': 82, 'baseline_archive_files': 6133, 'source_canaries': source_canaries, 'stream_bindings': streams, 'surface_checks': surfaces, 'serializer_checks': serializers, 'ownership_canaries': canaries, 'test_checks': test_checks, 'discovery_checks': discoveries, 'interpreter_layout': layouts['candidate'], 'parent_local_canary': driver['local_source_hash_canary'], 'scope': 'Local immutable-report verification only. No project imports, tests, sync, mirror calls, repository edits, or commits. The preceding copy read only the four immutable remote report directories.'}
out = ROOT / 'independent-verification.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'path': str(out), 'bytes': out.stat().st_size, 'sha256': digest(out.read_bytes()), 'reports': 4, 'files': copied_files, 'jobs': 41, 'streams': 82, 'surfaces': 23, 'serializer_tables_per_lane': 6, 'canaries': 6, 'tests': test_checks, 'discovery': discoveries}))
