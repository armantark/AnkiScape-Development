#!/usr/bin/env python3
"""Reject one process-local fixture with the exact frozen quest assertion."""
import ast
import copy
import hashlib
import importlib
import json
from pathlib import Path
import sys
import types
import unittest

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
TEST_SHA256 = '1ca4308e9d9ce6e7eac03f70dad99983353822f3fc71b71d8c38569d636e248a'
CASES = ('facade-presence', 'reward-row-alias', 'mutation-snapshot')


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        raise ValueError('Choose exactly one defined quest canary case')
    case = sys.argv[1]
    source = ROOT / 'tests/quest_catalog/test_split_contract.py'
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != TEST_SHA256:
        raise RuntimeError('Frozen test source changed; no project imports performed')
    tree = ast.parse(raw)
    methods = {node.name: node for cls in tree.body
               if isinstance(cls, ast.ClassDef) and cls.name == 'TestQuestSplitContract'
               for node in cls.body if isinstance(node, ast.FunctionDef)}
    if case == 'facade-presence':
        method = methods['test_every_quest_part_imports_without_loading_the_facade']
        value = next(node.value for node in method.body if isinstance(node, ast.Assign)
                     and any(isinstance(target, ast.Name) and target.id == 'script'
                             for target in node.targets))
        if not (isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute)
                and isinstance(value.func.value, ast.Constant) and value.func.value.value == '\n'
                and value.func.attr == 'join' and len(value.args) == 1 and not value.keywords):
            raise RuntimeError('Standalone snippet no longer has its frozen literal form')
        script = '\n'.join(ast.literal_eval(value.args[0]))
        snippet_tree = ast.parse(script)
        matches = [node for node in ast.walk(snippet_tree) if isinstance(node, ast.Assert)
                   and ast.unparse(node.test) == "'ankiscape.data.quest_data' not in sys.modules"]
        if len(matches) != 1:
            raise RuntimeError('Facade assertion is missing or ambiguous')
        expected_line = matches[0].lineno
        expected_assertion = ast.unparse(matches[0].test)
        filename = str(source) + '::standalone-script'
        code = compile(script, filename, 'exec')
        source_digest = hashlib.sha256(script.encode()).hexdigest()
    else:
        method = methods['test_reward_item_metadata_is_owned_by_each_projection']
        calls = [node for node in ast.walk(method) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute)
                 and isinstance(node.func.value, ast.Name) and node.func.value.id == 'self']
        if case == 'reward-row-alias':
            matches = [node for node in calls if node.func.attr == 'assertIsNot']
        else:
            matches = [node for node in calls if node.func.attr == 'assertEqual'
                       and isinstance(node.args[0], ast.Call)
                       and ast.unparse(node.args[0].func) == 'quest_data.quest_reward_items_as_dict']
        if len(matches) != 1:
            raise RuntimeError('Reward ownership assertion is missing or ambiguous')
        expected_line = matches[0].lineno
        expected_assertion = ast.unparse(matches[0])
        filename = str(source) + '::reward-method'
        code = compile(ast.Module(body=[method], type_ignores=[]), filename, 'exec')
        source_digest = hashlib.sha256(b''.join(raw.splitlines(keepends=True)[
            method.lineno - 1:method.end_lineno])).hexdigest()
    sys.path.insert(0, str(ROOT))
    import pkg_alias
    original_fragments = fragment_snapshot = original_projection = facade = None
    if case == 'facade-presence':
        module_name = 'ankiscape.data.quest.dependencies'
        importlib.import_module(module_name)
        if 'ankiscape.data.quest_data' in sys.modules:
            raise RuntimeError('Canary setup already loaded the facade')
        sys.modules['ankiscape.data.quest_data'] = types.ModuleType('ankiscape.data.quest_data')
        sys.argv = ['-c', module_name]
        invoke = lambda: exec(code, {'__name__': '__main__'})
    else:
        facade = importlib.import_module('ankiscape.data.quest_data')
        rewards = importlib.import_module('ankiscape.data.quest.reward_items')
        original_fragments = rewards._QUEST_REWARD_ITEM_FRAGMENTS
        fragment_snapshot = copy.deepcopy(original_fragments)
        original_projection = facade.quest_reward_items_as_dict
        first = original_projection()
        if not first:
            raise RuntimeError('Reward fixture is empty')
        if case == 'reward-row-alias':
            facade.quest_reward_items_as_dict = lambda: dict(first)
        else:
            second = original_projection()
            calls_made = 0

            def corrupt_second_on_third_call():
                nonlocal calls_made
                calls_made += 1
                if calls_made == 1:
                    return first
                if calls_made == 2:
                    return second
                if calls_made == 3:
                    second[next(iter(second))]['source'] = 'Changed only inside the canary fixture'
                    return second
                raise RuntimeError('Mutation fixture received an unexpected projection call')

            facade.quest_reward_items_as_dict = corrupt_second_on_third_call
        namespace = {'copy': copy, 'quest_data': facade}
        exec(code, namespace)
        invoke = lambda: namespace[method.name](unittest.TestCase())
    try:
        invoke()
    except AssertionError as error:
        frames = []
        trace = error.__traceback__
        while trace:
            if trace.tb_frame.f_code.co_filename == filename:
                frames.append(trace.tb_lineno)
            trace = trace.tb_next
        if frames != [expected_line]:
            raise RuntimeError('Canary failed at an unrelated assertion') from error
        if case == 'facade-presence' and error.args:
            raise RuntimeError('Facade canary did not reach its bare absence assertion') from error
        if case == 'mutation-snapshot' and calls_made != 3:
            raise RuntimeError('Mutation canary failed before its third call') from error
        if original_fragments is not None and original_fragments != fragment_snapshot:
            raise RuntimeError('Original reward fragment storage was modified') from error
        print(json.dumps({'status': 'PASS', 'case': case, 'caught': 'AssertionError',
                          'assertion': expected_assertion, 'assertion_line': expected_line,
                          'checked_source_sha256': source_digest, 'test_sha256': TEST_SHA256,
                          'original_fragment_storage_unchanged': True}), flush=True)
        return 0
    finally:
        if facade is not None:
            facade.quest_reward_items_as_dict = original_projection
    raise RuntimeError('Canary did not fail at its intended assertion')


if __name__ == '__main__':
    raise SystemExit(main())
