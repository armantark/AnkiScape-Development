#!/usr/bin/env python3
"""Capture reviewed quest evidence under the parent's canonical mirror guard."""
import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
BINDINGS = Path('/tmp/ankiscape-quest-operational-bindings-2026-09-05.json')
ARCHIVE_MANIFEST = Path('/tmp/ankiscape-main814-baseline-manifest-2026-09-05.json')
EXPECTED = {}
EXPECTED_PARTS = []
RECORD_PATTERN = r'^(test_\S+) \(([^\n]+)\)(?:\n([^\n]*))? \.\.\. (.+)$'
ALLOWED_FULL_SKIP = {
    'test_module_surface.ModuleSurfaceTest.test_root_initializer_is_reported_as_unavailable_without_aqt':
        'root initializer requires aqt; use the offscreen Qt interpreter',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def binding(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def check_tests(record, out, expected_ids, descriptions):
    check = {'lane': record['lane'], 'mode': record['mode'], 'valid': False, 'outcomes': []}
    try:
        assert record['exit_code'] == 0 and record['status'] == 'finished', 'Test subprocess failed'
        assert (out / record['stdout']).read_bytes() == b'', 'Unexpected test stdout'
        text = (out / record['stderr']).read_text()
        cursor = 0
        skips = 0
        for match in re.finditer(RECORD_PATTERN, text, re.MULTILINE):
            assert text[cursor:match.start()].strip() == '', 'Unmatched text before a test record'
            method, test_id, description, status = match.groups()
            assert test_id in expected_ids and method == test_id.rsplit('.', 1)[-1], 'Unexpected test identity'
            if description is not None:
                assert descriptions[test_id] == description, 'Printed description differs from the source docstring'
            if status != 'ok':
                assert record['mode'] == 'module-surface' and test_id in ALLOWED_FULL_SKIP, 'Unexpected non-passing test outcome'
                assert status.startswith('skipped '), 'Expected the existing plain-root skip only'
                assert ast.literal_eval(status[len('skipped '):]) == ALLOWED_FULL_SKIP[test_id], 'Skip reason differs from the existing test contract'
                skips += 1
            check['outcomes'].append({'test_id': test_id, 'description': description, 'status': status})
            cursor = match.end()
        ids = [row['test_id'] for row in check['outcomes']]
        assert Counter(ids) == Counter(expected_ids) and len(set(ids)) == len(expected_ids), 'Test selection is incomplete or duplicated'
        tail = re.fullmatch(r'\n\n-{70}\nRan ([0-9]+) tests in ([0-9]+\.[0-9]+)s\n\nOK(?: \(skipped=([0-9]+)\))?\n', text[cursor:])
        assert tail and int(tail[1]) == len(expected_ids) and int(tail[3] or 0) == skips, 'Unmatched output or inconsistent unittest summary'
        check.update(valid=True, tests=len(ids), skips=skips, seconds=tail[2], unmatched_records=0,
                     selected_ids_sha256=sha(('\n'.join(sorted(ids)) + '\n').encode()))
    except (AssertionError, OSError, ValueError, KeyError, SyntaxError) as error:
        check['error'] = repr(error)
    return check

def source_hashes():
    return {name: sha((ROOT / name).read_bytes()) if (ROOT / name).is_file() else None
            for name in EXPECTED}


def part_inventory():
    return sorted(str(path.relative_to(ROOT)) for path in (ROOT / 'data/quest').rglob('*.py'))


def payload_integrity(path, marker):
    raw = path.read_bytes()
    body, footer = raw.rsplit(marker, 1)
    if footer != (sha(body) + '\n').encode():
        raise ValueError('Payload footer does not match its complete body')
    if marker == b'QUEST_SERIALIZERS_SHA256: ':
        rows = json.loads(body)
        if not isinstance(rows, list) or [row[0] for row in rows] != [
                'quests', 'references', 'quest_unlocks', 'target_unlocks', 'reward_items', 'claims']:
            raise ValueError('Serializer table inventory differs')
        if any(not isinstance(row, list) or len(row) != 3 for row in rows):
            raise ValueError('Serializer record shape differs')
    return {**binding(path), 'body_sha256': sha(body), 'valid': True}


def archive_inventory(cfg):
    if sha(ARCHIVE_MANIFEST.read_bytes()) != cfg['baseline_archive']['manifest_sha256']:
        raise ValueError('Baseline archive manifest changed')
    manifest = json.loads(ARCHIVE_MANIFEST.read_text())
    if (manifest['status'] != 'PASS_EXACT_GIT_ARCHIVE'
            or manifest['commit'] != cfg['main_baseline_commit'] or len(manifest['files']) != 6133):
        raise ValueError('Baseline archive identity differs')
    expected = {entry['path']: entry for entry in manifest['files']}
    actual_paths = set()
    for path in ROOT.rglob('*'):
        relative = path.relative_to(ROOT)
        if ('.venv-qt' in relative.parts or '__pycache__' in relative.parts
                or path.name.startswith('ankiscape_debug.log')):
            continue
        if path.is_symlink():
            raise ValueError('Unexpected baseline symlink: ' + str(relative))
        if path.is_file():
            actual_paths.add(relative.as_posix())
    if len(expected) != 6133 or actual_paths != set(expected):
        raise ValueError('Complete baseline file inventory differs')
    actual = {}
    for name, entry in expected.items():
        path = ROOT / name
        raw = path.read_bytes()
        digest = sha(raw)
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        executable = bool(path.stat().st_mode & 0o111)
        if (digest != entry['sha256'] or len(raw) != entry['bytes'] or blob != entry['git_blob']
                or executable != (entry['mode'] == '100755')):
            raise ValueError('Baseline archive file differs: ' + name)
        actual[name] = digest
    return {'status': 'PASS', 'files': 6133, 'actual_source_hashes': actual,
            'archive_manifest_sha256': cfg['baseline_archive']['manifest_sha256']}


def interpreter_layout():
    qt = ROOT.parent / '.venv-qt/bin/python'
    internal_qt = ROOT / '.venv-qt/bin/python'
    plain = Path('/opt/homebrew/bin/python3')
    if not plain.is_file() or not qt.is_file() or not internal_qt.is_file():
        raise ValueError('A required interpreter is unavailable')
    if internal_qt.resolve() != qt.resolve():
        raise ValueError('The mirror Qt link does not resolve to the approved interpreter')
    return {name: {'path': str(path), 'resolved': str(path.resolve()),
                   'binary_sha256': sha(path.read_bytes())}
            for name, path in (('plain', plain), ('qt', qt), ('internal_qt', internal_qt))}


def candidate_preflight(cfg, args, out):
    baseline_report = Path(args.baseline_report).resolve()
    if (baseline_report.parent != (ROOT.parent / 'reports').resolve()
            or not baseline_report.name.startswith('quest-baseline-')):
        raise ValueError('Unexpected serializer baseline report path')
    baseline_manifest = baseline_report / 'serializer-baseline.json'
    if sha(baseline_manifest.read_bytes()) != args.baseline_manifest_sha256:
        raise ValueError('Serializer baseline manifest changed')
    baseline = json.loads(baseline_manifest.read_text())
    if (baseline['status'] != 'PASS' or baseline['phase'] != 'baseline'
            or baseline['main_commit'] != cfg['main_baseline_commit']
            or baseline['bindings_sha256'] != args.bindings_sha256
            or baseline['probe_sha256'] != cfg['serializer_probe']['sha256']
            or baseline['archive_manifest_sha256'] != cfg['baseline_archive']['manifest_sha256']
            or baseline['source_hashes'] != cfg['baseline_source_hashes_or_required_absence']
            or set(baseline['streams']) != {'plain', 'qt'}):
        raise ValueError('Serializer baseline provenance differs')
    for name, entry in baseline['evidence_bindings'].items():
        if Path(name).name != name or binding(baseline_report / name) != entry:
            raise ValueError('Serializer baseline evidence binding differs: ' + name)
    for lane, record in baseline['streams'].items():
        path = baseline_report / (lane + '-serializers.stdout')
        if payload_integrity(path, b'QUEST_SERIALIZERS_SHA256: ') != record:
            raise ValueError('Serializer baseline bytes differ')
    write_json(out / 'serializer-baseline-input.json', {
        'path': str(baseline_report), 'manifest_sha256': args.baseline_manifest_sha256,
        'manifest': baseline})
    descriptions = {}
    for test_id in set(cfg['candidate_quest_test_ids'] + cfg['existing_measurement_test_ids']):
        module_name, class_name, method_name = test_id.rsplit('.', 2)
        path = ROOT / 'tests' / (module_name.replace('.', '/') + '.py')
        tree = ast.parse(path.read_bytes())
        method = next(node for cls in tree.body if isinstance(cls, ast.ClassDef) and cls.name == class_name
                      for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == method_name)
        descriptions[test_id] = (ast.get_docstring(method) or '').split('\n', 1)[0]
    tree = ast.parse((ROOT / 'tests/test_module_surface.py').read_bytes())
    modules = list(next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                        and any(isinstance(target, ast.Name) and target.id == 'FIRST_WAVE_DIGESTS'
                                for target in node.targets)))
    expected_surfaces = cfg['surface_baseline']['files']
    expected_names = {lane + '-' + module.replace('/', '_') + '.stdout'
                      for lane in ('plain', 'qt')
                      for module in [*modules, *(['__init__.py'] if lane == 'qt' else [])]}
    if len(expected_names) != 23 or expected_names != set(expected_surfaces):
        raise ValueError('The complete measuring module inventory differs')
    surface_root = Path(cfg['surface_baseline']['remote_report'])
    for name, expected in expected_surfaces.items():
        actual = payload_integrity(surface_root / name, b'MODULE_SURFACE_SHA256: ')
        if any(actual[key] != value for key, value in expected.items()):
            raise ValueError('Pinned surface baseline differs: ' + name)
    available = {path.name for path in surface_root.glob('*.py.stdout')}
    if available - expected_names - {'plain-__init__.py.stdout'}:
        raise ValueError('Unexpected surface baseline payloads')
    control = surface_root / 'plain-__init__.py.stdout'
    if control.exists() and control.read_bytes():
        raise ValueError('Unavailable plain-root control must be empty')
    discovery_root = Path(cfg['discovery_baseline']['remote_report'])
    baseline_ids = {}
    for lane in ('plain', 'qt'):
        stdout = discovery_root / (lane + '-discovery.stdout')
        stderr = discovery_root / (lane + '-discovery.stderr')
        raw = stdout.read_bytes()
        ids = raw.decode().splitlines()
        if (sha(raw) != cfg['discovery_baseline']['stdout_sha256']
                or stderr.read_bytes() or len(ids) != len(set(ids)) or len(ids) != 5567):
            raise ValueError('Discovery baseline differs')
        baseline_ids[lane] = ids
    return baseline_report, descriptions, modules, baseline_ids, baseline


def run_job(lane, mode, arguments, python, out, results):
    name = lane + '-' + mode
    record = {'lane': lane, 'mode': mode, 'argv': [python, *arguments], 'exit_code': None,
              'stdout': name + '.stdout', 'stderr': name + '.stderr', 'status': 'running',
              'source_hashes_before': source_hashes(), 'source_hashes_after': None, 'launched': False,
              'part_inventory_before': part_inventory(), 'part_inventory_after': None}
    results.append(record)
    write_json(out / 'results.json', results)
    if record['source_hashes_before'] != EXPECTED or record['part_inventory_before'] != EXPECTED_PARTS:
        record['status'] = 'blocked-before-launch'
        write_json(out / 'results.json', results)
        raise RuntimeError(name + ': source hash mismatch before launch; remaining jobs stopped')
    env = {**os.environ, 'PATH': '/opt/homebrew/bin:/usr/bin:/bin', 'QT_QPA_PLATFORM': 'offscreen',
           'PYTHONHASHSEED': '0', 'ANKISCAPE_GAME_MAIN': str(ROOT.parent / 'sources/game-main'),
           'ANKISCAPE_DARKAN_WORLD_SERVER': str(ROOT.parent / 'sources/darkan-world-server')}
    env.pop('PYTHONPATH', None)
    if lane == 'plain':
        env['PYTHONPATH'] = str(ROOT.parent / 'plain-site')
    with (out / record['stdout']).open('wb') as stdout, (out / record['stderr']).open('wb') as stderr:
        try:
            process = subprocess.Popen(record['argv'], cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            record['launched'] = True
            try:
                record['exit_code'] = process.wait(timeout=300)
                record['status'] = 'finished'
            except subprocess.TimeoutExpired as error:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                record.update(exit_code=process.wait(), status='error', error=repr(error),
                              timeout_process_group=process.pid)
        except OSError as error:
            record.update(status='error', error=repr(error))
    record['stdout_binding'] = binding(out / record['stdout'])
    record['stderr_binding'] = binding(out / record['stderr'])
    record['source_hashes_after'] = source_hashes()
    record['part_inventory_after'] = part_inventory()
    write_json(out / 'results.json', results)
    if record['source_hashes_after'] != EXPECTED or record['part_inventory_after'] != EXPECTED_PARTS:
        raise RuntimeError(name + ': source hash mismatch after job; remaining jobs stopped')
    if record['status'] != 'finished' or record['exit_code'] != 0:
        raise RuntimeError(name + ': subprocess did not finish successfully')
    return record


def main():
    global EXPECTED, EXPECTED_PARTS
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', required=True, choices=('baseline', 'candidate'))
    parser.add_argument('--bindings-sha256', required=True)
    parser.add_argument('--source-hash-canary', action='store_true')
    parser.add_argument('--baseline-report')
    parser.add_argument('--baseline-manifest-sha256')
    args = parser.parse_args()
    out = Path(tempfile.mkdtemp(prefix='quest-' + args.phase + '-', dir=ROOT.parent / 'reports'))
    print(str(out), flush=True)
    results, checks, errors = [], [], []
    try:
        if sha(BINDINGS.read_bytes()) != args.bindings_sha256:
            raise ValueError('Operational bindings changed')
        cfg = json.loads(BINDINGS.read_text())
        for path, digest in cfg['uploads'].items():
            if sha(Path(path).read_bytes()) != digest:
                raise ValueError('Frozen upload differs: ' + path)
        EXPECTED = dict(cfg['baseline_source_hashes_or_required_absence'] if args.phase == 'baseline'
                        else cfg['candidate_source_hashes'])
        if args.source_hash_canary:
            EXPECTED['data/quest_data.py'] = '0' * 64
        actual = source_hashes()
        write_json(out / 'source-hashes.json', {'expected': EXPECTED, 'actual': actual})
        write_json(out / 'capture.json', {'phase': args.phase, 'started_utc': datetime.now(timezone.utc).isoformat(),
                   'bindings_sha256': args.bindings_sha256, 'capture_sha256': sha(Path(__file__).read_bytes()),
                   'main_commit': cfg['main_baseline_commit'], 'candidate_head': cfg['candidate_head'],
                   'static_manifest_sha256': cfg['static_manifest']['sha256'], 'source_count': len(EXPECTED),
                   'source_hash_canary': args.source_hash_canary, 'archive': cfg['baseline_archive'],
                   'serializer_probe': cfg['serializer_probe']})
        if actual != EXPECTED:
            write_json(out / 'source-hashes-after.json', actual)
            write_json(out / 'verification.json', {'status': 'FAIL',
                       'errors': ['Source hash mismatch; no runtime commands launched'], 'subprocess_count': 0})
            return 2
        inventory = part_inventory()
        expected_parts = [] if args.phase == 'baseline' else cfg['part_inventory']
        EXPECTED_PARTS = expected_parts
        write_json(out / 'part-inventory.json', {'expected': expected_parts, 'actual': inventory})
        if inventory != expected_parts:
            raise ValueError('Quest part inventory differs')
        if args.phase == 'candidate':
            names = ['ankiscape.' + '.'.join(Path(path).with_suffix('').parts[:-1]
                     if Path(path).name == '__init__.py' else Path(path).with_suffix('').parts)
                     for path in inventory]
            if len(names) != len(set(names)) or len(names) != 83:
                raise ValueError('Native quest part identities differ')
        layout = interpreter_layout()
        write_json(out / 'interpreter-layout.json', layout)
        if args.phase == 'baseline':
            write_json(out / 'archive-before.json', archive_inventory(cfg))
        else:
            if not args.baseline_report or not args.baseline_manifest_sha256:
                raise ValueError('Candidate requires the fresh approved serializer baseline')
            baseline_report, descriptions, modules, baseline_ids, serializer_baseline = candidate_preflight(cfg, args, out)
    except (AssertionError, OSError, ValueError, KeyError, StopIteration, SyntaxError, TypeError) as error:
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': [repr(error)],
                   'scope': 'Preflight failed; no runtime commands launched', 'subprocess_count': 0})
        return 2
    try:
        for lane in ('plain', 'qt'):
            jobs = [('serializers', [cfg['serializer_probe']['path']])]
            if args.phase == 'candidate':
                jobs = [('canary-' + case, [cfg['canary_script']['path'], case]) for case in cfg['canaries']]
                jobs += [('named-tests', ['run_tests.py', *cfg['new_test_ids'], '--verbosity', '2']),
                         ('quest-tests', ['run_tests.py', *cfg['quest_test_selectors'], '--verbosity', '2']),
                         ('module-surface', ['run_tests.py', 'test_module_surface.', '--verbosity', '2']),
                         ('discovery', ['run_tests.py', '--list', '--max-results', '10000']),
                         ('serializers', [cfg['serializer_probe']['path']])]
                jobs += [(module.replace('/', '_'), ['tools/module_surface.py', module])
                         for module in [*modules, *(['__init__.py'] if lane == 'qt' else [])]]
            for mode, arguments in jobs:
                record = run_job(lane, mode, arguments, layout[lane]['path'], out, results)
                check = {'lane': lane, 'mode': mode, 'valid': False}
                if mode == 'serializers':
                    value = payload_integrity(out / record['stdout'], b'QUEST_SERIALIZERS_SHA256: ')
                    if (out / record['stderr']).read_bytes():
                        raise ValueError('Unexpected serializer stderr')
                    check['candidate'] = value
                    if args.phase == 'candidate':
                        baseline = baseline_report / record['stdout']
                        check['baseline'] = payload_integrity(baseline, b'QUEST_SERIALIZERS_SHA256: ')
                        if check['baseline'] != serializer_baseline['streams'][lane]:
                            raise ValueError('Pinned serializer baseline bytes changed')
                        if (out / record['stdout']).read_bytes() != baseline.read_bytes():
                            raise ValueError('Quest serializer output differs from fresh main814 baseline')
                        check['byte_equal'] = True
                elif mode.startswith('canary-'):
                    observed = json.loads((out / record['stdout']).read_text())
                    case = mode[len('canary-'):]
                    if (out / record['stderr']).read_bytes() or observed != cfg['canaries'][case]:
                        raise ValueError('Canary did not identify its exact intended assertion')
                    check['evidence'] = observed
                elif mode in ('named-tests', 'quest-tests', 'module-surface'):
                    expected_ids = {'named-tests': cfg['new_test_ids'], 'quest-tests': cfg['candidate_quest_test_ids'],
                                    'module-surface': cfg['existing_measurement_test_ids']}[mode]
                    check = check_tests(record, out, expected_ids, descriptions)
                    if not check['valid']:
                        raise ValueError('Test outcome differs: ' + check['error'])
                elif mode == 'discovery':
                    ids = (out / record['stdout']).read_text().splitlines()
                    selected = [test_id for test_id in ids if any(s.casefold() in test_id.casefold()
                                for s in cfg['quest_test_selectors'])]
                    new = cfg['new_test_ids']
                    if ((out / record['stderr']).read_bytes() or len(ids) != len(set(ids)) or len(ids) != 5570
                            or Counter(ids) != Counter(baseline_ids[lane]) + Counter(new)
                            or [test_id for test_id in ids if test_id not in new] != baseline_ids[lane]
                            or Counter(selected) != Counter(cfg['candidate_quest_test_ids'])):
                        raise ValueError('Discovery differs from main814 plus exactly three new tests')
                    check.update(baseline_tests=5567, candidate_tests=5570, expected_additions=new,
                                 full_quest_test_ids=selected, ordered_baseline_preserved=True)
                else:
                    candidate = out / record['stdout']
                    baseline = Path(cfg['surface_baseline']['remote_report']) / record['stdout']
                    check['candidate'] = payload_integrity(candidate, b'MODULE_SURFACE_SHA256: ')
                    check['baseline'] = payload_integrity(baseline, b'MODULE_SURFACE_SHA256: ')
                    if any(check['baseline'][key] != value for key, value
                           in cfg['surface_baseline']['files'][record['stdout']].items()):
                        raise ValueError('Pinned public-surface baseline changed')
                    if candidate.read_bytes() != baseline.read_bytes():
                        raise ValueError('Whole public-surface bytes differ: ' + mode)
                    check['byte_equal'] = True
                check['valid'] = True
                checks.append(check)
                write_json(out / 'checks.json', checks)
                print(lane + '-' + mode, record['exit_code'], record['status'], flush=True)
        if args.phase == 'baseline':
            write_json(out / 'archive-after.json', archive_inventory(cfg))
        if source_hashes() != EXPECTED or part_inventory() != expected_parts:
            raise ValueError('Source hashes or part inventory changed during capture')
        required = 2 if args.phase == 'baseline' else 39
        if len(results) != required or len(checks) != required or not all(check['valid'] for check in checks):
            raise ValueError('Required command/check inventory differs')
    except (AssertionError, OSError, ValueError, RuntimeError, KeyError, TypeError) as error:
        errors.append(repr(error))
    write_json(out / 'source-hashes-after.json', source_hashes())
    write_json(out / 'part-inventory-after.json', part_inventory())
    verdict = {'status': 'FAIL' if errors else 'PASS', 'phase': args.phase, 'errors': errors,
               'finished_utc': datetime.now(timezone.utc).isoformat(),
               'subprocess_count': sum(record['launched'] for record in results),
               'surface_count': sum('byte_equal' in check and check['mode'] != 'serializers' for check in checks),
               'serializer_count': sum(check['mode'] == 'serializers' for check in checks),
               'ownership_canary_count': sum(check['mode'].startswith('canary-') for check in checks),
               'scope': 'Frozen-source targeted verification only; full/native/exact merged gates remain separate.'}
    write_json(out / 'verification.json', verdict)
    if not errors and args.phase == 'baseline':
        names = ['capture.json', 'results.json', 'source-hashes.json', 'source-hashes-after.json',
                 'interpreter-layout.json', 'archive-before.json', 'archive-after.json', 'verification.json']
        manifest = {'status': 'PASS', 'phase': 'baseline', 'main_commit': cfg['main_baseline_commit'],
                    'bindings_sha256': args.bindings_sha256, 'probe_sha256': cfg['serializer_probe']['sha256'],
                    'archive_manifest_sha256': cfg['baseline_archive']['manifest_sha256'], 'source_hashes': EXPECTED,
                    'streams': {check['lane']: check['candidate'] for check in checks},
                    'evidence_bindings': {name: binding(out / name) for name in names}}
        write_json(out / 'serializer-baseline.json', manifest)
    print(json.dumps(verdict), flush=True)
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
