#!/usr/bin/env python3
"""Run the reviewed quest baseline and candidate under the canonical mirror lock."""
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

CANONICAL = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
CANDIDATE = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/6/ankiscape_fork')
CAPTURE = Path('/tmp/ankiscape-quest-capture-2026-09-05.py')
BINDINGS = Path('/tmp/ankiscape-quest-operational-bindings-2026-09-05.json')
BINDINGS_SHA256 = 'ea4687ce5e45b6d95df6011cffd4fe4fc880059ffbb3e0c4896dcabb84894598'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def verify_candidate(cfg, expected=None):
    head = subprocess.check_output(['git', '-C', str(CANDIDATE), 'rev-parse', 'HEAD'], text=True).strip()
    if head != cfg['candidate_head']:
        raise RuntimeError('Candidate HEAD changed; no remote commands launched')
    expected = cfg['candidate_source_hashes'] if expected is None else expected
    if {name: sha(CANDIDATE / name) for name in expected} != expected:
        raise RuntimeError('Frozen source bindings changed; no remote commands launched')
    inventory = sorted(str(path.relative_to(CANDIDATE)) for path in (CANDIDATE / 'data/quest').rglob('*.py'))
    if inventory != cfg['part_inventory']:
        raise RuntimeError('Quest part inventory changed; no remote commands launched')
    static = cfg['static_manifest']
    if sha(CANDIDATE / static['path']) != static['sha256']:
        raise RuntimeError('Static manifest changed; no remote commands launched')


def verify_baseline(cfg):
    archive = cfg['baseline_archive']
    source = Path(archive['source'])
    manifest_path = Path(archive['manifest_path'])
    if sha(manifest_path) != archive['manifest_sha256']:
        raise RuntimeError('Baseline manifest changed; sync blocked')
    manifest = json.loads(manifest_path.read_text())
    if (manifest['status'] != 'PASS_EXACT_GIT_ARCHIVE' or manifest['source'] != str(source)
            or manifest['commit'] != cfg['main_baseline_commit'] or len(manifest['files']) != 6133):
        raise RuntimeError('Baseline manifest identity differs; sync blocked')
    if (source / '.git').exists():
        raise RuntimeError('The baseline must remain the approved archive without Git metadata')
    expected = {entry['path']: entry for entry in manifest['files']}
    paths = set()
    for path in source.rglob('*'):
        if path.is_symlink():
            raise RuntimeError('Unexpected baseline symlink; sync blocked: ' + str(path))
        if path.is_file():
            paths.add(path.relative_to(source).as_posix())
    if len(expected) != 6133 or paths != set(expected):
        raise RuntimeError('Complete baseline inventory differs; sync blocked')
    for name, entry in expected.items():
        path = source / name
        raw = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        if (hashlib.sha256(raw).hexdigest() != entry['sha256'] or len(raw) != entry['bytes']
                or blob != entry['git_blob'] or bool(path.stat().st_mode & 0o111) != (entry['mode'] == '100755')):
            raise RuntimeError('Baseline file differs; sync blocked: ' + name)
    return {'status': 'PASS', 'files': 6133, 'manifest_sha256': archive['manifest_sha256']}


def local_canary(cfg):
    wrong = {**cfg['candidate_source_hashes'], 'data/quest_data.py': '0' * 64}
    try:
        verify_candidate(cfg, wrong)
    except RuntimeError as error:
        if str(error) != 'Frozen source bindings changed; no remote commands launched':
            raise
        return {'status': 'PASS', 'canary': str(error), 'remote_commands_launched': 0}
    raise RuntimeError('Local source canary failed to stop')


def remote_report(output, runner, phase):
    report = Path(output.splitlines()[0])
    if report.parent != runner.REMOTE_ROOT / 'reports' or not report.name.startswith('quest-' + phase + '-'):
        raise RuntimeError('Unexpected quest capture report path: ' + str(report))
    return report


def remote_hashes(runner, expected, label):
    output = runner._ssh('shasum -a 256 ' + ' '.join(shlex.quote(path) for path in expected),
                         label=label, repeat_safe=True)
    rows = [line.split(maxsplit=1) for line in output.splitlines()]
    observed = {row[1].strip(): row[0] for row in rows if len(row) == 2}
    if len(rows) != len(expected) or observed != expected:
        raise RuntimeError(label + ': remote hashes differ')


def launch(runner, phase, source_canary, baseline=None):
    arguments = ['/opt/homebrew/bin/python3', str(CAPTURE), '--phase', phase,
                 '--bindings-sha256', BINDINGS_SHA256]
    if source_canary:
        arguments.append('--source-hash-canary')
    if baseline is not None:
        arguments += ['--baseline-report', baseline['report'],
                      '--baseline-manifest-sha256', baseline['manifest_sha256']]
    command = shlex.join(arguments)
    original_command = runner._remote_lane_command
    try:
        runner._remote_lane_command = lambda lane: command
        return runner._stream_remote_run('quest-' + phase + ('-source-canary' if source_canary else '-capture'),
                                         timeout=300 if source_canary else 3600, poll_interval=5)
    finally:
        runner._remote_lane_command = original_command


def main():
    if sys.argv[1:] not in ([], ['--source-hash-canary']):
        raise RuntimeError('Unknown arguments; no remote commands launched')
    if sha(BINDINGS) != BINDINGS_SHA256:
        raise RuntimeError('Operational bindings changed; no remote commands launched')
    cfg = json.loads(BINDINGS.read_text())
    for path, digest in cfg['uploads'].items():
        if sha(Path(path)) != digest:
            raise RuntimeError('Frozen upload differs; no remote commands launched: ' + path)
    if sha(CANONICAL / 'tools/run_remote_tests.py') != cfg['runner']['sha256']:
        raise RuntimeError('Canonical runner changed; no remote commands launched')
    verify_candidate(cfg)
    baseline_archive = verify_baseline(cfg)
    guard = local_canary(cfg)
    if sys.argv[1:] == ['--source-hash-canary']:
        print(json.dumps({**guard, 'baseline_archive': baseline_archive}), flush=True)
        return 0
    spec = importlib.util.spec_from_file_location('quest_remote_runner', CANONICAL / 'tools/run_remote_tests.py')
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    summary = Path(tempfile.mkdtemp(prefix='quest-driver-')) / 'capture.json'
    record = {'status': 'RUNNING', 'bindings_sha256': BINDINGS_SHA256,
              'local_source_hash_canary': guard, 'baseline_archive': baseline_archive, 'phases': []}
    summary.write_text(json.dumps(record, indent=2) + '\n')
    print('Local driver record: ' + str(summary), flush=True)
    runner.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with runner.LOCAL_MIRROR_LOCK_PATH.open('a+', encoding='utf-8') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            runner._reconcile_pending_run()
            runner._preflight('plain')
            runner._preflight('qt')
            uploads = {**cfg['uploads'], str(BINDINGS): BINDINGS_SHA256}
            runner._run_with_retries(('rsync', '-a', '-e', runner.RSYNC_SSH, *uploads, f'{runner.HOST}:/tmp/'),
                                     label='upload reviewed quest capture and fixtures')
            remote_hashes(runner, uploads, 'quest upload hash check')
            baseline = None
            for phase in ('baseline', 'candidate'):
                verify_candidate(cfg)
                if phase == 'baseline':
                    record['baseline_archive_before_sync'] = verify_baseline(cfg)
                    source = Path(cfg['baseline_archive']['source'])
                else:
                    source = CANDIDATE
                summary.write_text(json.dumps(record, indent=2) + '\n')
                runner._sync(source)
                for source_canary in (True, False):
                    phase_record = {'phase': phase, 'source_hash_canary': source_canary, 'status': 'RUNNING'}
                    record['phases'].append(phase_record)
                    summary.write_text(json.dumps(record, indent=2) + '\n')
                    code, output = launch(runner, phase, source_canary, baseline)
                    phase_record.update(exit_code=code, output=output, status='TERMINAL')
                    summary.write_text(json.dumps(record, indent=2) + '\n')
                    report = remote_report(output, runner, phase)
                    verdict = json.loads(runner._ssh('cat ' + shlex.quote(str(report / 'verification.json')),
                                                    label='quest phase terminal verification', repeat_safe=True))
                    phase_record.update(report=str(report), verification=verdict)
                    summary.write_text(json.dumps(record, indent=2) + '\n')
                    if source_canary:
                        if code != 2 or verdict != {'status': 'FAIL', 'errors': [
                                'Source hash mismatch; no runtime commands launched'], 'subprocess_count': 0}:
                            raise RuntimeError('Remote source canary did not reject before runtime')
                        runner._ssh('test ! -e ' + shlex.quote(str(report / 'results.json')),
                                    label='quest source canary zero-job evidence', repeat_safe=True)
                        phase_record['results_json_absent'] = True
                    else:
                        expected = {'subprocess_count': 2, 'surface_count': 0, 'serializer_count': 2,
                                    'ownership_canary_count': 0} if phase == 'baseline' else {
                                    'subprocess_count': 39, 'surface_count': 23, 'serializer_count': 2,
                                    'ownership_canary_count': 6}
                        if (code != 0 or verdict.get('status') != 'PASS' or verdict.get('errors') != []
                                or verdict.get('phase') != phase
                                or any(verdict.get(key) != value for key, value in expected.items())):
                            raise RuntimeError('Quest capture did not pass its exact contract')
                        if phase == 'baseline':
                            raw = runner._ssh('cat ' + shlex.quote(str(report / 'serializer-baseline.json')),
                                              label='quest serializer baseline manifest', repeat_safe=True)
                            manifest = json.loads(raw)
                            if (manifest['status'] != 'PASS' or manifest['phase'] != 'baseline'
                                    or manifest['bindings_sha256'] != BINDINGS_SHA256
                                    or manifest['main_commit'] != cfg['main_baseline_commit']
                                    or manifest['archive_manifest_sha256'] != cfg['baseline_archive']['manifest_sha256']
                                    or manifest['source_hashes'] != cfg['baseline_source_hashes_or_required_absence']
                                    or manifest['probe_sha256'] != cfg['serializer_probe']['sha256']
                                    or set(manifest['streams']) != {'plain', 'qt'}):
                                raise RuntimeError('Fresh serializer baseline provenance differs')
                            expected_hashes = {str(report / name): entry['sha256']
                                               for name, entry in manifest['evidence_bindings'].items()}
                            expected_hashes.update({entry['path']: entry['sha256'] for entry in manifest['streams'].values()})
                            manifest_sha = hashlib.sha256(raw.encode()).hexdigest()
                            expected_hashes[str(report / 'serializer-baseline.json')] = manifest_sha
                            remote_hashes(runner, expected_hashes, 'quest serializer baseline evidence hash check')
                            baseline = {'report': str(report), 'manifest_sha256': manifest_sha, 'manifest': manifest}
                            record['serializer_baseline'] = baseline
                    verify_candidate(cfg)
                    summary.write_text(json.dumps(record, indent=2) + '\n')
            record['status'] = 'PASS'
            record['subprocess_count'] = 41
            summary.write_text(json.dumps(record, indent=2) + '\n')
        except Exception as error:
            record.update(status='FAIL', error=repr(error))
            summary.write_text(json.dumps(record, indent=2) + '\n')
            raise
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
    print(json.dumps({'status': 'PASS', 'local_record': str(summary),
                      'baseline_report': baseline['report'], 'candidate_report': str(report),
                      'subprocess_count': 41}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
