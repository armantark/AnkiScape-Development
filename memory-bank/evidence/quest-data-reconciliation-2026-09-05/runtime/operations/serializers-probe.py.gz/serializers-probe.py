#!/usr/bin/env python3
"""Emit ordered serializer outputs and the existing typed normalization."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
if Path.cwd() != ROOT:
    raise RuntimeError('Serializer probe requires the canonical mirror working directory')
sys.path.insert(0, str(ROOT))
import pkg_alias
from ankiscape.data import quest_data
from tools import module_surface

serializers = (
    ('quests', quest_data.quests_as_dict),
    ('references', quest_data.quest_references_as_dict),
    ('quest_unlocks', quest_data.quest_unlock_rules_as_dict),
    ('target_unlocks', quest_data.target_unlock_rules_as_dict),
    ('reward_items', quest_data.quest_reward_items_as_dict),
    ('claims', quest_data.claims_as_dict),
)
records = []
for name, function in serializers:
    value = function()
    records.append((name, value, module_surface._normalize(value, set())))
body = (json.dumps(records, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
sys.stdout.buffer.write(body)
sys.stdout.buffer.write(('QUEST_SERIALIZERS_SHA256: ' + hashlib.sha256(body).hexdigest() + '\n').encode())
