import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
import tempfile
from unittest.mock import patch

ROOT = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/combat-kill-reward-settlement')
sys.path.insert(0, str(ROOT))
from tools import run_remote_tests as remote

OUT = Path(tempfile.mkdtemp(prefix='ankiscape-combat-focused-', dir='/tmp'))
REMOTE_OUT = remote.REMOTE_ROOT / 'reports' / OUT.name
BASELINE = '221d5f5f3ee439e2be1bc06c76cf6a585b52b5eab621a2f86a74addb411c52f7'
SOURCES = {
    'logic_pure/logic_pure_combat_engine.py': '30377177ba69e1aa112a8d8b384cfd205d6d593133821bdbf74ce85fbcd323f6',
    'tests/combat/test_kill_rewards.py': '41cc273f999d760ecf7ee1ff2f27771a9f2c152b86802a688cccc99b311e087b',
    'tools/combat/compare_kill_rewards.py': '37d9d779f062fc37e0ade00464f0724a4a17d97ff21c3a4dd44c36ad0f35dde2',
}
SELECTORS = [
    'CombatKillRewardsTest', 'AutoBuryBonesTest',
    'CombatLogicTest.test_combat_burst_kills_once_awards_xp_and_rolls_source_backed_drops',
    'CombatLogicTest.test_combat_burst_chains_multiple_kills_within_tick_budget',
    'CombatLogicTest.test_vengeance_reflection_kill_counts_and_drops_normally',
    'CombatLogicTest.test_combat_burst_caps_to_one_kill_per_review_even_with_many_ticks',
    'CombatLogicTest.test_gargoyle_regeneration_is_tick_exact_across_review_boundaries',
    'CombatLogicTest.test_wall_beast_can_continue_after_helmet_swap_but_cannot_chain_a_respawn',
    'PrayerPassiveMechanicsTest.test_bonecrusher_precedes_auto_prayer_without_duplicate_xp_or_ticks',
    'PrayerPassiveMechanicsTest.test_bonecrusher_interception_adds_no_auto_burial_ticks',
    'PrayerPassiveMechanicsTest.test_prayer_urn_intercepts_ash_before_auto_prayer',
]
EV = ROOT / 'memory-bank/evidence/combat-kill-reward-settlement-2026-09-05'
expected = json.loads(gzip.decompress((EV / 'preflight.json.gz').read_bytes()))['sources_before']
actual = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in expected}
assert actual == expected and len(actual) == 769
assert all(actual[p] == digest for p, digest in SOURCES.items())
assert remote.HOST == 'armans-macbook-pro'
assert str(remote.REMOTE_REPO) == '/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork'
report = {'local_root': str(ROOT), 'local_output': str(OUT), 'remote_output': str(REMOTE_OUT), 'local_sources_before': actual, 'jobs': [], 'ownership': 'not_acquired'}

def save():
    (OUT / 'capture.json').write_text(json.dumps(report, indent=2) + '\n')

save()
print('CAPTURE_DIRECTORY', OUT, flush=True)

SETUP = '''import gzip,hashlib,json,os,sys
from pathlib import Path
root=Path(%r)
out=Path(%r)
assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
out.mkdir(parents=True,exist_ok=True)
ev=root/'memory-bank/evidence/combat-kill-reward-settlement-2026-09-05'
expected=json.loads(gzip.decompress((ev/'preflight.json.gz').read_bytes()))['sources_before']
actual={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
assert actual==expected and len(actual)==769
baseline=gzip.decompress((ev/'baseline-engine.py.gz').read_bytes())
assert len(baseline)==128059 and hashlib.sha256(baseline).hexdigest()==%r
(out/'baseline.py').write_bytes(baseline)
result={'sources':actual,'baseline_bytes':len(baseline),'baseline_sha256':hashlib.sha256(baseline).hexdigest(),'python':sys.executable,'version':sys.version,'optimize':sys.flags.optimize,'pythonoptimize_present':'PYTHONOPTIMIZE' in os.environ}
print(json.dumps(result,indent=2))
''' % (str(remote.REMOTE_REPO), str(REMOTE_OUT), BASELINE)

SNAPSHOT = '''import gzip,hashlib,json
from pathlib import Path
root=Path(%r)
ev=root/'memory-bank/evidence/combat-kill-reward-settlement-2026-09-05'
expected=json.loads(gzip.decompress((ev/'preflight.json.gz').read_bytes()))['sources_before']
actual={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
print(json.dumps(actual,indent=2))
assert actual==expected
''' % str(remote.REMOTE_REPO)

try:
    with remote.LOCAL_MIRROR_LOCK_PATH.open('a+', encoding='utf-8') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        report['ownership'] = 'acquired'
        save()
        try:
            remote._preflight('plain')
            remote._preflight('qt')
            remote._sync(ROOT)
            setup_command = shlex.join(['env', '-u', 'PYTHONOPTIMIZE', '/opt/homebrew/bin/python3', '-B', '-c', SETUP])
            setup = remote._ssh(setup_command, label='combat frozen source setup', repeat_safe=True)
            (OUT / 'remote-before.json').write_text(setup)
            assert json.loads(setup)['sources'] == actual
            for lane in ('plain', 'qt'):
                interpreter = '/opt/homebrew/bin/python3' if lane == 'plain' else str(remote.REMOTE_VENV / 'bin/python')
                environment = ['env', '-u', 'PYTHONOPTIMIZE', 'PATH=/opt/homebrew/bin:/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE=1', f'ANKISCAPE_GAME_MAIN={remote.REMOTE_GAME_MAIN}', f'ANKISCAPE_DARKAN_WORLD_SERVER={remote.REMOTE_DARKAN}']
                environment.append(f'PYTHONPATH={remote.REMOTE_PLAIN_SITE}' if lane == 'plain' else 'QT_QPA_PLATFORM=offscreen')
                for kind in ('comparison', 'focused'):
                    stem = f'{lane}-{kind}'
                    stdout_path, stderr_path = REMOTE_OUT / (stem + '.stdout'), REMOTE_OUT / (stem + '.stderr')
                    if kind == 'comparison':
                        arguments = ['tools/combat/compare_kill_rewards.py', '--baseline', str(REMOTE_OUT / 'baseline.py'), '--candidate-sha256', SOURCES['logic_pure/logic_pure_combat_engine.py'], '--output', str(REMOTE_OUT / (stem + '.json'))]
                    else:
                        arguments = ['run_tests.py', '--verbosity', '2', *SELECTORS]
                    command = shlex.join([*environment, interpreter, '-B', *arguments])
                    shell = '\n'.join((f'{command} > {shlex.quote(str(stdout_path))} 2> {shlex.quote(str(stderr_path))}', 'job_exit=$?', f'cat {shlex.quote(str(stdout_path))}', f'cat {shlex.quote(str(stderr_path))} >&2', 'exit "$job_exit"'))
                    job = {'lane': lane, 'kind': kind, 'command': command, 'remote_stdout': str(stdout_path), 'remote_stderr': str(stderr_path)}
                    report['jobs'].append(job)
                    save()
                    original_ssh = remote._ssh
                    def capture_ssh(command, *, label, repeat_safe=False):
                        if label == 'remote lane launch':
                            job['run'] = json.loads(remote._pending_path().read_text())
                            save()
                        return original_ssh(command, label=label, repeat_safe=repeat_safe)
                    with patch.object(remote, '_remote_lane_command', return_value=shlex.join(['/bin/sh', '-c', shell])), patch.object(remote, '_ssh', side_effect=capture_ssh):
                        code, output = remote._stream_remote_run('combat-' + stem, timeout=900, poll_interval=3)
                    job['exit_code'] = code
                    (OUT / (stem + '.log')).write_text(output)
                    for suffix, path in [('stdout', stdout_path), ('stderr', stderr_path), ('report', Path(job['run']['report_path']))]:
                        body = remote._ssh('cat ' + shlex.quote(str(path)), label='combat raw report read', repeat_safe=True)
                        (OUT / (stem + '.' + suffix)).write_text(body)
                    if kind == 'comparison':
                        remote_json = REMOTE_OUT / (stem + '.json')
                        body = remote._ssh('cat ' + shlex.quote(str(remote_json)), label='combat comparison payload read', repeat_safe=True)
                        (OUT / (stem + '.json')).write_text(body)
                    save()
                    print('TERMINAL_JOB', stem, code, flush=True)
                    if code != 0:
                        raise RuntimeError(f'{stem} failed with exit {code}; frozen artifacts retained')
                    if kind == 'comparison':
                        result = json.loads(body)
                        assert result['status'] == 'PASS' and len(result['cases']) == 32
                        assert result['sources_before'] == actual == result['sources_after']
                    else:
                        summary = remote.parse_unittest_summary(output)
                        assert summary.tests == 16 and summary.skipped == 0, summary
        finally:
            try:
                after = remote._ssh(shlex.join(['env', '-u', 'PYTHONOPTIMIZE', '/opt/homebrew/bin/python3', '-B', '-c', SNAPSHOT]), label='combat final source snapshot', repeat_safe=True)
                (OUT / 'remote-after.json').write_text(after)
                report['remote_sources_unchanged'] = json.loads(after) == actual
            finally:
                report['pending_record_exists'] = remote._pending_path().exists()
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
                report['ownership'] = 'released'
                save()
except BaseException as error:
    report['error'] = repr(error)
    save()
    raise
finally:
    report['local_sources_after'] = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in expected}
    report['local_sources_unchanged'] = report['local_sources_after'] == actual
    save()
