#!/usr/bin/env python3
"""Run the focused capture probe through the canonical remote-run guard."""
import argparse
import fcntl
import importlib.util
import json
from pathlib import Path
import shlex
import sys

CANONICAL = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
CANDIDATE = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/7/ankiscape_fork')
COMMAND = '/opt/homebrew/bin/python3 /tmp/ankiscape-pouch-capture-2026-09-05.py'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--canary', action='store_true')
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('capture_remote_runner', CANONICAL / 'tools/run_remote_tests.py')
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    runner._remote_lane_command = lambda lane: COMMAND
    lane = 'pouch-capture-canary' if args.canary else 'pouch-capture'
    runner.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with runner.LOCAL_MIRROR_LOCK_PATH.open('a+', encoding='utf-8') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            runner._reconcile_pending_run()
            if not args.canary:
                runner._preflight('plain')
                runner._preflight('qt')
                runner._sync(CANDIDATE)
            returncode, output = runner._stream_remote_run(lane, timeout=1800, poll_interval=5)
            if args.canary:
                if returncode != 2:
                    raise RuntimeError(f'Canary expected exit 2, received {returncode}')
                report = Path(output.splitlines()[0])
                if report.parent != runner.REMOTE_ROOT / 'reports' or not report.name.startswith('pouch-verification-'):
                    raise RuntimeError(f'Unexpected canary report directory: {report}')
                verification = json.loads(runner._ssh(
                    f'cat {shlex.quote(str(report / "verification.json"))} && '
                    f'test ! -e {shlex.quote(str(report / "results.json"))}',
                    label='canary source guard evidence', repeat_safe=True))
                if verification != {'status': 'FAIL', 'errors': ['Source hash mismatch; no runtime commands launched']}:
                    raise RuntimeError(f'Unexpected canary verification: {verification!r}')
                print('Canary source guard confirmed: no capture subprocesses launched.', flush=True)
            print(json.dumps({'lane': lane, 'returncode': returncode,
                              'scope': 'Focused capture probe; not full-gate evidence'}), flush=True)
            return returncode
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


if __name__ == '__main__':
    raise SystemExit(main())
