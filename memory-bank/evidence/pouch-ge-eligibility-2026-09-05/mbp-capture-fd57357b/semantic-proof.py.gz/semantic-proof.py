#!/usr/bin/env python3
"""Verify retained pouch evidence; never import or execute AnkiScape code."""
import ast
from collections import Counter
import copy
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
POOL7 = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/7/ankiscape_fork')
CONTRACT_ROOT = POOL7 / 'memory-bank/evidence/pouch-ge-eligibility-2026-09-05'
BASELINE = Path('/tmp/cut-gem-baseline-6438d422')
CANDIDATE = Path('/tmp/pouch-verification-0f715ccf')
CAPTURE_SCRIPT = Path('/tmp/ankiscape-pouch-capture-2026-09-05.py')
DISCOVERY = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/14/ankiscape_fork/memory-bank/source-audits/cut-gem-tradeability-implementation-2026-09-05/mbp/repair/discovery')
OUTPUT = Path('/tmp/ankiscape-pouch-semantic-proof-0f715ccf.json')
BASE_COMMIT = '6438d42256236992b10d921d4cca920293b55d93'
CONTRACT_SHA = 'fed0fe119fa61ed3aea965bc60d643fc383373d755189fe16ef94a9a81871513'
LIMITS_SHA = '5f211e7a07308bf357d2cf52244c4ee21c86ae7b4be1720fb22480125cfeab4d'
MODULES = (
    'core/constants.py', 'data/quest_data.py', 'data/combat_data.py',
    'data/slayer_data.py', 'logic_pure/logic_pure_combat_engine.py',
    'tests/test_combat_enemy_roster.py', 'logic/shop_logic.py',
    'ui/ui_tab_shop.py', 'data/achievement_diary_catalog.py',
    'runtime/runtime_actions_carried.py', 'runtime/runtime_actions_activities.py',
)
ALIASES = {
    'Vampire bat pouch': 2449,
    'Spirit cockatrice pouch': 2624, 'Spirit coraxatrice pouch': 2624,
    'Spirit guthatrice pouch': 2624, 'Spirit pengatrice pouch': 2624,
    'Spirit saratrice pouch': 2624, 'Spirit vulatrice pouch': 2624,
    'Spirit zamatrice pouch': 2624,
}
NEW_TESTS = [
    'skills.test_summoning_market.SummoningMarketTest.test_aliases_preserve_real_cache_entries_and_support_an_absent_cache',
    'skills.test_summoning_market.SummoningMarketTest.test_bought_pouches_exchange_at_bogrog_undo_and_sell_through_real_market',
    'skills.test_summoning_market.SummoningMarketTest.test_exact_cache_aliases_supply_value_and_exchangeability_without_renaming',
    'skills.test_summoning_market.SummoningMarketTest.test_registered_pouches_keep_identity_and_the_period_market_boundary',
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def binding(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def load_bound(path, expected_sha):
    raw = path.read_bytes()
    assert sha(raw) == expected_sha, ('Input hash mismatch', str(path))
    return json.loads(raw)


def read_payload(path):
    raw = path.read_bytes()
    body, footer = raw.rsplit(b'MODULE_SURFACE_SHA256: ', 1)
    digest = sha(body)
    assert footer == (digest + '\n').encode(), ('Invalid footer', str(path))
    lines = body.decode().splitlines(keepends=True)
    pairs = [line[5:].rstrip('\n').split(' = ', 1) for line in lines if line.startswith('NAME ')]
    assert len(pairs) == len(dict(pairs)), ('Duplicate exported name', str(path))
    return raw, body, lines, {key: json.loads(value) for key, value in pairs}, digest


def mapping(value, class_name='builtins.dict'):
    assert set(value) == {'class', 'items', 'type'}
    assert value['class'] == class_name and value['type'] == 'mapping'
    assert all(isinstance(pair, list) and len(pair) == 2 for pair in value['items'])
    result = dict(value['items'])
    assert len(result) == len(value['items']), 'Duplicate mapping key'
    return result


def normalized_mapping(value):
    return {'class': 'builtins.dict', 'type': 'mapping',
            'items': [[key, normalized_mapping(item) if isinstance(item, dict) else item]
                      for key, item in sorted(value.items())]}


def definitions(value):
    assert set(value) == {'class', 'items', 'type'}
    assert value['class'] == 'builtins.tuple' and value['type'] == 'sequence'
    rows = value['items']
    for row in rows:
        assert set(row) == {'class', 'fields', 'type'}
        assert row['class'] == 'ankiscape.core.item_registry.ItemDefinition'
        assert row['type'] == 'dataclass'
    result = {row['fields']['storage_key']: row for row in rows}
    assert len(result) == len(rows), 'Duplicate item identity'
    return result


def reverse_extra(old, new, baseline_shop, owners, deltas, baseline_defs):
    before, after = mapping(old), mapping(new)
    assert before.keys() == after.keys()
    assert {name for name in before if before[name] != after[name]} == deltas.keys()
    for name, delta in deltas.items():
        a, b = mapping(before[name]), mapping(after[name])
        assert before[name] == baseline_shop[name], name
        assert json.dumps(after[name], sort_keys=True) == json.dumps(owners[name], sort_keys=True), ('Restored metadata is not its unchanged owner', name)
        assert set(a) == {'category', 'source', 'tradeable'}
        assert set(b) == {'image', 'source', 'source_item_id'}
        assert a['category'] == 'material'
        assert a['tradeable'] is (name == 'Phoenix pouch')
        assert a['source'] == delta['source'][0] and b['source'] == delta['source'][1]
        assert b['source_item_id'] == delta['source_item_id'][1]
        asset = baseline_defs[name]['fields']['asset_path']
        assert asset.startswith('<repo>/') and b['image'] == asset.removeprefix('<repo>/')
    for pair in new['items']:
        if pair[0] in deltas:
            pair[1] = copy.deepcopy(before[pair[0]])
    assert new == old, 'Unexpected extra metadata or ordering change'


def reverse_overlay(old, new, baseline_extra, names):
    before, after = mapping(old), mapping(new)
    assert before.keys() - after.keys() == names and not after.keys() - before.keys()
    assert all(before[name] == baseline_extra[name] for name in names)
    expected = copy.deepcopy(old)
    expected['items'] = [pair for pair in expected['items'] if pair[0] not in names]
    assert json.dumps(new, sort_keys=True) == json.dumps(expected, sort_keys=True), 'Unexpected retained overlay metadata or ordering change'
    new['items'] = copy.deepcopy(old['items'])
    assert new == old


def reverse_definitions(old, new, deltas):
    before, after = definitions(old), definitions(new)
    assert list(before) == list(after)
    assert {name for name in before if before[name] != after[name]} == deltas.keys()
    for name, delta in deltas.items():
        expected = copy.deepcopy(before[name])
        for field, (old_value, new_value) in delta.items():
            assert expected['fields'][field] == old_value, (name, field)
            expected['fields'][field] = new_value
        assert json.dumps(after[name], sort_keys=True) == json.dumps(expected, sort_keys=True), name
        after[name]['fields'] = copy.deepcopy(before[name]['fields'])
    assert new == old, 'Unexpected definition metadata or ordering change'


def reverse_values(old, new):
    before, after = mapping(old), mapping(new)
    assert not before.keys() & ALIASES.keys()
    assert after.keys() - before.keys() == ALIASES.keys() and not before.keys() - after.keys()
    assert json.dumps({name: after[name] for name in ALIASES}, sort_keys=True) == json.dumps(ALIASES, sort_keys=True)
    new['items'] = [pair for pair in new['items'] if pair[0] not in ALIASES]
    assert new == old, 'An existing item value or its ordering changed'


def reverse_catalog(old, new, expected_rows):
    before = mapping(old, 'builtins.mappingproxy')
    after = mapping(new, 'builtins.mappingproxy')
    assert after.keys() - before.keys() == expected_rows.keys() and not before.keys() - after.keys()
    assert 'Ghast pouch' not in before and 'Ghast pouch' not in after
    assert before['Meerkats pouch'] == after['Meerkats pouch']
    assert mapping(after['Meerkats pouch'])['buy_limit'] == 100
    assert {name for name in before if before[name] != after[name]} == {'Phoenix pouch'}
    phoenix_before, phoenix_after = mapping(before['Phoenix pouch']), mapping(after['Phoenix pouch'])
    assert phoenix_before['source_item_id'] is None
    assert type(phoenix_after['source_item_id']) is int and phoenix_after['source_item_id'] == 14623
    assert phoenix_before['buy_limit'] == phoenix_after['buy_limit'] == 5000
    for name, expected in expected_rows.items():
        assert json.dumps(after[name], sort_keys=True) == json.dumps(normalized_mapping(expected), sort_keys=True), ('Unqualified GE row', name)
    for pair in after['Phoenix pouch']['items']:
        if pair[0] == 'source_item_id':
            pair[1] = None
    assert after['Phoenix pouch'] == before['Phoenix pouch']
    new['items'] = [pair for pair in new['items'] if pair[0] not in expected_rows]
    assert new == old, 'An existing catalog row or its ordering changed'


def verify_generated(qualified, global_source, captured_sha):
    relative = 'generated/grand_exchange_period_generated.py'
    argv = ['git', '-C', str(REPO), 'show', BASE_COMMIT + ':' + relative]
    baseline_raw = subprocess.check_output(argv)
    assert sha(baseline_raw) == '55188e1db6cf4509742bd644ea946eb0992e4bfacaf2b06f84733c244c0ffa3c'
    candidate_path = POOL7 / relative
    candidate_raw = candidate_path.read_bytes()
    assert sha(candidate_raw) == captured_sha == '92a960aaf7474965bc9d664fce449d12ce4de39db0ad8cbd6c39b15fd6210252'
    trees = [ast.parse(raw) for raw in (baseline_raw, candidate_raw)]
    assignments = [{node.targets[0].id: node.value for node in tree.body
                    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)} for tree in trees]
    old = {key: ast.literal_eval(value) for key, value in assignments[0].items()}
    new = {key: ast.literal_eval(value) for key, value in assignments[1].items()}
    assert old.keys() == new.keys()
    assert [key for key in old if old[key] != new[key]] == ['PERIOD_GE_BUY_LIMITS']
    assert old['PERIOD_GE_BUY_LIMIT_SOURCE'] == new['PERIOD_GE_BUY_LIMIT_SOURCE'] == global_source
    limits_before, limits_after = old['PERIOD_GE_BUY_LIMITS'], new['PERIOD_GE_BUY_LIMITS']
    assert not limits_before.keys() & qualified.keys()
    assert limits_after == {**limits_before, **{name: 5000 for name in qualified}}
    assert all(type(limits_after[name]) is int and limits_after[name] == 5000 for name in qualified)
    assert len(limits_before) == 1753 and len(limits_after) == 1830
    assert not old['PERIOD_GE_GUIDE_PRICES'].keys() & qualified.keys()
    assert not old['PERIOD_GE_PRICE_PROVENANCE'].keys() & qualified.keys()
    node = assignments[1]['PERIOD_GE_BUY_LIMITS']
    removed_lines = set()
    for key, value in zip(node.keys, node.values):
        if ast.literal_eval(key) in qualified:
            assert key.lineno == key.end_lineno == value.lineno == value.end_lineno
            removed_lines.add(key.lineno)
    assert len(removed_lines) == 77
    reversed_raw = b''.join(line for index, line in enumerate(candidate_raw.splitlines(keepends=True), 1)
                           if index not in removed_lines)
    assert reversed_raw == baseline_raw, 'Generated file has a change beyond the 77 qualified rows'
    return {'baseline': {'repo': str(REPO), 'commit': BASE_COMMIT, 'path': relative,
                         'read_only_argv': argv, 'bytes': len(baseline_raw), 'sha256': sha(baseline_raw)},
            'candidate': binding(candidate_path), 'before_count': len(limits_before),
            'after_count': len(limits_after), 'additions': {name: 5000 for name in sorted(qualified)},
            'all_other_assignments_identical': True, 'reversed_file_byte_exact': True,
            'reversed_sha256': sha(reversed_raw)}


def main(proof):
    contract_path = CONTRACT_ROOT / 'review-resolved-runtime-invariance.json'
    limits_path = CONTRACT_ROOT / 'qualified-buy-limits.json'
    contract = load_bound(contract_path, CONTRACT_SHA)
    limits = load_bound(limits_path, LIMITS_SHA)
    assert contract['errors'] == [] and contract['aliases'] == ALIASES
    qualified = {row['registered_name']: row for row in limits['additions']}
    assert len(qualified) == len(limits['additions']) == 77
    assert len({row['id'] for row in qualified.values()}) == 77
    assert set(qualified) == set(contract['added_limit_and_ge_names'])
    assert all(row['limit'] == 5000 for row in qualified.values())
    assert not {'Phoenix pouch', 'Meerkats pouch', 'Ghast pouch'} & qualified.keys()
    deltas = contract['definition_deltas']
    assert len(deltas) == 78 and deltas.keys() == qualified.keys() | {'Phoenix pouch'}
    assert Counter(field for delta in deltas.values() for field in delta) == Counter({'source': 78, 'source_item_id': 78, 'tradeable': 77})
    for name, delta in deltas.items():
        assert set(delta) == ({'source', 'source_item_id'} if name == 'Phoenix pouch' else {'source', 'source_item_id', 'tradeable'})
        assert delta['source_item_id'] == [None, 14623 if name == 'Phoenix pouch' else qualified[name]['id']]
        if name != 'Phoenix pouch':
            assert delta['tradeable'][0] is False and delta['tradeable'][1] is True
    proof['contracts'] = [binding(contract_path), binding(limits_path)]
    script_raw = CAPTURE_SCRIPT.read_bytes()
    assert sha(script_raw) == '99f491c6ffd319899fef6008e5619a53ac3f3842ae20059f094a9d71cd83a5e0'
    expected = next(ast.literal_eval(node.value) for node in ast.parse(script_raw).body
                    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'EXPECTED' for target in node.targets))
    source = json.loads((CANDIDATE / 'source-hashes.json').read_bytes())
    source_after = json.loads((CANDIDATE / 'source-hashes-after.json').read_bytes())
    assert len(expected) == 8 and source['expected'] == source['actual'] == source_after == expected
    proof['source_binding'] = {'capture_script': binding(CAPTURE_SCRIPT), 'hashes': expected,
                               'before': binding(CANDIDATE / 'source-hashes.json'),
                               'after': binding(CANDIDATE / 'source-hashes-after.json')}
    proof['generated_maps'] = verify_generated(qualified, limits['global_source'], expected['generated/grand_exchange_period_generated.py'])
    required = [lane + '-' + module.replace('/', '_') + '.stdout'
                for lane in ('plain', 'qt') for module in (*MODULES, *(('__init__.py',) if lane == 'qt' else ()))]
    assert len(required) == len(set(required)) == 23
    assert {path.name for path in CANDIDATE.glob('*.py.stdout')} == set(required)
    assert {path.name for path in BASELINE.glob('*.py.stdout')} == set(required) | {'plain-__init__.py.stdout'}
    control = BASELINE / 'plain-__init__.py.stdout'
    assert control.read_bytes() == b''
    proof['extra_baseline_control'] = {**binding(control), 'role': 'Unavailable plain root control; outside the required 23 payloads'}
    baseline_core = read_payload(BASELINE / 'plain-core_constants.py.stdout')[3]
    baseline_root = read_payload(BASELINE / 'qt-__init__.py.stdout')[3]
    owners = mapping(baseline_core['SUMMONING_EXTRA_ITEM_DATA'])
    old_extra = mapping(baseline_core['EXTRA_ITEM_DATA'])
    old_shop = mapping(baseline_core['SHOP_ONLY_EXTRA_ITEM_DATA'])
    old_defs = definitions(baseline_core['ITEM_DEFINITIONS'])
    baseline_values = mapping(baseline_root['ITEM_VALUES'])
    assert not baseline_values.keys() & ALIASES.keys()
    expected_values = {**baseline_values, **ALIASES}
    expected_rows = {}
    for name, qualification in qualified.items():
        item = old_defs[name]['fields']
        value = expected_values[name]
        assert isinstance(value, int) and not isinstance(value, bool) and value > 0
        expected_rows[name] = {
            'asset_path': item['asset_path'], 'buy_limit': 5000, 'buy_limit_source': limits['global_source'],
            'cache_value': value, 'category': item['category'], 'exchangeable': True,
            'guide_price': value, 'guide_price_provenance': {}, 'guide_price_source': 'cache_value_fallback',
            'high_alchemy_value': int(value * 0.6), 'item_id': item['id'], 'item_name': name,
            'low_alchemy_value': int(value * 0.4), 'required_level': item['required_level'],
            'source_item_id': qualification['id'], 'source_role': 'general', 'tradeable': True,
        }
    expected_exports = {
        'core_constants.py': {'EXTRA_ITEM_DATA', 'ITEM_DEFINITIONS', 'SHOP_ONLY_EXTRA_ITEM_DATA'},
        'logic_shop_logic.py': {'EXTRA_ITEM_DATA'},
        'runtime_runtime_actions_carried.py': {'ITEM_DEFINITIONS', 'ITEM_VALUES'},
        'runtime_runtime_actions_activities.py': {'ITEM_DEFINITIONS'},
        '__init__.py': {'GE_ITEM_CATALOG', 'ITEM_VALUES'},
    }
    proof['payloads'] = []
    for filename in required:
        proof['stage'] = filename
        old_raw, old_body, old_lines, old, old_digest = read_payload(BASELINE / filename)
        new_raw, new_body, new_lines, new, new_digest = read_payload(CANDIDATE / filename)
        assert list(old) == list(new), ('Changed exports or order', filename)
        assert [line for line in old_lines if not line.startswith('NAME ')] == [line for line in new_lines if not line.startswith('NAME ')]
        changed = {key for key in old if old[key] != new[key]}
        assert changed == expected_exports.get(filename.split('-', 1)[1].removesuffix('.stdout'), set()), filename
        if filename.endswith('core_constants.py.stdout'):
            assert old['SUMMONING_EXTRA_ITEM_DATA'] == new['SUMMONING_EXTRA_ITEM_DATA'] == baseline_core['SUMMONING_EXTRA_ITEM_DATA']
            for name, source_id in [('Meerkats pouch', 19622), ('Ghast pouch', 21444)]:
                assert mapping(new['EXTRA_ITEM_DATA'])[name] == old_extra[name]
                assert definitions(new['ITEM_DEFINITIONS'])[name] == old_defs[name]
                assert old_defs[name]['fields']['source_item_id'] == source_id
        fixed = copy.deepcopy(new)
        for key in changed:
            reference = baseline_root if key in {'GE_ITEM_CATALOG', 'ITEM_VALUES'} else baseline_core
            assert old[key] == reference[key], ('Inconsistent baseline export', filename, key)
            if key == 'EXTRA_ITEM_DATA':
                reverse_extra(old[key], fixed[key], old_shop, owners, deltas, old_defs)
            elif key == 'SHOP_ONLY_EXTRA_ITEM_DATA':
                reverse_overlay(old[key], fixed[key], old_extra, set(deltas))
            elif key == 'ITEM_DEFINITIONS':
                reverse_definitions(old[key], fixed[key], deltas)
            elif key == 'ITEM_VALUES':
                reverse_values(old[key], fixed[key])
            elif key == 'GE_ITEM_CATALOG':
                assert filename == 'qt-__init__.py.stdout'
                reverse_catalog(old[key], fixed[key], expected_rows)
            else:
                raise AssertionError(('Unknown changed export', filename, key))
        assert fixed == old, ('Whole object reversal differs', filename)
        rebuilt = ''.join(
            'NAME ' + line[5:].split(' = ', 1)[0] + ' = ' + json.dumps(
                fixed[line[5:].split(' = ', 1)[0]], ensure_ascii=True, separators=(',', ':'), sort_keys=True) + '\n'
            if line.startswith('NAME ') else line for line in new_lines).encode()
        assert rebuilt == old_body, ('Complete reversed body differs', filename)
        if not changed:
            assert new_raw == old_raw, ('Unchanged raw payload differs', filename)
        proof['payloads'].append({'file': filename,
                                  'baseline': {**binding(BASELINE / filename), 'body_sha256': old_digest},
                                  'candidate': {**binding(CANDIDATE / filename), 'body_sha256': new_digest},
                                  'changed_exports': sorted(changed), 'reversed_body_sha256': sha(rebuilt),
                                  'reversed_body_byte_equal': True})
    assert sum(bool(row['changed_exports']) for row in proof['payloads']) == 9
    proof['qualified_delta'] = {'definition_deltas': deltas, 'aliases': ALIASES,
                               'restored_raw_owner_names': sorted(deltas), 'removed_overlay_names': sorted(deltas),
                               'new_ge_rows': expected_rows, 'phoenix_ge_delta': {'source_item_id': [None, 14623]},
                               'meerkats_and_ghast_unchanged': True}
    proof['stage'] = 'discovery'
    proof['discovery'] = []
    for lane in ('plain', 'qt'):
        baseline_path = DISCOVERY / f'baseline-{lane}.stdout.gz'
        old_raw = gzip.decompress(baseline_path.read_bytes())
        assert sha(old_raw) == 'da52c1f1ad36b961d1958b87ca5d310803a08e8131dd587f147d3cbba53e1cfa'
        candidate_path = CANDIDATE / f'{lane}-discovery.stdout'
        new_raw = candidate_path.read_bytes()
        old_ids, new_ids = old_raw.decode().splitlines(), new_raw.decode().splitlines()
        assert len(old_ids) == 5562 and len(new_ids) == 5566
        assert Counter(new_ids) == Counter(old_ids) + Counter(NEW_TESTS)
        assert [test_id for test_id in new_ids if test_id not in NEW_TESTS] == old_ids
        assert (CANDIDATE / f'{lane}-discovery.stderr').read_bytes() == b''
        proof['discovery'].append({'lane': lane, 'baseline': binding(baseline_path),
                                   'baseline_raw_sha256': sha(old_raw), 'candidate': binding(candidate_path),
                                   'before_count': len(old_ids), 'after_count': len(new_ids),
                                   'added': dict(Counter(NEW_TESTS)), 'removed': {}})
    results = json.loads((CANDIDATE / 'results.json').read_bytes())
    assert len(results) == 27 and all(row['exit_code'] == 0 for row in results)
    original_report = CANDIDATE / 'verification.json'
    assert sha(original_report.read_bytes()) == 'a387078e2068a17eaab388261ae2d28274a1020943c80400daeda9c7785036c7'
    assert json.loads(original_report.read_bytes())['status'] == 'FAIL'
    proof['original_failed_capture'] = binding(original_report)
    proof.update(status='PASS', required_payloads=23, changed_payloads=9, byte_identical_payloads=14,
                 scope='Historical source, semantic delta, generated-map preservation and discovery proof only. Focused parser reconciliation, full gates and native acceptance are separate.')
    proof.pop('stage', None)


if __name__ == '__main__':
    result = {'status': 'FAIL', 'baseline_directory': str(BASELINE), 'candidate_directory': str(CANDIDATE)}
    try:
        main(result)
    except (AssertionError, OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        result['error'] = repr(error)
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'proof_path': str(OUTPUT),
                      'proof_sha256': sha(OUTPUT.read_bytes()), 'error': result.get('error')}))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)
