#!/usr/bin/env python3
"""Capture Summoning pouch verification evidence after the driver has synced the mirror."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
BASELINE = ROOT.parent / 'reports/cut-gem-baseline-6438d422'
SELECTORS = ['skills.test_summoning_market.',
 'test_item_values.',
 'test_item_values_aliases.',
 'test_grand_exchange_data.',
 'test_grand_exchange_logic.',
 'test_shop_data.',
 'test_shop_logic.',
 'test_summoning_data.',
 'test_summoning_logic.',
 'test_undo_seam_summoning.',
 'test_direct_action_undo_seam.']
EXPECTED = {'core/constants.py': 'a354b29d81c197874b9ff6407b8f2024ffabd156504ce398c714302f30362fd0',
 'data/item_values.py': '5815a838b702b22d2788f9ad258bd85b3abd20bc246df4aceb673feedda7f785',
 'generated/grand_exchange_period_generated.py': '92a960aaf7474965bc9d664fce449d12ce4de39db0ad8cbd6c39b15fd6210252',
 'tests/test_grand_exchange_data.py': '0b130085606b0a8963f30424ee759d8f99d8f31db744440723ced633e7920f53',
 'tests/skills/test_summoning_market.py': 'f29db0aec8342f6faf66f1350605ebc11047ae35ff40d9f44ec747ab3e403730',
 'tools/module_surface.py': 'a66948b912691279dc951ac9e5aa0c144b75a351c9b1bb46b88f67d85ebcf1e5',
 'tests/test_module_surface.py': 'ba48d8b3afbfd957a1298846b263eb9358e5ebf3415d93be1adf76262a65c25f',
 'run_tests.py': '4ce89f5dd8c70693977140fbc42bef571cdcada3d97e61671d0e873f0653bb33'}
MODULES = ['core/constants.py',
 'data/quest_data.py',
 'data/combat_data.py',
 'data/slayer_data.py',
 'logic_pure/logic_pure_combat_engine.py',
 'tests/test_combat_enemy_roster.py',
 'logic/shop_logic.py',
 'ui/ui_tab_shop.py',
 'data/achievement_diary_catalog.py',
 'runtime/runtime_actions_carried.py',
 'runtime/runtime_actions_activities.py']

EXPECTED_SELECTED_COUNT = 218
EXPECTED_SELECTED_SHA256 = '659a7bb72dce4b7a19a49f5c6a94358bef759abb9e83eeac244b82caa2c58d62'


def selected_ids_sha256(ids):
    return hashlib.sha256(("\n".join(sorted(ids)) + "\n").encode()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def source_hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            if (ROOT / name).is_file() else None for name in EXPECTED}


def payload_integrity(path):
    record = {'path': str(path), 'valid': False}
    try:
        raw = path.read_bytes()
        record.update(bytes=len(raw), file_sha256=hashlib.sha256(raw).hexdigest())
        body, footer = raw.rsplit(b'MODULE_SURFACE_SHA256: ', 1)
        digest = hashlib.sha256(body).hexdigest()
        recorded = footer.decode('ascii').strip()
        record.update(body_sha256=digest, footer_sha256=recorded,
                      valid=digest == recorded)
        if not record['valid']:
            record['error'] = 'Body digest does not match footer'
    except (OSError, ValueError, UnicodeError) as error:
        record['error'] = repr(error)
    return record


def main():
    out = Path(tempfile.mkdtemp(prefix='pouch-verification-', dir=ROOT.parent / 'reports'))
    print(str(out), flush=True)
    started = datetime.now(timezone.utc).isoformat()
    actual = source_hashes()
    write_json(out / 'source-hashes.json', {'expected': EXPECTED, 'actual': actual})
    write_json(out / 'capture.json', {
        'started_utc': started, 'repo': str(ROOT), 'baseline': str(BASELINE),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'selectors': SELECTORS, 'timeout_seconds_per_process': 300,
        'expected_selected_count': EXPECTED_SELECTED_COUNT,
        'expected_selected_ids_sha256': EXPECTED_SELECTED_SHA256,
        'excluded_tests': [],
        'selection_basis': '214 retained baseline discovery IDs plus the four current skills.test_summoning_market methods; generated-count case included because frozen maps match its assertions',
        'candidate_commit': 'fd57357bd5f91f760a9a572351466759cc5da713',
        'baseline_compatibility': {
            'baseline_commit': '6438d42256236992b10d921d4cca920293b55d93',
            'candidate_parent_commit': '1932b3c07b5dd8bdb598889f2f503607ac92b791',
            'author_static_git_diff_check': 'All differing paths are under memory-bank; product, tools, and tests are identical',
            'non_document_path_differences': [],
        },
    })
    if actual != EXPECTED:
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': ['Source hash mismatch; no runtime commands launched']})
        return 2
    tree = ast.parse((ROOT / 'tests/test_module_surface.py').read_text())
    modules = list(next(ast.literal_eval(node.value) for node in tree.body
                        if isinstance(node, ast.Assign) and any(
                            isinstance(target, ast.Name) and target.id == 'FIRST_WAVE_DIGESTS'
                            for target in node.targets)))
    if modules != MODULES:
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': ['FIRST_WAVE_DIGESTS differs from the explicit 11 required modules']})
        return 2
    required_names = [lane + '-' + module.replace('/', '_') + '.stdout'
                      for lane in ('plain', 'qt')
                      for module in [*MODULES, *(['__init__.py'] if lane == 'qt' else [])]]
    baseline_files = [BASELINE / name for name in required_names]
    available_names = {path.name for path in BASELINE.glob('*.py.stdout')}
    control = BASELINE / 'plain-__init__.py.stdout'
    excluded = []
    errors = []
    if control.is_file():
        raw_control = control.read_bytes()
        excluded.append({'path': str(control), 'bytes': len(raw_control),
                         'sha256': hashlib.sha256(raw_control).hexdigest(),
                         'role': 'Unavailable plain root control; excluded only if empty'})
        if raw_control:
            errors.append('Unexpected nonempty baseline plain root control')
    if available_names - set(required_names) - {'plain-__init__.py.stdout'}:
        errors.append('Unexpected baseline payload files outside the required 23 and plain root control')
    write_json(out / 'baseline-files.json', {'required': [str(path) for path in baseline_files],
                                            'available': sorted(available_names), 'excluded': excluded})
    baseline_integrity = [payload_integrity(path) for path in baseline_files]
    write_json(out / 'baseline-integrity.json', baseline_integrity)
    if not all(row['valid'] for row in baseline_integrity):
        errors.append('A required baseline payload is missing or has an invalid footer')
    results = []
    surfaces = []
    focus_checks = []
    for lane, python in [('plain', '/opt/homebrew/bin/python3'),
                         ('qt', str(ROOT.parent / '.venv-qt/bin/python'))]:
        env = {**os.environ, 'PATH': '/opt/homebrew/bin:/usr/bin:/bin',
               'QT_QPA_PLATFORM': 'offscreen',
               'ANKISCAPE_GAME_MAIN': str(ROOT.parent / 'sources/game-main'),
               'ANKISCAPE_DARKAN_WORLD_SERVER': str(ROOT.parent / 'sources/darkan-world-server')}
        env.pop('PYTHONPATH', None)
        if lane == 'plain':
            env['PYTHONPATH'] = str(ROOT.parent / 'plain-site')
        jobs = [('focus', ['run_tests.py', *SELECTORS, '--verbosity', '2']),
                ('discovery', ['run_tests.py', '--list', '--max-results', '10000'])]
        jobs += [(module.replace('/', '_'), ['tools/module_surface.py', module])
                 for module in [*modules, *(['__init__.py'] if lane == 'qt' else [])]]
        for mode, args in jobs:
            name = lane + '-' + mode
            argv = [python, *args]
            record = {'lane': lane, 'mode': mode, 'argv': argv, 'exit_code': None,
                      'stdout': name + '.stdout', 'stderr': name + '.stderr', 'status': 'running'}
            results.append(record)
            write_json(out / 'results.json', results)
            with (out / record['stdout']).open('wb') as stdout, (out / record['stderr']).open('wb') as stderr:
                try:
                    record['exit_code'] = subprocess.run(argv, cwd=ROOT, env=env,
                                                        stdout=stdout, stderr=stderr,
                                                        timeout=300).returncode
                    record['status'] = 'finished'
                except (OSError, subprocess.TimeoutExpired) as error:
                    record.update(status='error', error=repr(error))
            write_json(out / 'results.json', results)
            if record['exit_code'] != 0:
                errors.append(name + ': subprocess did not exit successfully')
            if mode == 'focus':
                stderr_text = (out / record['stderr']).read_text(errors='replace')
                outcomes = re.findall(r'^test_\S+ \(([^\n]+)\) \.\.\. (.+)$', stderr_text, re.MULTILINE)
                check = {'lane': lane, 'outcomes': outcomes,
                         'valid': len(outcomes) == EXPECTED_SELECTED_COUNT
                         and selected_ids_sha256([test_id for test_id, _ in outcomes]) == EXPECTED_SELECTED_SHA256
                         and all(status == 'ok' for _, status in outcomes)
                         and re.search(r'^Ran 218 tests in .+s$', stderr_text, re.MULTILINE) is not None
                         and re.search(r'^OK$', stderr_text, re.MULTILINE) is not None
                         and record['exit_code'] == 0}
                focus_checks.append(check)
                write_json(out / 'focused-verification.json', focus_checks)
                if not check['valid']:
                    errors.append(name + ': expected the complete 218-test selection to pass once each with no skips')
            elif mode == 'discovery':
                discovered = (out / record['stdout']).read_text(errors='replace').splitlines()
                selected = [test_id for test_id in discovered
                            if any(selector.casefold() in test_id.casefold() for selector in SELECTORS)]
                selection = {'lane': lane, 'selected_ids': selected,
                             'selected_ids_sha256': selected_ids_sha256(selected),
                             'valid': len(selected) == EXPECTED_SELECTED_COUNT
                             and selected_ids_sha256(selected) == EXPECTED_SELECTED_SHA256
                             and record['exit_code'] == 0}
                write_json(out / (lane + '-focused-discovery.json'), selection)
                if not selection['valid']:
                    errors.append(name + ': discovered focused IDs differ from the complete planned selection')
            else:
                integrity = payload_integrity(out / record['stdout'])
                surfaces.append(integrity)
                write_json(out / 'surface-integrity.json', surfaces)
                if not integrity['valid']:
                    errors.append(name + ': invalid surface payload')
            print(name, record['exit_code'], record['status'], flush=True)
    candidate_names = {Path(row['path']).name for row in surfaces}
    if len(surfaces) != 23 or candidate_names != {path.name for path in baseline_files}:
        errors.append('Candidate and baseline must have the same 23 payload filenames')
    final_hashes = source_hashes()
    write_json(out / 'source-hashes-after.json', final_hashes)
    if final_hashes != actual:
        errors.append('Source files changed during capture')
    verdict = {'status': 'FAIL' if errors else 'PASS', 'errors': errors,
               'finished_utc': datetime.now(timezone.utc).isoformat(),
               'scope': 'Capture integrity and focused tests only; semantic reversal and discovery comparison are pending',
               'surface_count': len(surfaces), 'subprocess_count': len(results)}
    write_json(out / 'verification.json', verdict)
    print(json.dumps(verdict), flush=True)
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
