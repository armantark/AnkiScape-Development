#!/usr/bin/env python3
"""Verify retained pouch test records without executing AnkiScape or editing captures."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/7/ankiscape_fork')
REPORT = Path('/tmp/pouch-verification-0f715ccf')
HARNESS = Path('/tmp/ankiscape-pouch-capture-2026-09-05.py')
OUTPUT = Path('/tmp/ankiscape-pouch-focused-parse-proof-0f715ccf.json')
EXPECTED_HEAD = 'fd57357bd5f91f760a9a572351466759cc5da713'
HARNESS_SHA256 = '99f491c6ffd319899fef6008e5619a53ac3f3842ae20059f094a9d71cd83a5e0'
SELECTED_COUNT = 218
SELECTED_SHA256 = '659a7bb72dce4b7a19a49f5c6a94358bef759abb9e83eeac244b82caa2c58d62'
INPUT_SHA256 = {
    'capture.json': 'aaad69a3de967068621fd551aeb0dc67712b8a5bc4dada5b9dca7fbf8673f43f',
    'source-hashes.json': '734e0ef0b1823942128346391a54a896d8ef39517b04bef4faf622990cb562f3',
    'source-hashes-after.json': '0b7d52c51b72c01b6006f9de8948bb8b2b4f9f3aaa56e4f1d578cc0a7daccb44',
    'verification.json': 'a387078e2068a17eaab388261ae2d28274a1020943c80400daeda9c7785036c7',
    'results.json': '5c5350f5ea1379a53bbd3c34e0d6c480aaacf4687f9afa26f85002bb5c77a510',
    'focused-verification.json': 'df4f906d0243f59107bdb52b8dad360a4fdaed4acdc84aed803ca7704c054a1c',
    'plain-focused-discovery.json': '7064f158fbb5492b087c11d0379e89d62ffbfb3c967fe7f00bad006615464118',
    'qt-focused-discovery.json': '423f4c65e18a26fccbb211f561254ae7604fa11fa77436efb078e8a9b3e64ba7',
    'plain-focus.stderr': 'cf0111fdbc9799e70e20bf43f776ceaa2b87489687fdd80320690d1aa6b8878b',
    'qt-focus.stderr': 'a880e6bfa7893eaa0398dd3ea092cae0de4d64a27276dd1e43122175723a038a',
}
OLD_PATTERN = r'^test_\S+ \(([^\n]+)\) \.\.\. (.+)$'
RECORD_PATTERN = r'^(test_\S+) \(([^\n]+)\)(?:\n([^\n]*))? \.\.\. (.+)$'
BINDINGS = {}


def read_bound(path):
    raw = path.read_bytes()
    record = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    if str(path) in BINDINGS:
        assert BINDINGS[str(path)] == record, 'An input changed while reading'
    BINDINGS[str(path)] = record
    if path.parent == REPORT and path.name in INPUT_SHA256:
        assert record['sha256'] == INPUT_SHA256[path.name], 'Pinned report input differs'
    return raw


def selected_digest(ids):
    return hashlib.sha256(('\n'.join(sorted(ids)) + '\n').encode()).hexdigest()


def git_state():
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, check=True,
                          capture_output=True, text=True).stdout.strip()
    status = subprocess.run(['git', 'status', '--porcelain'], cwd=ROOT, check=True,
                            capture_output=True, text=True).stdout
    assert head == EXPECTED_HEAD and status == '', 'Pool7 must remain at the exact clean candidate HEAD'
    return {'head': head, 'status_porcelain': status, 'clean': True}


def check_docstring(test_id, description):
    module, class_name, method_name = test_id.rsplit('.', 2)
    source_path = ROOT / 'tests' / (module.replace('.', '/') + '.py')
    tree = ast.parse(read_bound(source_path), filename=str(source_path))
    classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name]
    assert len(classes) == 1, 'Expected one source test class'
    methods = [node for node in classes[0].body
               if isinstance(node, ast.FunctionDef) and node.name == method_name]
    assert len(methods) == 1, 'Expected one source test method'
    docstring = ast.get_docstring(methods[0])
    assert docstring and docstring.splitlines()[0] == description, 'Raw description differs from exact AST docstring first line'
    return {'test_id': test_id, 'source': BINDINGS[str(source_path)],
            'method_line': methods[0].lineno, 'ast_docstring': docstring,
            'ast_first_line': docstring.splitlines()[0], 'raw_description': description,
            'exact_match': True}


def check_lane(lane, selectors, old_checks):
    selected = json.loads(read_bound(REPORT / (lane + '-focused-discovery.json')))
    discovery = read_bound(REPORT / (lane + '-discovery.stdout')).decode().splitlines()
    selected_ids = [test_id for test_id in discovery
                    if any(selector.casefold() in test_id.casefold() for selector in selectors)]
    assert selected['valid'] is True and selected['selected_ids'] == selected_ids, 'Focused discovery differs'
    assert len(selected_ids) == SELECTED_COUNT and len(set(selected_ids)) == SELECTED_COUNT, 'Selected ID count/uniqueness differs'
    assert selected_digest(selected_ids) == selected['selected_ids_sha256'] == SELECTED_SHA256, 'Planned selection digest differs'
    assert read_bound(REPORT / (lane + '-discovery.stderr')) == b'', 'Unexpected discovery stderr'
    assert read_bound(REPORT / (lane + '-focus.stdout')) == b'', 'Unexpected focused stdout'
    text = read_bound(REPORT / (lane + '-focus.stderr')).decode()
    old_outcomes = re.findall(OLD_PATTERN, text, re.MULTILINE)
    old = next(row for row in old_checks if row['lane'] == lane)
    assert old['valid'] is False and old['outcomes'] == [list(row) for row in old_outcomes], 'Historical parser rejection differs'
    assert len(old_outcomes) == 205 and all(status == 'ok' for _, status in old_outcomes), 'Unexpected original parsed outcomes'
    outcomes = []
    recovered = []
    cursor = 0
    for match in re.finditer(RECORD_PATTERN, text, re.MULTILINE):
        assert text[cursor:match.start()].strip() == '', 'Unmatched or unexpected test output before a record'
        method, test_id, description, status = match.groups()
        assert method == test_id.rsplit('.', 1)[-1], 'Printed test method and ID disagree'
        assert status == 'ok', 'A selected test failed, skipped, or had another non-passing status'
        outcomes.append((test_id, status))
        if description is not None:
            recovered.append({**check_docstring(test_id, description),
                              'raw_record_lines': match.group().splitlines(),
                              'stderr_start_line': text.count('\n', 0, match.start()) + 1})
        cursor = match.end()
    summary = re.fullmatch(r'\n\n-{70}\nRan 218 tests in ([0-9]+\.[0-9]+)s\n\nOK\n', text[cursor:])
    assert summary is not None, 'Unexpected trailing output or missing exact Ran 218 / OK summary'
    ids = [test_id for test_id, _ in outcomes]
    assert len(ids) == SELECTED_COUNT and len(set(ids)) == SELECTED_COUNT, 'Parsed outcome count/uniqueness differs'
    assert Counter(ids) == Counter(selected_ids) and selected_digest(ids) == SELECTED_SHA256, 'Parsed IDs differ from exact planned selection'
    assert len(recovered) == 13, 'Expected exactly thirteen recovered description records'
    assert {row['test_id'] for row in recovered} == set(ids) - {test_id for test_id, _ in old_outcomes}, 'Recovered records differ from original parser omissions'
    return {'lane': lane, 'status': 'PASS', 'tests': len(ids), 'unique_ids': len(set(ids)),
            'selected_ids_sha256': selected_digest(ids), 'outcomes': outcomes,
            'seconds': summary.group(1), 'skips': 0, 'unmatched_records': 0,
            'original_parser_outcomes': len(old_outcomes), 'recovered_count': len(recovered),
            'recovered_records': recovered}


def main(proof):
    proof['source_checkout_before'] = git_state()
    harness = read_bound(HARNESS)
    assert hashlib.sha256(harness).hexdigest() == HARNESS_SHA256, 'Original harness hash differs'
    assignments = {target.id: ast.literal_eval(node.value)
                   for node in ast.parse(harness).body if isinstance(node, ast.Assign)
                   for target in node.targets if isinstance(target, ast.Name)
                   and target.id in {'EXPECTED', 'SELECTORS', 'MODULES', 'EXPECTED_SELECTED_COUNT', 'EXPECTED_SELECTED_SHA256'}}
    assert assignments['EXPECTED_SELECTED_COUNT'] == SELECTED_COUNT and assignments['EXPECTED_SELECTED_SHA256'] == SELECTED_SHA256
    capture = json.loads(read_bound(REPORT / 'capture.json'))
    assert capture['script_sha256'] == HARNESS_SHA256 and capture['candidate_commit'] == EXPECTED_HEAD
    assert capture['selectors'] == assignments['SELECTORS'] and capture['excluded_tests'] == []
    assert capture['expected_selected_count'] == SELECTED_COUNT and capture['expected_selected_ids_sha256'] == SELECTED_SHA256
    source = json.loads(read_bound(REPORT / 'source-hashes.json'))
    after = json.loads(read_bound(REPORT / 'source-hashes-after.json'))
    assert len(assignments['EXPECTED']) == 8 and source['expected'] == source['actual'] == after == assignments['EXPECTED'], 'Eight capture source hashes disagree'
    for name, digest in source['actual'].items():
        assert hashlib.sha256(read_bound(ROOT / name)).hexdigest() == digest, 'Current candidate differs from a captured source file'
    proof['captured_source_hashes'] = source['actual']
    original = json.loads(read_bound(REPORT / 'verification.json'))
    assert original['status'] == 'FAIL' and original['errors'] == [
        lane + '-focus: expected the complete 218-test selection to pass once each with no skips'
        for lane in ('plain', 'qt')], 'Historical FAIL contains a different failure'
    proof['original_capture_verdict'] = original
    results = json.loads(read_bound(REPORT / 'results.json'))
    modules = assignments['MODULES']
    expected_modes = {(lane, mode) for lane in ('plain', 'qt')
                      for mode in ['focus', 'discovery', *[name.replace('/', '_') for name in modules],
                                   *(['__init__.py'] if lane == 'qt' else [])]}
    assert len(results) == len(expected_modes) == 27 and {(row['lane'], row['mode']) for row in results} == expected_modes, 'Capture does not contain all 27 unique commands'
    for row in results:
        assert row['exit_code'] == 0 and row['status'] == 'finished', 'A captured process did not finish successfully'
        for stream in ('stdout', 'stderr'):
            assert row[stream] == row['lane'] + '-' + row['mode'] + '.' + stream, 'Unexpected stream filename'
            read_bound(REPORT / row[stream])
    proof['subprocesses'] = results
    old_checks = json.loads(read_bound(REPORT / 'focused-verification.json'))
    assert len(old_checks) == 2 and {row['lane'] for row in old_checks} == {'plain', 'qt'}
    proof['lanes'] = [check_lane(lane, assignments['SELECTORS'], old_checks) for lane in ('plain', 'qt')]
    assert [row['test_id'] for row in proof['lanes'][0]['recovered_records']] == [row['test_id'] for row in proof['lanes'][1]['recovered_records']], 'Recovered IDs differ between lanes'
    proof['source_checkout_after'] = git_state()
    for record in list(BINDINGS.values()):
        read_bound(Path(record['path']))
    proof.update(status='PASS', scope='Separate retained-output parsing proof only. The historical capture remains FAIL for its parser rejection; no project runtime, full-suite, semantic, or native acceptance is claimed.')


if __name__ == '__main__':
    proof = {'status': 'FAIL', 'created_utc': datetime.now(timezone.utc).isoformat(),
             'script': {'path': str(Path(__file__)), 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
             'report_directory': str(REPORT), 'source_checkout': str(ROOT),
             'output_path': str(OUTPUT), 'record_pattern': RECORD_PATTERN}
    try:
        main(proof)
    except (AssertionError, OSError, ValueError, KeyError, TypeError, StopIteration, subprocess.CalledProcessError) as error:
        proof['error'] = repr(error)
    proof['input_bindings'] = list(BINDINGS.values())
    with OUTPUT.open('x') as stream:
        json.dump(proof, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': proof['status'], 'proof_path': str(OUTPUT),
                      'proof_sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(), 'error': proof.get('error')}))
    raise SystemExit(0 if proof['status'] == 'PASS' else 1)
