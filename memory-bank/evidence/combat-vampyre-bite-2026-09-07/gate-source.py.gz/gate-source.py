#!/usr/bin/env python3
"""Diff-aware AI-slop gate, run by the global pre-commit hook.

Every check is a ratchet: a commit is blocked only when the staged change
introduces a new violation or worsens an existing one. Edits that touch a
legacy hotspot without worsening it pass, so the gate never punishes
maintenance of old code. Analysis runs on staged blobs, never the working
tree, so unstaged edits cannot change the verdict.

Checks (thresholds overridable via SLOP_GATE_* env vars):
  - cyclomatic complexity per function  > 15   (lizard, all languages)
  - cognitive complexity per function   > 15   (complexipy, Python)
  - Halstead difficulty per function    > 80   (radon, Python)
  - lines per code file                 > 1000
  - new import cycles                          (scan cap: SLOP_GATE_GRAPH_MAX=4000)
  Moves do not ratchet: a Python def re-added with an identical normalized
  AST after being removed elsewhere in the same commit keeps its complexity,
  and a cycle whose new files trace back to files that already cycled is
  not new. A changed body, or a copy that leaves the original, still counts.
  - import fan-out per file             > 25   (SLOP_GATE_FAN_OUT)
  - code files per directory            > 40   (SLOP_GATE_DIR_FILES)
  - new dead code                              (vulture >= 90% confidence:
    unused imports and variables; functions sit at 60% and are excluded
    on purpose, a fresh public API looks identical to dead code)
  - new `any` in TypeScript added lines        (waive a deliberate one with
    a `slop-gate: allow` comment on the same line)
  - oxlint on staged JS/TS in any repo with a package.json; a repo without
    the Ultracite oxlint config is told how to add it (2026-09-02)
  - new PEP 8 layout violations (pycodestyle E30x blank lines between
    definitions, E70x several statements on one line), so a line budget is
    never paid with stripped spacing or semicolon joins (2026-09-02)

Not here, by design: coverage, CRAP, and mutation checks need a test run
and belong in CI, not in a commit hook.

Escape hatch: `git commit --no-verify` (humans only; agents are barred from
that flag by policy, which is the point of the gate).
"""

from __future__ import annotations

import ast
import csv
import hashlib
import json
import os
import posixpath
import re
import subprocess
import sys
import tempfile
from collections import Counter, defaultdict
from fnmatch import fnmatch
from pathlib import Path, PurePosixPath


def threshold(name: str, default: int) -> int:
    return int(os.environ.get(f"SLOP_GATE_{name}", default))


CCN_MAX = threshold("CCN", 15)
COGNITIVE_MAX = threshold("COGNITIVE", 15)
HALSTEAD_MAX = threshold("HALSTEAD", 80)
FILE_LINES_MAX = threshold("FILE_LINES", 1000)
FAN_OUT_MAX = threshold("FAN_OUT", 25)
DIR_FILES_MAX = threshold("DIR_FILES", 40)
GRAPH_MAX = threshold("GRAPH_MAX", 4000)
VULTURE_MIN_CONFIDENCE = threshold("VULTURE_CONFIDENCE", 90)

CODE_SUFFIXES = {
    ".py", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".vue", ".svelte",
    ".go", ".rs", ".java", ".kt", ".kts", ".swift", ".c", ".h", ".cc",
    ".cpp", ".hpp", ".m", ".mm", ".cs", ".rb", ".php", ".lua", ".sh",
}
JS_SUFFIXES = (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs")
SKIPPED_DIRS = {"node_modules", ".venv", "venv", "dist", "build", "vendor"}
JS_IMPORT_PATTERNS = (
    re.compile(
        r"\b(?:import|export)\s+(?:type\s+)?(?:[^;\"']*?\s+from\s*)?"
        r"[\"']([^\"']+)[\"']"
    ),
    re.compile(r"\bimport\s*\(\s*[\"']([^\"']+)[\"']\s*\)"),
    re.compile(r"\brequire\s*\(\s*[\"']([^\"']+)[\"']\s*\)"),
)

ANY_PATTERN = re.compile(r"\bas any\b|:\s*any\b|<any[,>\s]")
ANY_WAIVER = "slop-gate: allow"

# Vendored build output is not authored code: its complexity belongs to the
# bundler, and hashed filenames defeat the ratchet's identity anyway
# (2026-08-31, SvelteKit's minified route parser blocked an SPA refresh).
# `_app` is SvelteKit's immutable output directory, wherever it is served from.
EXCLUDED_GLOBS = [
    g
    for g in os.environ.get(
        "SLOP_GATE_EXCLUDE", "*/prebuilt/*,*/_app/*"
    ).split(",")
    if g
]


def git(*args: str) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(["git", *args], capture_output=True)


# Generated code is not authored code either: openapi-typescript, protoc,
# and friends all announce themselves in the file header, and their output
# grows with the schema, not with anyone's discipline (2026-09-01, a
# one-line schema.d.ts regeneration blocked a backend commit).
GENERATED_HEADER = re.compile(rb"auto-?generated|do not edit|@generated", re.IGNORECASE)


def declares_generated_blob(blob: bytes) -> bool:
    head = b"\n".join(blob.splitlines()[:5])
    return bool(GENERATED_HEADER.search(head))


def excluded_path(rel: str) -> bool:
    return any(part in SKIPPED_DIRS for part in PurePosixPath(rel).parts) or any(
        fnmatch(rel, glob) for glob in EXCLUDED_GLOBS
    )


def staged_paths() -> list[str]:
    out = git("diff", "--cached", "--name-only", "--diff-filter=ACMR", "-z")
    paths = [p for p in out.stdout.decode(errors="replace").split("\0") if p]
    return [
        p
        for p in paths
        if not excluded_path(p)
        and not declares_generated_blob(git("show", f":{p}").stdout)
    ]


def write_blob(root: Path, rel: str, ref: str) -> bool:
    """Materialize one blob (":path" = index, "HEAD:path") under root."""
    show = git("show", f"{ref}{rel}")
    if show.returncode != 0:
        return False
    dest = root / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(show.stdout)
    return True


def run_tool(argv: list[str], tool: str) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(argv, capture_output=True, text=True)
    if proc.returncode != 0 and not proc.stdout:
        sys.exit(
            f"slop-gate: {tool} failed to run; install it with"
            f" `uv tool install {tool}` or commit with --no-verify.\n"
            + proc.stderr
        )
    return proc


def ccn_by_function(root: Path) -> dict[tuple[str, str], int]:
    """Map (relative file, function name) -> worst CCN, via lizard --csv."""
    proc = run_tool(["lizard", "--csv", str(root)], "lizard")
    result: dict[tuple[str, str], int] = {}
    for row in csv.reader(proc.stdout.splitlines()):
        # Columns: NLOC, CCN, tokens, params, length, location, file, name, ...
        try:
            ccn, file_path, name = int(row[1]), row[6], row[7]
        except (IndexError, ValueError):
            continue
        rel = str(Path(file_path).relative_to(root))
        key = (rel, name)
        result[key] = max(result.get(key, 0), ccn)
    return result


def cognitive_by_function(root: Path) -> dict[tuple[str, str], int]:
    """Map (relative file, function name) -> cognitive complexity."""
    if not any(root.rglob("*.py")):
        return {}
    with tempfile.TemporaryDirectory(prefix="slop-cog-") as out_dir:
        run_tool(
            ["complexipy", str(root), "--output-format", "json",
             "--output", out_dir, "-q", "-i"],
            "complexipy",
        )
        report = Path(out_dir, "complexipy-results.json")
        rows = json.loads(report.read_text()) if report.exists() else []
    result: dict[tuple[str, str], int] = {}
    for row in rows:
        rel = str(Path(row["path"]).resolve().relative_to(root.resolve()))
        key = (rel, row["function_name"])
        result[key] = max(result.get(key, 0), int(row["complexity"]))
    return result


def halstead_by_function(root: Path) -> dict[tuple[str, str], float]:
    """Map (relative file, function name) -> Halstead difficulty."""
    py_files = [str(p) for p in root.rglob("*.py")]
    if not py_files:
        return {}
    proc = run_tool(["radon", "hal", "-f", "-j", *py_files], "radon")
    result: dict[tuple[str, str], float] = {}
    for file_path, report in json.loads(proc.stdout).items():
        if "error" in report:
            continue
        rel = str(Path(file_path).relative_to(root))
        for name, metrics in report.get("functions", {}).items():
            key = (rel, name)
            result[key] = max(result.get(key, 0.0), metrics["difficulty"])
    return result


def line_counts(root: Path, paths: list[str]) -> dict[str, int]:
    result = {}
    for rel in paths:
        f = root / rel
        if f.is_file() and Path(rel).suffix in CODE_SUFFIXES:
            result[rel] = f.read_bytes().count(b"\n")
    return result


def dead_code_findings(
    root: Path, moved_spans: dict[str, list[tuple[int, int]]] | None = None
) -> set[tuple[str, str]]:
    """Vulture findings for a snapshot of changed files, as (path, message).

    At >=90% confidence vulture reports only unused imports and variables,
    which are file-local judgments, so analyzing just the changed files is
    exact and cheap; no whole-tree pass is needed. `__init__.py` is exempt
    because re-exporting imports is that file's job. Line numbers are
    dropped so unrelated edits do not shift a pre-existing finding's
    identity.
    """
    if not root.is_dir():
        return set()
    proc = subprocess.run(
        ["vulture", str(root), "--min-confidence", str(VULTURE_MIN_CONFIDENCE),
         "--exclude", "*/tests/*,*/test_*.py,*_test.py,*/__init__.py"],
        capture_output=True, text=True,
    )
    findings = set()
    snapshot = root.resolve()  # macOS: /var/... reports as /private/var
    for line in proc.stdout.splitlines():
        path, _, rest = line.partition(":")
        line_number, _, message = rest.partition(":")
        message = message.strip()
        if message:
            rel = str(Path(path).resolve().relative_to(snapshot))
            if not inside_moved(rel, line_number, moved_spans or {}):
                findings.add((rel, message))
    return findings


def inside_moved(rel: str, line_number: str, spans: dict[str, list[tuple[int, int]]]) -> bool:
    """A finding inside a definition that only changed file is pre-existing debt."""
    try:
        line = int(line_number)
    except ValueError:
        return False
    return any(start <= line <= end for start, end in spans.get(rel, ()))


PEP8_LAYOUT_CODES = "E301,E302,E303,E305,E306,E701,E702,E703"


def pep8_layout_findings(
    root: Path, moved_spans: dict[str, list[tuple[int, int]]] | None = None
) -> Counter:
    """Count pycodestyle layout violations per (file, code), skipping moved code."""
    py_files = [str(p) for p in root.rglob("*.py")]
    if not py_files:
        return Counter()
    proc = run_tool(
        ["pycodestyle", f"--select={PEP8_LAYOUT_CODES}",
         "--format=%(path)s:%(row)d:%(code)s", *py_files],
        "pycodestyle",
    )
    findings: Counter = Counter()
    snapshot = root.resolve()
    for line in proc.stdout.splitlines():
        path, row, code = line.rsplit(":", 2)
        rel = str(Path(path).resolve().relative_to(snapshot))
        if not inside_moved(rel, row, moved_spans or {}):
            findings[(rel, code)] += 1
    return findings


def layout_ratchet(staged: Counter, head: Counter) -> list[str]:
    return [
        f"{rel}: {code} x{count} (was {head.get((rel, code), 0)})"
        for (rel, code), count in sorted(staged.items())
        if count > head.get((rel, code), 0)
    ]


def added_ts_any() -> list[tuple[str, str]]:
    """(file, added line) pairs that introduce a TypeScript `any`."""
    diff = git(
        "diff", "--cached", "-U0", "--diff-filter=ACMR",
        "--", "*.ts", "*.tsx",
    ).stdout.decode(errors="replace")
    hits, current = [], ""
    for line in diff.splitlines():
        if line.startswith("+++ b/"):
            current = line[6:]
        elif line.startswith("+") and not line.startswith("+++"):
            text = line[1:]
            if ANY_PATTERN.search(text) and ANY_WAIVER not in text and not excluded_path(current):
                hits.append((current, text.strip()))
    return hits


OXLINT_CONFIGS = ("oxlint.config.ts", "oxlint.config.js", "oxlint.config.mjs", ".oxlintrc.json")
# --skip-install because npm 11 rejects the installer's --allow-scripts flag in
# project-scoped installs; the init also sets "type": "module" in package.json.
ULTRACITE_INIT = (
    "npx -y ultracite init --linter oxlint --js-plugins anti-slop --quiet"
    " --skip-install && npm install"
)


def oxlint_reports(paths: list[str]) -> list[tuple[str, list[str], str]]:
    """Lint staged JS/TS through the repo's oxlint, or demand the config.

    Only repos with a package.json count as JS projects. oxlint reads the
    working tree, which equals the index for a normal commit.
    """
    js = [p for p in paths if PurePosixPath(p).suffix in JS_SUFFIXES]
    if not js or not Path("package.json").exists():
        return []
    if not any(Path(c).exists() for c in OXLINT_CONFIGS):
        return [(
            "JavaScript/TypeScript was staged in a repo without the Ultracite oxlint config:",
            js,
            f"Run `{ULTRACITE_INIT}`, then revert the `\"type\": \"module\"` it adds"
            " if the project is CommonJS, and turn off `no-module-mocking` only"
            " where tests need it.",
        )]
    binary = Path("node_modules/.bin/oxlint")
    if not binary.exists():
        return [(
            "oxlint is configured but not installed:",
            js,
            "Run `npm install` so node_modules/.bin/oxlint exists.",
        )]
    proc = subprocess.run([str(binary), *js], capture_output=True, text=True)
    if proc.returncode == 0:
        return []
    rows = [line for line in (proc.stdout + proc.stderr).splitlines() if ": error " in line]
    return [(
        "oxlint reported errors:",
        rows[:40] or [proc.stdout.strip() or proc.stderr.strip()],
        "Fix the finding; a rule that does not fit this repo is turned off in"
        " its oxlint config, not waived inline.",
    )]


def code_entries(args: tuple[str, ...], id_field: int) -> dict[str, str]:
    """Map repo-relative code path -> blob ID from ls-files/ls-tree output."""
    entries = {}
    for raw in git(*args).stdout.split(b"\0"):
        metadata, tab, path = raw.partition(b"\t")
        rel = path.decode(errors="replace")
        if tab and PurePosixPath(rel).suffix in CODE_SUFFIXES and not excluded_path(rel):
            entries[rel] = metadata.split()[id_field].decode()
    return entries


def read_blobs(object_ids: set[str]) -> dict[str, bytes]:
    """Read many Git objects through one `cat-file --batch` process."""
    requested = sorted(object_ids)
    stdout = subprocess.run(
        ["git", "cat-file", "--batch"],
        input=("\n".join(requested) + "\n").encode(),
        capture_output=True,
    ).stdout
    blobs, offset = {}, 0
    for object_id in requested:
        header_end = stdout.index(b"\n", offset)
        size = int(stdout[offset:header_end].split()[2])
        offset = header_end + 1
        blobs[object_id] = stdout[offset:offset + size]
        offset += size + 1  # cat-file terminates each object's contents with LF
    return blobs


def repository_snapshots() -> tuple[dict[str, bytes], dict[str, bytes], int]:
    """Build staged and HEAD code snapshots without consulting the worktree."""
    index_code = code_entries(("ls-files", "-s", "-z"), 1)
    head_code = code_entries(("ls-tree", "-rz", "HEAD"), 2)
    objects = read_blobs(set(index_code.values()) | set(head_code.values()))

    def snapshot(entries: dict[str, str]) -> dict[str, bytes]:
        return {
            rel: objects[object_id]
            for rel, object_id in entries.items()
            if not declares_generated_blob(objects[object_id])
        }

    staged, head = snapshot(index_code), snapshot(head_code)
    return staged, head, max(len(staged), len(head))


def python_module_name(rel: str) -> str | None:
    """The dotted name a repo-root-relative Python file is importable as."""
    path = PurePosixPath(rel)
    parts = list(path.parts[:-1])
    if path.stem != "__init__":
        parts.append(path.stem)
    return ".".join(parts) or None


def python_module_index(paths: set[str]) -> dict[str, str]:
    """Map importable Python module names to their repo-relative files."""
    return {
        name: rel
        for rel in sorted(paths)
        if rel.endswith(".py") and (name := python_module_name(rel))
    }


def relative_python_targets(
    rel: str, node: ast.ImportFrom, paths: set[str]
) -> set[str]:
    base = posixpath.dirname(rel)
    for _ in range(node.level - 1):
        base = posixpath.dirname(base)
    module_names = [node.module] if node.module else [alias.name for alias in node.names]
    bases = [posixpath.join(base, module.replace(".", "/")) for module in module_names]
    return {
        candidate
        for module_base in bases
        for candidate in (f"{module_base}.py", f"{module_base}/__init__.py")
        if candidate in paths
    }


def python_node_targets(
    rel: str,
    node: ast.AST,
    paths: set[str],
    modules: dict[str, str],
) -> set[str]:
    if isinstance(node, ast.Import):
        return {
            target
            for alias in node.names
            if (target := modules.get(alias.name)) is not None
        }
    if not isinstance(node, ast.ImportFrom):
        return set()
    if node.level:
        return relative_python_targets(rel, node, paths)
    if node.module and (target := modules.get(node.module)):
        return {target}
    return set()


def python_import_targets(
    rel: str,
    blob: bytes,
    paths: set[str],
    modules: dict[str, str],
) -> set[str]:
    try:
        tree = ast.parse(blob.decode(errors="replace"), filename=rel)
    except SyntaxError:
        return set()
    targets = set()
    for node in ast.walk(tree):
        targets.update(python_node_targets(rel, node, paths, modules))
    return targets


def js_import_targets(rel: str, blob: bytes, paths: set[str]) -> set[str]:
    text = blob.decode(errors="replace")
    specifiers = {
        match.group(1)
        for pattern in JS_IMPORT_PATTERNS
        for match in pattern.finditer(text)
        if match.group(1).startswith(".")
    }
    targets = set()
    for specifier in specifiers:
        base = posixpath.normpath(posixpath.join(posixpath.dirname(rel), specifier))
        # `./a.js` is how TypeScript spells an import of `a.ts`, so the written
        # extension is dropped and every JS extension probed in its place.
        suffix = PurePosixPath(base).suffix
        stem = base[: -len(suffix)] if suffix in JS_SUFFIXES else base
        for candidate in (
            *(stem + extension for extension in JS_SUFFIXES),
            *(f"{stem}/index{extension}" for extension in JS_SUFFIXES),
        ):
            if candidate in paths:
                targets.add(candidate)
                break
    return targets


def imports_by_file(
    blobs: dict[str, bytes], selected: set[str] | None = None
) -> dict[str, set[str]]:
    paths = set(blobs)
    modules = python_module_index(paths)
    sources = paths if selected is None else paths & selected
    result = {}
    for rel in sources:
        suffix = PurePosixPath(rel).suffix
        if suffix == ".py":
            result[rel] = python_import_targets(rel, blobs[rel], paths, modules)
        elif suffix in JS_SUFFIXES:
            result[rel] = js_import_targets(rel, blobs[rel], paths)
    return result


def finish_graph_walk(
    root: str,
    graph: dict[str, set[str]],
    visited: set[str],
    order: list[str],
) -> None:
    visited.add(root)
    stack = [(root, iter(sorted(graph[root])))]
    while stack:
        node, neighbors = stack[-1]
        try:
            target = next(neighbors)
        except StopIteration:
            order.append(node)
            stack.pop()
            continue
        if target not in visited:
            visited.add(target)
            stack.append((target, iter(sorted(graph.get(target, set())))))


def graph_finish_order(graph: dict[str, set[str]]) -> list[str]:
    visited, order = set(), []
    for root in sorted(graph):
        if root not in visited:
            finish_graph_walk(root, graph, visited, order)
    return order


def reverse_graph(graph: dict[str, set[str]]) -> dict[str, set[str]]:
    reverse: dict[str, set[str]] = defaultdict(set)
    for source, targets in graph.items():
        for target in targets:
            reverse[target].add(source)
    return reverse


def collect_component(
    root: str,
    reverse: dict[str, set[str]],
    visited: set[str],
) -> frozenset[str]:
    component, pending = set(), [root]
    visited.add(root)
    while pending:
        node = pending.pop()
        component.add(node)
        for predecessor in reverse.get(node, set()):
            if predecessor not in visited:
                visited.add(predecessor)
                pending.append(predecessor)
    return frozenset(component)


def strongly_connected_components(
    graph: dict[str, set[str]],
) -> list[frozenset[str]]:
    reverse = reverse_graph(graph)
    visited, components = set(), []
    for root in reversed(graph_finish_order(graph)):
        if root not in visited:
            components.append(collect_component(root, reverse, visited))
    return components


def cycles_from(graph: dict[str, set[str]], starts: set[str]) -> set[frozenset[str]]:
    """Return cyclic components that pass through one of `starts`."""
    return {
        component
        for component in strongly_connected_components(graph)
        if len(component) > 1 and component & starts
    }


def directory_counts(blobs: dict[str, bytes]) -> dict[str, int]:
    return Counter(posixpath.dirname(rel) or "." for rel in blobs)


def ratchet(
    staged: dict[tuple[str, str], float],
    head: dict[tuple[str, str], float],
    limit: float,
    moved: set[tuple[str, str]] = frozenset(),
) -> list[tuple[str, str, float, float]]:
    return [
        (rel, name, value, head.get((rel, name), 0))
        for (rel, name), value in sorted(staged.items())
        if value > limit
        and value > head.get((rel, name), 0)
        and (rel, simple_name(name)) not in moved
    ]


def simple_name(name: str) -> str:
    """The bare function name behind a tool's `Class::method` or `Class.method`."""
    return name.split("::")[-1].split(".")[-1]


def python_definitions(blob: bytes) -> list[tuple[str, str, int, int]]:
    """(name, normalized-AST digest, first line, last line) per def or top-level assignment."""
    try:
        tree = ast.parse(blob)
    except (SyntaxError, ValueError):
        return []
    found = []
    for node in ast.walk(tree):
        name = definition_name(node)
        if name:
            digest = hashlib.sha256(ast.dump(node).encode()).hexdigest()
            found.append((name, digest, node.lineno, node.end_lineno or node.lineno))
    return found


def definition_name(node: ast.AST) -> str | None:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return node.name
    if isinstance(node, ast.Assign) and len(node.targets) == 1:
        target = node.targets[0]
        return target.id if isinstance(target, ast.Name) else None
    return None


def moved_definitions(
    staged_blobs: dict[str, bytes], head_blobs: dict[str, bytes]
) -> tuple[set[tuple[str, str]], dict[str, str]]:
    """Definitions that changed file without changing body, and new files' origins.

    A move introduces nothing: a function deleted from one file and re-added
    with an identical normalized AST elsewhere keeps the complexity it already
    had, so the ratchets must not read it as new (2026-09-02, every split of a
    large old file was refused for functions it did not touch). A copy that
    leaves the original in place is not a move. `origin_of` maps each new file
    to the head file most of its moved definitions came from, so a split does
    not read as a new import cycle either.
    """
    head_files: dict[str, set[str]] = defaultdict(set)
    for rel, blob in head_blobs.items():
        for _name, digest, _start, _end in python_definitions(blob):
            head_files[digest].add(rel)
    staged_defs = {rel: python_definitions(blob) for rel, blob in staged_blobs.items()}
    staged_keys = {(rel, d[0]) for rel, defs in staged_defs.items() for d in defs}
    moved: set[tuple[str, str]] = set()
    spans: dict[str, list[tuple[int, int]]] = defaultdict(list)
    origins: dict[str, Counter] = defaultdict(Counter)
    for rel, name, start, end, departed in departed_definitions(
        staged_defs, head_files, staged_keys
    ):
        moved.add((rel, name))
        spans[rel].append((start, end))
        origins[rel].update(departed)
    origin_of = {
        rel: counter.most_common(1)[0][0]
        for rel, counter in origins.items()
        if rel not in head_blobs
    }
    return moved, origin_of, dict(spans)


def departed_definitions(
    staged_defs: dict[str, list[tuple[str, str, int, int]]],
    head_files: dict[str, set[str]],
    staged_keys: set[tuple[str, str]],
):
    """Yield each staged definition whose identical body left some other head file."""
    for rel, defs in staged_defs.items():
        for name, digest, start, end in defs:
            departed = {
                source
                for source in head_files.get(digest, set())
                if source != rel and (source, name) not in staged_keys
            }
            if departed:
                yield rel, name, start, end, departed


def infer_origins_by_edges(
    staged_graph: dict[str, set[str]],
    head_graph: dict[str, set[str]],
    origin_of: dict[str, str],
) -> dict[str, str]:
    """Map new files that add no import edge of their own to the file that grew them.

    A new module imported only by files that existed at head, whose own imports
    are a subset of what one of those importers already imported (or of other
    new files with the same origin), is the same edges drawn differently.
    """
    origin_of = dict(origin_of)
    importers = reverse_graph(staged_graph)
    changed = True
    while changed:
        changed = False
        for rel in sorted(set(staged_graph) - set(head_graph) - set(origin_of)):
            candidates = {
                origin_of.get(source, source) for source in importers.get(rel, set())
            } & set(head_graph)
            for origin in sorted(candidates):
                allowed = head_graph[origin] | {
                    new for new, o in origin_of.items() if o == origin
                } | {origin}
                if staged_graph[rel] - {rel} <= allowed:
                    origin_of[rel] = origin
                    changed = True
                    break
    return origin_of


def known_cycle(
    cycle: frozenset[str], head_cycles: list[frozenset[str]], origin_of: dict[str, str]
) -> bool:
    """A cycle whose members trace back to files that already cycled is not new."""
    mapped = frozenset(origin_of.get(rel, rel) for rel in cycle)
    return any(mapped <= head for head in head_cycles)


def fmt(rows: list[tuple[str, str, float, float]]) -> list[str]:
    return [
        f"{rel}: {name} {value:g}"
        f" ({f'was {before:g}' if before else 'new'})"
        for rel, name, value, before in rows
    ]


def import_ratchets(
    staged_blobs: dict[str, bytes],
    head_blobs: dict[str, bytes],
    changed_code: set[str],
    tracked_code_count: int,
    origin_of: dict[str, str] | None = None,
) -> tuple[set[frozenset[str]], list[tuple[str, str, int, int]]]:
    over_cap = tracked_code_count > GRAPH_MAX
    if over_cap:
        print(
            "slop-gate: import-cycle graph skipped: "
            f"{tracked_code_count} tracked code files exceeds "
            f"SLOP_GATE_GRAPH_MAX={GRAPH_MAX}"
        )
    scope = changed_code if over_cap else None
    staged_graph = imports_by_file(staged_blobs, scope)
    head_graph = imports_by_file(head_blobs, scope)
    new_cycles: set[frozenset[str]] = set()
    origins = infer_origins_by_edges(staged_graph, head_graph, origin_of or {})
    if not over_cap:
        head_cycles = [
            c for c in strongly_connected_components(head_graph) if len(c) > 1
        ]
        new_cycles = {
            cycle
            for cycle in cycles_from(staged_graph, changed_code) - set(head_cycles)
            if not known_cycle(cycle, head_cycles, origins)
        }

    fan_out = [
        (rel, "fan-out", count, before)
        for rel in sorted(changed_code & set(staged_graph))
        if (count := moved_aware_fan_out(rel, staged_graph[rel], origins)) > FAN_OUT_MAX
        and count > (before := fan_out_baseline(rel, head_graph, origins))
    ]
    return new_cycles, fan_out


def moved_aware_fan_out(rel: str, targets: set[str], origins: dict[str, str]) -> int:
    """Edges between a file and the parts its own definitions moved into are not fan-out.

    Seen from the aggregator, edges to its new parts introduce nothing; seen from
    a part, edges to its origin and to sibling parts introduce nothing either.
    """
    family = origins.get(rel, rel)
    return len({
        target for target in targets
        if origins.get(target, target) != family and target != family
    })


def fan_out_baseline(rel: str, head_graph: dict[str, set[str]], origins: dict[str, str]) -> int:
    """A new part inherits the ratchet baseline of the file it was split out of."""
    return len(head_graph.get(rel if rel in head_graph else origins.get(rel, rel), set()))


def oversized_directories(
    staged_blobs: dict[str, bytes], head_blobs: dict[str, bytes]
) -> list[tuple[str, int, int]]:
    staged_dirs = directory_counts(staged_blobs)
    head_dirs = directory_counts(head_blobs)
    return [
        (directory, count, head_dirs.get(directory, 0))
        for directory, count in sorted(staged_dirs.items())
        if head_dirs.get(directory, 0) >= DIR_FILES_MAX
        and count > head_dirs.get(directory, 0)
    ]


def modularity_reports(
    paths: list[str],
    snapshots: tuple[dict[str, bytes], dict[str, bytes], int],
    origin_of: dict[str, str],
) -> list[tuple[str, list[str], str]]:
    staged_blobs, head_blobs, tracked_code_count = snapshots
    changed_code = set(paths) & set(staged_blobs)
    new_cycles, fan_out = import_ratchets(
        staged_blobs, head_blobs, changed_code, tracked_code_count, origin_of
    )
    oversized_dirs = oversized_directories(staged_blobs, head_blobs)
    return [
        (
            "new import cycles were introduced:",
            [", ".join(sorted(cycle)) for cycle in sorted(new_cycles, key=sorted)],
            "Break the cycle by moving the shared contract or dependency to a"
            " lower-level module.",
        ),
        (
            f"import fan-out above {FAN_OUT_MAX} was introduced:",
            fmt(fan_out),
            "Depend on a narrower module boundary, or split the file along its"
            " responsibilities.",
        ),
        (
            f"code files were added to directories already at {DIR_FILES_MAX} files:",
            [
                f"{directory}: {count} code files (was {before})"
                for directory, count, before in oversized_dirs
            ],
            "Create a cohesive subdirectory instead of widening this directory.",
        ),
    ]


def collect_reports() -> list[tuple[str, list[str], str]]:
    """Run every check; return (title, rows, advice) per failed check."""
    paths = staged_paths()
    if not paths:
        return []
    snapshots = repository_snapshots()
    moved, origin_of, moved_spans = moved_definitions(snapshots[0], snapshots[1])
    with tempfile.TemporaryDirectory(prefix="slop-gate-") as tmp:
        staged_root = Path(tmp, "staged")
        head_root = Path(tmp, "head")
        head_root.mkdir(parents=True)  # empty dirs yield empty results
        staged_root.mkdir(parents=True)
        for rel in paths:
            write_blob(staged_root, rel, ":")
            write_blob(head_root, rel, "HEAD:")

        ccn = ratchet(
            ccn_by_function(staged_root), ccn_by_function(head_root), CCN_MAX, moved
        )
        cognitive = ratchet(
            cognitive_by_function(staged_root),
            cognitive_by_function(head_root),
            COGNITIVE_MAX,
            moved,
        )
        halstead = ratchet(
            halstead_by_function(staged_root),
            halstead_by_function(head_root),
            HALSTEAD_MAX,
            moved,
        )
        head_lines = line_counts(head_root, paths)
        oversized = [
            (rel, lines, head_lines.get(rel, 0))
            for rel, lines in sorted(line_counts(staged_root, paths).items())
            if lines > FILE_LINES_MAX and lines > head_lines.get(rel, 0)
        ]
        dead = dead_code_findings(staged_root, moved_spans) - dead_code_findings(head_root)
        layout = layout_ratchet(
            pep8_layout_findings(staged_root, moved_spans), pep8_layout_findings(head_root)
        )

    modularity = modularity_reports(paths, snapshots, origin_of)
    reports = [
        (
            "PEP 8 layout violations were introduced:",
            layout,
            "Restore the spacing (two blank lines around top-level definitions,"
            " one between methods) and one statement per line. A line budget is"
            " never paid with stripped blank lines or joined statements; split the"
            " file at a seam instead.",
        ),
        (
            f"cyclomatic complexity above {CCN_MAX} was introduced:",
            fmt(ccn),
            "Simplify the control flow (consolidate branches, use a table or"
            " early returns); do not split into trivial helpers to game the"
            " number.",
        ),
        (
            f"cognitive complexity above {COGNITIVE_MAX} was introduced:",
            fmt(cognitive),
            "Flatten the nesting: invert conditions, return early, or lift"
            " the inner loop body to a named function that earns its name.",
        ),
        (
            f"Halstead difficulty above {HALSTEAD_MAX} was introduced:",
            fmt(halstead),
            "The function juggles too many distinct operators and repeated"
            " operands; name intermediate values or split along data, not"
            " along line count.",
        ),
        (
            f"code files above {FILE_LINES_MAX} lines were grown:",
            [
                f"{rel}: {lines} lines ({f'was {before}' if before else 'new'})"
                for rel, lines, before in oversized
            ],
            "Split along module seams (a cohesive unit per file), not at an"
            " arbitrary line count.",
        ),
        *modularity,
        *oxlint_reports(paths),
        (
            "new dead code was introduced:",
            [f"{p}: {m}" for p, m in sorted(dead)],
            "Delete it, or reference it; if vulture is wrong, add it to the"
            " repo's vulture whitelist.",
        ),
        (
            "new TypeScript `any` was introduced:",
            [f"{rel}: {text}" for rel, text in added_ts_any()],
            "Type it, or use `unknown` plus a narrowing check; a deliberate"
            f" `any` carries a `// {ANY_WAIVER}` comment on the same line.",
        ),
    ]
    return [r for r in reports if r[1]]


def main() -> None:
    reports = collect_reports()
    for title, rows, advice in reports:
        print(f"slop-gate: {title}")
        for row in rows:
            print(f"  {row}")
        print(f"  -> {advice}")
    if reports:
        sys.exit(1)


if __name__ == "__main__":
    main()
