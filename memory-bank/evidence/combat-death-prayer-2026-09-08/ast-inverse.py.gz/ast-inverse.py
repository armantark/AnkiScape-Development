"""Restore the complete candidate AST without executing product source."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
evidence = root / 'memory-bank/evidence/combat-death-prayer-2026-09-08'
engine_path = root / 'logic_pure/logic_pure_combat_engine.py'
specials_path = root / 'logic_pure/logic_pure_combat_specials.py'
engine = ast.parse(engine_path.read_bytes())
specials = ast.parse(specials_path.read_bytes())
helper = next(node for node in specials.body if isinstance(node, ast.FunctionDef) and node.name == '_combat_death_prayer_damage')
replacements = []


class Restore(ast.NodeTransformer):
    def visit_ImportFrom(self, node):
        node.names = [item for item in node.names if item.name != helper.name]
        return node

    def visit_Assign(self, node):
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == helper.name:
            replacements.append(ast.unparse(node))
            return helper.body[:-1]
        return self.generic_visit(node)


restored = Restore().visit(engine)
baseline = ast.parse(gzip.decompress((evidence / 'baseline-engine.py.gz').read_bytes()))
engine_equal = ast.dump(restored) == ast.dump(baseline)
specials.body.remove(helper)
for node in specials.body:
    if isinstance(node, ast.ImportFrom):
        node.names = [item for item in node.names if item.name not in ('_combat_cap_damage_for_finisher', '_positive_int')]
specials_equal = ast.dump(specials) == ast.dump(ast.parse(gzip.decompress((evidence / 'baseline-specials.py.gz').read_bytes())))
no_remaining_reads = all(not isinstance(node, ast.Name) or node.id not in ('cap_multiplier', 'death_roll') for node in ast.walk(ast.parse(engine_path.read_bytes())))
passed = engine_equal and specials_equal and no_remaining_reads and len(replacements) == 1
report = {
    'status': 'PASS' if passed else 'FAIL',
    'scope': 'Whole-file AST inverse only; no product imports or execution',
    'engine_inverse_equal': engine_equal,
    'specials_inverse_equal': specials_equal,
    'temporary_names_have_no_remaining_engine_reads': no_remaining_reads,
    'replacement_calls': replacements,
    'helper_arguments': [arg.arg for arg in helper.args.args],
    'helper_returns': ast.unparse(helper.body[-1]),
    'source_pins': {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in (engine_path, specials_path)},
}
(evidence / 'ast-inverse.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
if not passed:
    raise SystemExit(1)
