"""Measure pinned source text only; never import or execute product modules."""
import ast
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(sys.argv[1]).resolve()
evidence = root / 'memory-bank/evidence/combat-death-prayer-2026-09-08'
base = '5eaaf97a3c1cc64bc81cff6f276ebcedbb209db8'
gate_path = Path('/Users/ArmanTarkhanian1/fleet/config/git/hooks/slop_gate.py')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
spec = importlib.util.spec_from_file_location('source_static_gate', gate_path)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
raw_results = []
original = gate.run_tool


def retained(argv, tool):
    result = original(argv, tool)
    row = {'argv': argv, 'tool': tool, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    if tool == 'complexipy':
        report = Path(argv[argv.index('--output') + 1]) / 'complexipy-results.json'
        row['report_text'] = report.read_text() if report.exists() else None
    raw_results.append(row)
    return result


gate.run_tool = retained
pins = {'gate': {'path': str(gate_path), 'sha256': sha(gate_path.read_bytes())}, 'python': {'path': sys.executable, 'version': sys.version}}
for tool in ('lizard', 'complexipy', 'radon', 'pycodestyle'):
    path = Path(shutil.which(tool))
    result = subprocess.run([str(path), '--version'], capture_output=True, text=True)
    pins[tool] = {'path': str(path), 'sha256': sha(path.read_bytes()), 'version_stdout': result.stdout, 'version_stderr': result.stderr, 'version_returncode': result.returncode}
paths = ['logic_pure/logic_pure_combat_engine.py', 'logic_pure/logic_pure_combat_specials.py', 'tests/combat/test_death_prayer.py', 'tools/combat/compare_death_prayer.py', 'tools/combat/check_death_prayer_guards.py']
report = {'base_commit': base, 'instrument_pins': pins, 'scope': 'Source-only metrics, layout, file growth and directory module counts; runtime harnesses compared with accepted prayer protocol.', 'source_pins': {p: sha((root / p).read_bytes()) for p in paths}}
failures = []
with tempfile.TemporaryDirectory(prefix='death-prayer-source-static-') as folder:
    folder = Path(folder)
    before, after = folder / 'before', folder / 'after'
    before.mkdir(); after.mkdir()
    for p in paths:
        raw = (root / p).read_bytes()
        ast.parse(raw, filename=p)
        target = after / p
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    for name in ('engine', 'specials'):
        target = before / f'logic_pure/logic_pure_combat_{name}.py'
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.decompress((evidence / f'baseline-{name}.py.gz').read_bytes()))
    prior = root / 'memory-bank/evidence/combat-enemy-poison-2026-09-08'
    for name in ('runtime-harness.py.gz', 'runtime-safety-check.py.gz'):
        relative = 'operational/' + name[:-3]
        for tree, source in ((before, prior), (after, evidence)):
            raw = gzip.decompress((source / name).read_bytes())
            ast.parse(raw, filename=relative)
            target = tree / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        report['source_pins'][str(evidence.relative_to(root) / name)] = sha((evidence / name).read_bytes())
    for label, function, limit in (('ccn', gate.ccn_by_function, gate.CCN_MAX), ('cognitive', gate.cognitive_by_function, gate.COGNITIVE_MAX), ('halstead', gate.halstead_by_function, gate.HALSTEAD_MAX)):
        old, new = function(before), function(after)
        errors = gate.ratchet(new, old, limit)
        failures.extend(errors)
        report[label] = {'limit': limit, 'baseline': {'::'.join(k): v for k, v in old.items()}, 'candidate': {'::'.join(k): v for k, v in new.items()}, 'errors': errors}
    old, new = gate.pep8_layout_findings(before), gate.pep8_layout_findings(after)
    errors = gate.layout_ratchet(new, old)
    failures.extend(errors)
    report['layout'] = {'errors': errors}
    measured = paths + ['operational/runtime-harness.py', 'operational/runtime-safety-check.py']
    old, new = gate.line_counts(before, measured), gate.line_counts(after, measured)
    errors = [(p, n, old.get(p, 0)) for p, n in new.items() if n > gate.FILE_LINES_MAX and n > old.get(p, 0)]
    failures.extend(errors)
    report['file_growth'] = {'limit': gate.FILE_LINES_MAX, 'baseline': old, 'candidate': new, 'errors': errors}
base_paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base], cwd=root).decode().splitlines()
old = {p: b'' for p in base_paths if Path(p).suffix in gate.CODE_SUFFIXES}
new = {**old, **{p: b'' for p in paths}}
errors = gate.oversized_directories(new, old)
failures.extend(errors)
report['module_counts'] = {'limit': gate.DIR_FILES_MAX, 'baseline': dict(gate.directory_counts(old)), 'candidate': dict(gate.directory_counts(new)), 'errors': errors}
report['status'] = 'FAIL' if failures else 'PASS'
(evidence / 'source-static-report.json').write_text(json.dumps(report, indent=2) + '\n')
(evidence / 'source-static-raw.json.gz').write_bytes(gzip.compress((json.dumps(raw_results, indent=2) + '\n').encode(), mtime=0))
print(json.dumps({'status': report['status'], 'errors': failures}, indent=2))
if failures:
    raise SystemExit(1)
