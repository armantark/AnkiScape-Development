from pathlib import Path
import ast,datetime,gzip,hashlib,json,os,runpy,subprocess
ROOT=Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/13/ankiscape_fork')
OUT=ROOT/'memory-bank/evidence/exposed-complexity-2026-09-05'
d=json.loads((OUT/'inventory.json').read_text()); blobs=json.loads(gzip.decompress((OUT/'source-blobs.json.gz').read_bytes()))
moves=json.loads(gzip.decompress((OUT/'move-provenance-and-raw-metrics.json.gz').read_bytes())); current=json.loads(gzip.decompress((OUT/'accepted-main-raw-metrics.json.gz').read_bytes()))
limits={'ccn':d['thresholds']['CCN_MAX'],'cognitive':d['thresholds']['COGNITIVE_MAX'],'halstead':d['thresholds']['HALSTEAD_MAX']}
def sha(b):return hashlib.sha256(b).hexdigest()
functions_cache={}
def functions(h):
 if h in functions_cache:return functions_cache[h]
 out=[]
 def visit(node,prefix):
  named=isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))
  name=prefix+[node.name] if named else prefix
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):out.append(('.'.join(name),node.name,node.lineno,node.end_lineno))
  for child in ast.iter_child_nodes(node):visit(child,name)
 visit(ast.parse(blobs[h]),[]);functions_cache[h]=out;return out

def canonical(rows):
 out={}
 for r in rows:
  rawname=r['function']; name=rawname.replace('::','.')
  choices=[f for f in functions(r['source_sha256']) if f[0]==name]
  if not choices:choices=[f for f in functions(r['source_sha256']) if f[1]==name]
  assert len(choices)==1,(r['path'],name,choices)
  qualified,bare,start,end=choices[0];key=(r.get('commit'),r['path'],qualified)
  if key not in out:out[key]={**r,'function':qualified,'simple_name':bare,'start':start,'end':end,'raw_metric_names':[]}
  row=out[key]; row['raw_metric_names'].append(rawname)
  for metric in limits:
   if r.get(metric) is not None:row[metric]=r[metric]
  row['above_threshold']={k:row[k] for k,v in limits.items() if row.get(k) is not None and row[k]>v}
 return list(out.values())
accepted=canonical(d['accepted_outstanding']); provisional=canonical(d['provisional_outstanding'])
shop=[{**r,'accepted_landing':'0005e1cb42530706ab9ceb85e5be80ce3a0685f9','eligibility':'accepted moved definition; exact candidate blobs reconciled to landing'} for r in provisional if r['family']=='shop_logic']
accepted+=shop; provisional=[r for r in provisional if r['family']!='shop_logic']
remainder=[]
for r in current:
 if r['family'] not in {'activities','diary_generator'}:continue
 matching=[x for x in d['above_threshold_family_rows_without_move_or_explicit_eligibility'] if x['family']==r['family']]
 remainder+=canonical(matching)
shopmove=next(m for m in moves if m['family']=='shop_logic')
shopkeys={(r['path'],r['simple_name']) for r in shop}
shoprows=[{'family':'shop_logic','commit':shopmove['commit'],**r} for r in shopmove['raw_measurements'] if any(r.get(k) is not None and r[k]>v for k,v in limits.items())]
remainder += [{**r,'accepted_landing':'0005e1cb42530706ab9ceb85e5be80ce3a0685f9'} for r in canonical(shoprows) if (r['path'],r['simple_name']) not in shopkeys]
# Find historical above-threshold moved functions whose exact current path/name has disappeared.
currentkeys={(r['family'],x['path'],x['function'].split('::')[-1].split('.')[-1]) for r in current for x in r['raw_measurements']}
missing=[]
for m in moves:
 if not m['landed_at_capture']:continue
 movedkeys={(p['path'],p['function']) for p in m['matched_definitions']}
 for r in m['raw_measurements']:
  bare=r['function'].split('::')[-1].split('.')[-1]
  if (r['path'],bare) in movedkeys and any(r.get(k) is not None and r[k]>v for k,v in limits.items()) and (m['family'],r['path'],bare) not in currentkeys:
   missing.append({'family':m['family'],'split_commit':m['commit'],**r})
hook=Path(d['hook']['path']);source=hook.read_bytes();g=runpy.run_path(str(hook),run_name='slop_gate_inventory_final_check')
d['hook']['sha256_after']=sha(source);d['thresholds_after']={k:g[k] for k in d['thresholds']};d['environment_overrides_present_after']=any(k.startswith('SLOP_GATE_') for k in os.environ)
assert d['thresholds_after']==d['thresholds'] and sha(source)==d['hook']['sha256'] and not d['environment_overrides_present_after']
(OUT/'slop-gate-source.py.gz').write_bytes(gzip.compress(source,mtime=0))
for rows in [accepted,provisional,remainder]: rows.sort(key=lambda r:(r.get('ccn') or 0,r.get('cognitive') or 0),reverse=True)
d['accepted_function_queue_after_shop_reconciliation']=accepted;d['provisional_function_queue_after_shop_reconciliation']=provisional;d['accepted_split_family_remainders']=remainder;d['historical_moved_above_threshold_without_current_path_name']=missing
d['source_name_reconciliation']='Raw tool dictionaries remain unchanged. Human function rows join by exact source AST qualified function name; a tool bare name joins only when it identifies exactly one source function.'
(OUT/'inventory.json.gz').write_bytes(gzip.compress((json.dumps(d,indent=2)+'\n').encode(),mtime=0))
(OUT/'inventory.json').unlink()
(OUT/'finalization-script.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
manifest={'accepted_snapshot':d['accepted_main'],'shop_landing':'0005e1cb42530706ab9ceb85e5be80ce3a0685f9','hook_sha256':d['hook']['sha256'],'thresholds':d['thresholds'],'accepted_functions':len(accepted),'provisional_functions':len(provisional),'accepted_family_remainders':len(remainder),'missing_current_lineages':len(missing),'files':{p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='manifest.json'}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
lines=['# Exposed function complexity: measured scope and remaining work','',f"Accepted source snapshot: `{d['accepted_main']}`. Shop logic was then accepted at `0005e1cb42530706ab9ceb85e5be80ce3a0685f9`; all four shop-family source files are byte-identical to measured candidate `12850beed2aa644b0d051f6e1e4a90d9154a9b69`. Later main movement does not change the captured snapshot.",'', 'The installed gate loaded CCN 15, cognitive complexity 15, and Halstead difficulty 80, with no environment overrides. Its source hash and loaded limits matched after measurement. Lizard 1.24.0, Complexipy 7.0.1, and Radon 6.0.1 supplied the measurements. Exact executable paths, hashes, source snapshots, move matches, and raw metric dictionaries are retained in [the evidence manifest](../evidence/exposed-complexity-2026-09-05/manifest.json).','', 'The measurement reads immutable Git blobs and calls the installed gate APIs. It does not import product code, run tests, change the gate, or establish behavior preservation. Raw measurements are retained before the gate suppresses inherited moves. A passing regression gate does not mean that every function is below its limit.','', '## Scope','', 'Owner rulings in `handoffs/design-to-impl-rulings-2026-08-13.md` define the original ten sources at 34.2, carried as file eleven at 48, and the promotion tool as file twelve at 51.1. Section 48.1 also requires the activities and diary-generator splits. The table records all fourteen source families.','', '| Family source | Exact split or candidate | Status at the accepted snapshot |','| --- | --- | --- |']
for f in d['scope']:
 commits=', '.join('`'+c['commit'][:8]+'`' for c in f['move_commits']) or 'No accepted move'
 state='Accepted' if f['move_commits'] and all(c['landed_at_capture'] for c in f['move_commits']) else 'Provisional' if f['move_commits'] else 'Unsplit obligation'
 if f['family']=='shop_logic':state='Accepted later at 0005; source identity verified'
 if f['family']=='combat_engine':state='Explicit target; candidate simplifies in place'
 lines.append(f"| `{f['source_path']}` | {commits} | {state} |")
lines+=['', 'The root state conversion is a prerequisite, not the dispatcher relocation. Rejected root split `a8bb0fa70947d3602b917091aaba15ebf5cd1f54` is not accepted evidence. The latest shop-UI file-history change is `7a5a43976fbd0e725dc61780bd6dc9d367d50da9` on 2026-08-07; shop-logic candidate `12850bee` does not change `ui/ui_tab_shop.py`. These exact Git query results are retained in `scope-history.json`. The UI-family obligation is separate from shop logic. This audit authorizes no UI implementation or redesign; any later source move must preserve every visible behavior. Native approval remains pending separately.','', '## Confirmed exposed or explicitly named functions','', f'{len(accepted)} distinct functions remain above at least one loaded limit. This includes the owner-named combat burst and root answer dispatcher before their moves, plus the accepted shop reconciliation. The ordering below is descending CCN, then cognitive complexity.','', '| Function at measured source | CCN | Cognitive | Halstead |','| --- | ---: | ---: | ---: |']
def table(rows):
 for r in rows:
  vals=[str(r.get(k)) if r.get(k) is not None else 'Not reported' for k in ['ccn','cognitive','halstead']]
  lines.append(f"| `{r['path']}:{r['start']}::{r['function']}` | {' | '.join(vals)} |")
table(accepted)
lines+=['','## Provisional candidate functions','',f'{len(provisional)} distinct functions remain provisional. Combat candidate `0af0b0d5` reduces the same explicit target; it is not an additional accepted function. Quest `5c87ba05` and roster `4d3bd18b` are separate unlanded source measurements.','', '| Function at candidate source | CCN | Cognitive | Halstead |','| --- | ---: | ---: | ---: |'];table(provisional)
lines+=['','## Functions retained in accepted split-family aggregators','',f'{len(remainder)} further functions exceed a loaded limit but did not change file in the recovered moves. These are measured remainders of the accepted activities, diary-generator, and shop families. Keep them visible when defining completion of the family; do not call them exact moved-definition matches or silently discard them as unrelated repository debt.','', '| Function at measured source | CCN | Cognitive | Halstead |','| --- | ---: | ---: | ---: |'];table(remainder)
lines+=['','## Completion limits','',f'The exact historical above-threshold moved keys have {len(missing)} unresolved current path/name lineages. The raw inventory also retains above-threshold functions in the still-unsplit root, shop-UI, combat, quest and roster source files; they are not presented as completed moves. Farming is outside this scope. The generated diary catalog is excluded by the installed gate filter, and its generator is measured separately. No complete-program claim is possible while source moves and the provisional candidates remain unaccepted.','', 'The installed matcher returns moved keys, origin maps and spans. Its stale two-value return annotation was not used. Raw Lizard and Complexipy names for the same roster method differ; the human table joins them only through the uniquely identified source AST function. The retained raw dictionaries preserve each tool name unchanged.','']
p=ROOT/'memory-bank/source-audits/exposed-complexity-2026-09-05.md';p.write_text('\n'.join(lines))
print(json.dumps({'manifest':manifest,'human_note_bytes':p.stat().st_size},indent=2))
