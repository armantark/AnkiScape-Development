from pathlib import Path
import ast, datetime, gzip, hashlib, json, os, runpy, shutil, subprocess, tempfile
REPO=Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
OUT=Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/13/ankiscape_fork/memory-bank/evidence/exposed-complexity-2026-09-05')
HOOK=Path('/Users/ArmanTarkhanian1/fleet/config/git/hooks/slop_gate.py')
os.chdir(REPO)
OUT.mkdir(parents=True,exist_ok=True)
def git(*args): return subprocess.check_output(['git',*args])
def sha(b): return hashlib.sha256(b).hexdigest()
def packed(name,obj):
 data=json.dumps(obj,sort_keys=True,separators=(',',':')).encode()
 (OUT/name).write_bytes(gzip.compress(data,mtime=0))
 return {'path':name,'sha256':sha((OUT/name).read_bytes()),'uncompressed_sha256':sha(data)}
source=HOOK.read_bytes(); tree=ast.parse(source)
assert isinstance(tree.body[-1],ast.If) and ast.unparse(tree.body[-1].test)=="__name__ == '__main__'"
g=runpy.run_path(str(HOOK),run_name='slop_gate_inventory')
thresholds={k:g[k] for k in ['CCN_MAX','COGNITIVE_MAX','HALSTEAD_MAX']}
assert not any(k.startswith('SLOP_GATE_') for k in os.environ), 'Unexpected threshold environment override; report before proceeding'
main=git('rev-parse','main').decode().strip()
families=[
 ('root','__init__.py',['__init__.py'],[], 'rejected a8bb0fa7 is not an accepted move; state conversion alone has not relocated the dispatchers'),
 ('constants','core/constants.py',['core/constants.py','core/constants_parts/'],['bbb79d4d','0246e1fc','9f54377b'],''),
 ('quest','data/quest_data.py',['data/quest_data.py','data/quest/'],['5c87ba05'],''),
 ('combat_data','data/combat_data.py',['data/combat_data.py','data/combat/'],['2f5949b7'],''),
 ('slayer_data','data/slayer_data.py',['data/slayer_data.py','data/slayer/'],['50e5cbdb'],''),
 ('combat_engine','logic_pure/logic_pure_combat_engine.py',['logic_pure/logic_pure_combat_engine.py'],['0af0b0d5'],'explicit owner target; candidate is simplification, not a pure move'),
 ('roster','tests/test_combat_enemy_roster.py',['tests/test_combat_enemy_roster.py','tests/combat_roster/'],['4d3bd18b'],''),
 ('shop_logic','logic/shop_logic.py',['logic/shop_logic.py','logic/shop/'],['12850bee'],''),
 ('shop_ui','ui/ui_tab_shop.py',['ui/ui_tab_shop.py'],[],'No first-wave split recovered in file history; shop logic candidate does not touch this source'),
 ('diary_catalog','data/achievement_diary_catalog.py',['data/achievement_diary_catalog.py','data/achievement_diaries/'],['a0e22ade'],''),
 ('carried','runtime/runtime_actions_carried.py',['runtime/runtime_actions_carried'],['89f2666e'],''),
 ('promotion','tools/promotion_gate.py',['tools/promotion_gate.py','tools/promotion/'],['6bfeafe4'],''),
 ('activities','runtime/runtime_actions_activities.py',['runtime/runtime_actions_activities'],['3d3ed9d9'],''),
 ('diary_generator','tools/generate_achievement_diary_data.py',['tools/generate_achievement_diary_data.py','tools/achievement_diary_generation/'],['a0e22ade'],'')]
blob_store={}; snapshot_cache={}; records=[]; moves=[]; inventory=[]; measurement_cache={}
def snapshot(commit):
 if commit in snapshot_cache: return snapshot_cache[commit]
 entries=g['code_entries'](('ls-tree','-rz',commit),2)
 objects=g['read_blobs'](set(entries.values()))
 blobs={p:objects[h] for p,h in entries.items() if not g['declares_generated_blob'](objects[h])}
 snapshot_cache[commit]=blobs
 return blobs

def select(blobs,prefixes): return {p:b for p,b in blobs.items() if p.endswith('.py') and any(p==v or (not v.endswith('.py') and p.startswith(v)) for v in prefixes)}
def retain(blobs):
 result={}
 for p,b in blobs.items():
  h=sha(b); result[p]={'sha256':h,'bytes':len(b)}; blob_store[h]=b.decode('utf-8')
 return result

def measure(commit,blobs):
 key=(commit,tuple(sorted(blobs)))
 if key in measurement_cache: return measurement_cache[key]
 with tempfile.TemporaryDirectory(prefix='ankiscape-exposed-static-') as d:
  root=Path(d)
  for p,b in blobs.items():
   dest=root/p; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b)
  values={label:g[fn](root) for label,fn in [('ccn','ccn_by_function'),('cognitive','cognitive_by_function'),('halstead','halstead_by_function')]}
 rows=[]
 for p,n in sorted(set().union(*(set(v) for v in values.values()))):
  metrics={label:v.get((p,n)) for label,v in values.items()}
  rows.append({'path':p,'function':n,'source_sha256':sha(blobs[p]),**metrics})
 measurement_cache[key]=rows
 return rows
for name,origin,prefixes,commits,note in families:
 item={'family':name,'source_path':origin,'prefixes':prefixes,'note':note,'move_commits':[]}
 mb=select(snapshot(main),prefixes)
 current={'family':name,'status':'accepted_main','commit':main,'sources':retain(mb),'raw_measurements':measure(main,mb)}
 records.append(current)
 for short in commits:
  commit=git('rev-parse',short).decode().strip(); before=git('rev-parse',commit+'^1').decode().strip()
  landed=subprocess.run(['git','merge-base','--is-ancestor',commit,main],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
  after_all=snapshot(commit); before_all=snapshot(before)
  matched,origins,spans=g['moved_definitions'](after_all,before_all)
  after=select(after_all,prefixes); old=select(before_all,prefixes)
  old_defs={p:g['python_definitions'](b) for p,b in old.items()}
  provenance=[]
  for p,b in after.items():
   for n,digest,start,end in g['python_definitions'](b):
    if (p,n) not in matched: continue
    sources=[{'path':q,'start':s,'end':e,'source_sha256':sha(old[q])} for q,defs in old_defs.items() for on,od,s,e in defs if od==digest and q!=p and not any(x[0]==n for x in g['python_definitions'](after_all.get(q,b'')))]
    if sources: provenance.append({'path':p,'function':n,'start':start,'end':end,'normalized_ast_sha256':digest,'departed_sources':sources})
  move={'family':name,'commit':commit,'before_commit':before,'landed_at_capture':landed,'before_sources':retain(old),'after_sources':retain(after),'matched_definitions':provenance,'gate_origin_map':{p:q for p,q in origins.items() if p in after},'gate_moved_spans':{p:v for p,v in spans.items() if p in after},'raw_measurements':measure(commit,after)}
  moves.append(move); item['move_commits'].append({'commit':commit,'before_commit':before,'landed_at_capture':landed})
  print('MEASURED',name,short,'moved',len(provenance),'functions',len(move['raw_measurements']),flush=True)
 inventory.append(item)
# A name in an accepted moved definition remains eligible at its path even if later edits changed its AST.
limit={'ccn':thresholds['CCN_MAX'],'cognitive':thresholds['COGNITIVE_MAX'],'halstead':thresholds['HALSTEAD_MAX']}
def above(row): return {k:row[k] for k,v in limit.items() if row[k] is not None and row[k]>v}
accepted_keys={(m['family'],p['path'],p['function']) for m in moves if m['landed_at_capture'] for p in m['matched_definitions']}
explicit={('combat_engine','logic_pure/logic_pure_combat_engine.py','apply_combat_burst_pure'),('root','__init__.py','on_answer_card')}
accepted=[]; family_other=[]
for r in records:
 for row in r['raw_measurements']:
  key=(r['family'],row['path'],g['simple_name'](row['function']))
  if not above(row): continue
  out={'family':r['family'],'commit':main,**row,'above_threshold':above(row)}
  if key in accepted_keys or key in explicit:
   out['eligibility']='explicit owner target' if key in explicit else 'accepted moved definition'; accepted.append(out)
  else: family_other.append(out)
provisional=[]
for m in moves:
 if m['landed_at_capture']: continue
 keys={(p['path'],p['function']) for p in m['matched_definitions']}
 for row in m['raw_measurements']:
  key=(row['path'],g['simple_name'](row['function']))
  if above(row) and (key in keys or (m['family'],*key) in explicit):
   provisional.append({'family':m['family'],'commit':m['commit'],**row,'above_threshold':above(row)})
accepted.sort(key=lambda r:(r['ccn'] or 0,r['cognitive'] or 0),reverse=True)
provisional.sort(key=lambda r:(r['ccn'] or 0,r['cognitive'] or 0),reverse=True)
versions={}
for tool in ['lizard','complexipy','radon']:
 path=Path(shutil.which(tool)); proc=subprocess.run([str(path),'--version'],capture_output=True,text=True)
 versions[tool]={'executable':str(path),'resolved':str(path.resolve()),'sha256':sha(path.read_bytes()),'version_stdout':proc.stdout,'version_stderr':proc.stderr,'exit_code':proc.returncode}
reports=[packed('source-blobs.json.gz',blob_store),packed('move-provenance-and-raw-metrics.json.gz',moves),packed('accepted-main-raw-metrics.json.gz',records)]
manifest={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted_main':main,'main_at_end':git('rev-parse','main').decode().strip(),'hook':{'path':str(HOOK),'sha256':sha(source),'unchanged_after':HOOK.read_bytes()==source,'main_guard_inspected':True,'import_run_name':'slop_gate_inventory'},'thresholds':thresholds,'environment_overrides_present':False,'versions':versions,'scope':inventory,'reports':reports,'accepted_outstanding':accepted,'provisional_outstanding':provisional,'above_threshold_family_rows_without_move_or_explicit_eligibility':family_other,'method':'Existing gate measurement APIs and full filtered repository moved_definitions matching, before first parent versus exact split commit; current metric records retained before ratchet suppression. Exact family source bytes deduplicated by SHA256. No product imports/tests. Farming outside scope. Accepted current list follows exact moved path and name plus owner-named combat burst and root answer targets; retired or renamed destinations require lineage reconciliation.'}
(OUT/'inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'recovery-script.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('DONE',len(accepted),'accepted',len(provisional),'provisional',len(family_other),'unclassified family', 'main',main,flush=True)
