"""Runtime review-action handlers.

This module owns review action mutations without importing Anki or Qt. The
package entrypoint passes UI/save/achievement callbacks through
``RuntimeActionContext`` so ``__init__.py`` can stay focused on hooks and state
coordination.

The handlers themselves live in the ``runtime_actions_*`` modules and are
re-exported here, so existing callers keep importing from ``runtime_actions``.
Only the dispatch registries stay in this file, because they are the one place
that must see every handler. Import order runs context -> shared -> carried ->
combat/magic/gates -> the per-skill handler modules.

A test that patches a name must patch it on the module that DEFINES it. A caller
resolves the name from its own module globals, so rebinding the re-exported
attribute here is silently a no-op.
"""

from __future__ import annotations

import copy
import dataclasses
from dataclasses import dataclass
from typing import Any, Callable, Optional

from ..logic.combat_session import (
    wilderness_combat_risk_confirmed,
    wilderness_combat_risk_fingerprint,
)

from ..core.constants import (
    BIRD_NEST_DROP_CHANCE,
    BIRD_NEST_DROP_TABLE,
    BIRD_NEST_OPEN_TABLES,
    COMBAT_BURST_TICKS,
    COMBAT_ENEMY_DATA,
    COMBAT_FOOD_DATA,
    COOKING_DATA,
    CRAFTING_DATA,
    DEFAULT_COMBAT_TARGET,
    DEFAULT_COOKING_TARGET,
    DEFAULT_FIREMAKING_TARGET,
    DEFAULT_FLETCHING_TARGET,
    DEFAULT_FISHING_TARGET,
    DEFAULT_HERBLORE_TARGET,
    DEFAULT_HUNTER_TARGET,
    DEFAULT_MINING_TARGET,
    DEFAULT_RUNECRAFTING_TARGET,
    DEFAULT_UTILITY_ACTIVITY,
    DEFAULT_WOODCUTTING_TARGET,
    EQUIPMENT_DATA,
    EXP_TABLE,
    FIREMAKING_DATA,
    FISHING_DATA,
    HUNTER_DATA,
    FLETCHING_DATA,
    HERBLORE_DATA,
    GLORY_GEM_DROP_CHANCE,
    INCIDENTAL_GEM_DROP_CHANCE,
    INCIDENTAL_GEM_DROP_TABLE,
    ITEM_DEFINITIONS,
    MINING_BONUS_ITEM_DATA,
    MINING_PICKAXE_DATA,
    MAGIC_DATA,
    DEFAULT_MAGIC_TARGET,
    ORE_DATA,
    PRAYER_DATA,
    DEFAULT_PRAYER_TARGET,
    QUEST_DATA,
    QUEST_UNLOCK_RULES,
    RUNECRAFTING_DATA,
    RUNECRAFTING_POUCH_DATA,
    SMITHING_DATA,
    TREE_DATA,
    UTILITY_ACTIVITY_DATA,
    WOODCUTTING_AXE_DATA,
)
from ..logic_pure.logic_pure import (
    COMBAT_GRAVE_RECOVERY_REVIEWS,
    apply_combat_burst_pure,
    apply_combat_finisher_pure,
    apply_cooking_action_pure,
    apply_crafting_pure,
    apply_firemaking_action_pure,
    apply_fishing_action_pure,
    apply_fletching_pure,
    apply_herblore_action_pure,
    apply_hunter_action_pure,
    apply_quest_combat_encounter_pure,
    apply_mining_action_pure,
    apply_magic_action_pure,
    apply_open_bird_nests_pure,
    apply_prayer_action_pure,
    apply_construction_action_pure,
    construction_target_locked_reasons_pure,
    owned_gilded_altar_burner_count_pure,
    owned_gilded_altar_marrentill_required_pure,
    owned_gilded_altar_access_reasons_pure,
    effective_gilded_altar_multiplier_pure,
    charge_training_urn_for_action_pure,
    intercept_bonecrusher_outputs_pure,
    prayer_gilded_search_step_pure,
    clear_prayer_gilded_stint_pure,
    prayer_target_locked_reasons_pure,
    apply_quest_progress_pure,
    apply_runecrafting_action_pure,
    runecrafting_locked_reasons_pure,
    apply_smithing_action_pure,
    apply_stronghold_step_pure,
    apply_knight_waves_step_pure,
    apply_mage_arena_step_pure,
    attune_mage_arena_spell_pure,
    knight_waves_locked_reasons_pure,
    mage_arena_locked_reasons_pure,
    apply_utility_activity_pure,
    apply_woodcutting_action_pure,
    apply_woodcutting_processing_action_pure,
    best_mining_pickaxe_pure,
    best_woodcutting_axe_pure,
    calculate_cooking_success_probability_pure,
    calculate_firemaking_success_probability_pure,
    calculate_fishing_success_probability_pure,
    fishing_agility_double_catch_chance_pure,
    calculate_hunter_success_probability_pure,
    calculate_mining_success_probability_pure,
    calculate_woodcutting_success_probability_pure,
    cooking_source_roll_chance_pure,
    firemaking_source_roll_chance_pure,
    calculate_new_level,
    can_chop_woodcutting_target_pure,
    can_craft_item_pure,
    can_attempt_quest_review_pure,
    can_progress_quest_pure,
    can_runecraft_target_pure,
    can_smith_item_pure,
    can_start_quest_pure,
    cooking_target_locked_reasons_pure,
    combat_target_locked_reasons_pure,
    eligible_fishing_fish_pure,
    equipment_bonus_state_pure,
    firemaking_target_locked_reasons_pure,
    fishing_method_locked_reasons_pure,
    fletching_material_requirements_pure,
    fletching_target_locked_reasons_pure,
    herblore_target_locked_reasons_pure,
    has_cooking_materials_pure,
    has_crafting_materials_pure,
    has_firemaking_materials_pure,
    has_fishing_bait_pure,
    has_hunter_materials_pure,
    has_ring_of_forging_pure,
    hunter_target_locked_reasons_pure,
    mining_target_locked_reasons_pure,
    red_sandstone_daily_state_pure,
    magic_target_locked_reasons_pure,
    normalize_xp_rewards_pure,
    quest_current_stage_blocker_reasons_pure,
    quest_current_stage_blockers_pure,
    quest_current_stage_resolvable_combat_blockers_pure,
    record_action_telemetry_pure,
    record_cadence_wait_telemetry_pure,
    record_achievement_progress_pure,
    consume_ring_of_forging_charge_pure,
    smithing_success_probability_pure,
    smithing_target_locked_reasons_pure,
    utility_activity_locked_reasons_pure,
    woodcutting_target_locked_reasons_pure,
    thieving_blackjack_threshold_pure,
    apply_thieving_damage_pure,
    thieving_loot_roll_pure,
    thieving_multi_pick_count_pure,
    thieving_roll_succeeds_pure,
    thieving_stall_cadence_profile_pure,
    thieving_success_probability_pure,
    thieving_target_locked_reasons_pure,
    thieving_wall_safe_roll_succeeds_pure,
    STRONGHOLD_STEP_NAMES,
    STRONGHOLD_TOTAL_STEPS,
)
from ..core.skill_registry import get_skill
from ..logic.farming_logic import (
    advance_farm_clock_pure,
    apply_farming_review_with_queue_pure,
    consume_next_farm_queue_step_pure,
)
from ..data.construction_data import (
    CONSTRUCTION_DATA, DEFAULT_CONSTRUCTION_TARGET, NAIL_DATA, ROOM_DATA,
    SERVANT_DATA, WORKBENCH_TIERS,
)
from ..data.shop_data import SHOP_PLAYER_BUY_PRICES
from ..data.smithing_data import DEFAULT_SMITHING_TARGET
from ..data.urn_data import URN_STATE_ITEM_NAMES, materialize_urn_layout_pure
from ..data.thieving_data import DEFAULT_THIEVING_TARGET, THIEVING_TARGETS
from ..data.agility_data import AGILITY_TARGETS_BY_ID, DEFAULT_AGILITY_TARGET
from ..logic.agility_logic import (
    agility_target_locked_reasons_pure,
    apply_agility_command_pure,
    apply_agility_review_pure,
    sanitize_agility_state_pure,
)
from ..data.flash_powder_factory_data import FLASH_POWDER_FACTORY_ACTIVITY_ID
from ..logic.flash_powder_factory_logic import (
    apply_flash_powder_factory_review_pure,
    apply_factory_outfit_herblore_bonus_pure,
    factory_outfit_four_dose_eligible_pure,
    flash_powder_factory_view_pure,
)
from ..data.pyramid_plunder_data import PYRAMID_PLUNDER_ACTIVITY_ID
from ..logic.pyramid_plunder_logic import (
    apply_pyramid_plunder_review_pure,
    pyramid_plunder_view_pure,
)
from ..data.werewolf_skullball_data import WEREWOLF_SKULLBALL_ACTIVITY_ID
from ..logic.werewolf_skullball_logic import (
    apply_werewolf_skullball_review_pure,
    werewolf_skullball_view_pure,
)
from ..data.gnome_ball_data import GNOME_BALL_ACTIVITY_ID
from ..logic.gnome_ball_logic import (
    apply_gnome_ball_review_pure,
    gnome_ball_view_pure,
)
from ..data.fish_flingers_data import FISH_FLINGERS_ACTIVITY_ID
from ..logic.fish_flingers_logic import (
    apply_fish_flingers_review_pure,
    fish_flingers_view_pure,
    fishing_outfit_multiplier_pure,
)
from ..data.fishing_trawler_data import FISHING_TRAWLER_ACTIVITY_ID
from ..logic.fishing_trawler_logic import (
    apply_fishing_trawler_review_pure,
    fishing_trawler_view_pure,
)
from ..data.great_orb_project_data import GREAT_ORB_PROJECT_ACTIVITY_ID
from ..logic.great_orb_project_logic import (
    apply_great_orb_project_review_pure,
    great_orb_project_view_pure,
)
from ..data.court_cases_data import COURT_CASES_ACTIVITY_ID
from ..logic.court_cases_logic import (
    apply_court_case_review_pure,
    court_cases_view_pure,
    filter_court_summons_outputs_pure,
)
from ..data.circus_data import CIRCUS_ACTIVITY_ID
from ..logic.circus_logic import apply_circus_review_pure, circus_view_pure
from ..data.trouble_brewing_data import TROUBLE_BREWING_ACTIVITY_ID
from ..logic.trouble_brewing_logic import (
    apply_trouble_brewing_review_pure,
    trouble_brewing_view_pure,
)
from ..data.castle_wars_data import CASTLE_WARS_ACTIVITY_ID
from ..logic.castle_wars_logic import (
    apply_castle_wars_review_pure,
    castle_wars_view_pure,
)
from ..data.clan_wars_data import CLAN_WARS_ACTIVITY_ID
from ..logic.clan_wars_logic import clan_wars_view_pure
from ..data.troll_invasion_data import TROLL_INVASION_ACTIVITY_ID
from ..logic.troll_invasion_logic import troll_invasion_view_pure
from ..data.mage_training_arena_data import MAGE_TRAINING_ARENA_ACTIVITY_ID
from ..logic.mage_training_arena_logic import mage_training_arena_view_pure
from ..data.ranging_guild_data import RANGING_GUILD_ACTIVITY_ID
from ..logic.ranging_guild_logic import ranging_guild_view_pure
from ..data.gnome_restaurant_data import GNOME_RESTAURANT_ACTIVITY_ID
from ..logic.gnome_restaurant_logic import (
    gnome_restaurant_can_review_pure,
    gnome_restaurant_view_pure,
)
from ..data.temple_trekking_data import TEMPLE_TREKKING_ACTIVITY_ID
from ..logic.temple_trekking_logic import (
    temple_trekking_can_review_pure,
    temple_trekking_view_pure,
)
from ..data.mobilising_armies_data import MOBILISING_ARMIES_ACTIVITY_ID
from ..logic.mobilising_armies_logic import (
    mobilising_armies_can_review_pure,
    mobilising_armies_view_pure,
)
from ..data.dominion_tower_data import DOMINION_TOWER_ACTIVITY_ID
from ..logic.dominion_tower_logic import (
    dominion_tower_can_review_pure,
    dominion_tower_view_pure,
)
from ..data.crucible_data import CRUCIBLE_ACTIVITY_ID
from ..logic.crucible_logic import crucible_view_pure
from ..data.goblin_raids_data import GOBLIN_RAIDS_ACTIVITY_ID
from ..logic.goblin_raids_logic import goblin_raids_view_pure
from ..data.pest_control_data import PEST_CONTROL_ACTIVITY_ID
from ..logic.pest_control_logic import (
    apply_pest_control_review_pure,
    pest_control_view_pure,
)
from ..data.conquest_data import CONQUEST_ACTIVITY_ID
from ..logic.conquest_logic import conquest_view_pure
from ..data.barbarian_assault_data import BARBARIAN_ASSAULT_ACTIVITY_ID
from ..logic.barbarian_assault_logic import (
    apply_barbarian_assault_review_pure,
    barbarian_assault_view_pure,
)
from ..data.stronghold_player_safety_data import STRONGHOLD_PLAYER_SAFETY_ACTIVITY_ID
from ..logic.stronghold_player_safety_logic import (
    apply_stronghold_player_safety_review_pure,
    stronghold_player_safety_view_pure,
)
from ..data.soul_wars_data import SOUL_WARS_ACTIVITY_ID
from ..logic.soul_wars_logic import (
    apply_soul_wars_review_pure,
    soul_wars_view_pure,
)
from ..data.shades_of_mortton_data import SHADES_OF_MORTTON_ACTIVITY_ID
from ..logic.shades_of_mortton_logic import (
    apply_shades_of_mortton_review_pure,
    shades_of_mortton_view_pure,
)
from ..data.tzhaar_fight_pit_data import TZHAAR_FIGHT_PIT_ACTIVITY_ID
from ..data.treasure_trails_data import TREASURE_TRAILS_ACTIVITY_ID
from ..logic.treasure_trails_logic import treasure_trails_view_pure
from ..logic.tzhaar_fight_pit_logic import (
    apply_tzhaar_fight_pit_review_pure,
    tzhaar_fight_pit_view_pure,
)
from ..data.varrock_museum_data import VARROCK_MUSEUM_ACTIVITY_ID
from ..logic.varrock_museum_logic import (
    apply_varrock_museum_review_pure,
    varrock_museum_view_pure,
)
from ..data.managing_miscellania_data import MANAGING_MISCELLANIA_ACTIVITY_ID
from ..logic.managing_miscellania_logic import (
    apply_managing_miscellania_review_pure,
    managing_miscellania_view_pure,
)
from ..logic.agility_travel import (
    agility_travel_profile_pure,
    apply_run_energy_credit_pure,
    scheduled_travel_reviews_pure,
)
from ..logic.wicked_hood_logic import (
    bank_run_phase_label_pure,
    consume_wicked_hood_route_teleport_pure,
    runecrafting_route_phases_pure,
    wicked_hood_skip_active_outbound_pure,
)
from ..logic.cadence_kernel import EMBEDDED_PROBABILITY, RATE_LIMITED, advance_cadence_pure, default_cadence_profile_state_pure
from ..logic.cadence_live import (
    LIVE_COMBAT_TICKS_PER_REVIEW,
    advance_live_cadence_route_pure,
    resolve_live_cadence_route_pure,
)
from ..data.summoning_data import DEFAULT_SUMMONING_TARGET, SUMMONING_ACTIONS_BY_ID
from ..logic.summoning_logic import (
    apply_summoning_training_action_pure,
    familiar_effective_roll_level_pure,
    restore_summoning_points_pure,
    summoning_action_locked_reasons_pure,
    summoning_action_requirements_pure,
)
from ..logic.slayer_logic import apply_slayer_kills_pure
from ..data.evil_tree_data import (
    EVIL_TREE_ELIGIBLE_BLESSING_TARGETS,
    EVIL_TREE_NEST_MULTIPLIER,
    EVIL_TREE_UTILITY_ID,
)
from ..logic.evil_tree_logic import apply_evil_tree_review_pure
from ..data.big_chinchompa_data import BIG_CHINCHOMPA_UTILITY_ID
from ..logic.big_chinchompa_logic import (
    apply_big_chinchompa_review_pure,
    big_chinchompa_event_active_pure,
    consume_hunter_quota_ticket_pure,
)
from ..data.shooting_star_data import (
    SHOOTING_STAR_ACTIVITY_ID,
    SHOOTING_STAR_ORE_BONUS_CHANCE,
)
from ..logic.shooting_star_logic import (
    apply_shooting_star_review_pure,
    shooting_star_event_mineable_pure,
)
from ..data.fist_of_guthix_data import FIST_OF_GUTHIX_ACTIVITY_ID
from ..logic.fist_of_guthix_logic import (
    apply_fist_of_guthix_review_pure,
    fist_of_guthix_can_review_pure,
)
from ..data.fight_caves_data import FIGHT_CAVES_ACTIVITY_ID
from ..logic.fight_caves_logic import (
    apply_fight_caves_review_pure,
    fight_caves_view_pure,
)
from ..data.phoenix_lair_data import PHOENIX_LAIR_ACTIVITY_ID
from ..logic.phoenix_lair_logic import (
    apply_phoenix_lair_review_pure,
    phoenix_lair_view_pure,
)
from ..data.barrows_data import BARROWS_ACTIVITY_ID
from ..logic.barrows_logic import apply_barrows_review_pure, barrows_view_pure
from ..data.stealing_creation_data import STEALING_CREATION_ACTIVITY_ID
from ..logic.stealing_creation_logic import (
    apply_stealing_creation_review_pure,
    stealing_creation_view_pure,
)
from ..data.sorceress_garden_data import SORCERESS_GARDEN_ACTIVITY_ID
from ..logic.sorceress_garden_logic import (
    apply_sorceress_garden_review_pure,
    sorceress_garden_locked_reasons_pure,
    sorceress_garden_view_pure,
)
from ..data.penguin_hide_and_seek_data import PENGUIN_HIDE_AND_SEEK_ACTIVITY_ID
from ..logic.penguin_hide_and_seek_logic import (
    apply_penguin_review_pure,
    penguin_view_pure,
)
from ..data.vinesweeper_data import (
    COMPOST_POTION_ACTIVITY_ID,
    VINESWEEPER_ACTIVITY_ID,
)
from ..logic.vinesweeper_logic import (
    apply_compost_potion_pure,
    apply_vinesweeper_review_pure,
    vinesweeper_view_pure,
)
from ..data.warriors_guild_data import WARRIORS_GUILD_ACTIVITIES
from ..logic.warriors_guild_logic import (
    apply_warriors_guild_activity_pure,
    apply_warriors_guild_cyclops_kills_pure,
    apply_warriors_guild_cyclossus_kills_pure,
    consume_warriors_guild_cyclops_tokens_pure,
    sanitize_warriors_guild_state_pure,
    warriors_guild_activity_locked_reasons_pure,
)
from ..data.livid_farm_data import LIVID_FARM_ACTIVITY_ID
from ..logic.livid_farm_logic import (
    apply_livid_farm_reviews_pure,
    livid_farm_locked_reasons_pure,
)

from ..logic import inventory_pure
from ..data.item_values import ITEM_VALUES, STACKABLE_ITEM_NAMES

# --- split re-exports (additive; see the module docstrings) ---
from .runtime_actions_utility import (  # noqa: F401  (re-export)
    handle_utility_answer,
)

from .runtime_actions_thieving import (  # noqa: F401  (re-export)
    _thieving_award_success,
    _thieving_failure,
    _thieving_grant_outputs,
    _thieving_rng_index,
    handle_thieving_answer,
)

from .runtime_actions_gathering import (  # noqa: F401  (re-export)
    handle_fishing_answer,
    handle_hunter_answer,
    handle_mining_answer,
    handle_woodcutting_answer,
)

from .runtime_actions_production import (  # noqa: F401  (re-export)
    _spec_output_items,
    handle_construction_answer,
    handle_cooking_answer,
    handle_crafting_answer,
    handle_firemaking_answer,
    handle_fletching_answer,
    handle_herblore_answer,
    handle_prayer_answer,
    handle_quest_answer,
    handle_runecrafting_answer,
    handle_smithing_answer,
    handle_summoning_answer,
)

from .runtime_actions_gates import (  # noqa: F401  (re-export)
    _can_start_agility_action,
    _can_start_combat_action,
    _can_start_construction_action,
    _can_start_cooking_action,
    _can_start_dungeoneering_action,
    _can_start_crafting_action,
    _can_start_firemaking_action,
    _can_start_fishing_action,
    _can_start_fletching_action,
    _can_start_herblore_action,
    _can_start_hunter_action,
    _can_start_magic_action,
    _can_start_mining_action,
    _can_start_prayer_action,
    _can_start_quest_action,
    _can_start_runecrafting_action,
    _can_start_smithing_action,
    _can_start_summoning_action,
    _can_start_thieving_action,
    _can_start_utility_action,
    _can_start_woodcutting_action,
)

from .runtime_actions_magic import (  # noqa: F401  (re-export)
    _magic_alch_values,
    handle_magic_answer,
)

from .runtime_actions_combat import (  # noqa: F401  (re-export)
    handle_combat_answer,
)

from .runtime_actions_carried import (  # noqa: F401  (re-export)
    _BANK_RUN_TARGET_KEYS,
    _OVERLAY_STACKABLE_NAMES,
    _OVERLAY_TARGET_KEYS,
    _PROCESSING_DATA_TABLES,
    _PROCESSING_HANDLER_KEYS,
    _agility_carried_requirement_gaps,
    _agility_casual_layout_for,
    _agility_equipment_satisfies,
    _agility_target_can_damage,
    _bank_can_supply,
    _carried_target_view,
    _owned_bag_capacities,
    _pack_can_supply,
    _processing_presence_requirements_for,
    _processing_requirements_for,
    _repack_view_for_target,
    _set_carried_target_map,
    _try_pack_yak_winter_storage_overlay,
    _without_urn_substitutions,
    run_answer_with_carried_overlay,
)

from .runtime_actions_activities import (  # noqa: F401  (re-export)
    KNIGHT_WAVES_UTILITY_KEY,
    MAGE_ARENA_ATTUNE_PREFIX,
    MAGE_ARENA_UTILITY_KEY,
    STRONGHOLD_UTILITY_KEY,
    _handle_barrows_answer,
    _handle_big_chinchompa_answer,
    _handle_circus_answer,
    _handle_court_cases_answer,
    _handle_evil_tree_answer,
    _handle_fight_caves_answer,
    _handle_dagannoth_kings_answer,
    _handle_fish_flingers_answer,
    _handle_fishing_trawler_answer,
    _handle_fist_of_guthix_answer,
    _handle_gnome_ball_answer,
    _handle_great_orb_project_answer,
    _handle_knight_waves_answer,
    _handle_livid_farm_answer,
    _handle_mage_arena_answer,
    _handle_mage_arena_attunement_answer,
    _handle_managing_miscellania_answer,
    _handle_penguin_answer,
    _handle_phoenix_lair_answer,
    _handle_pyramid_plunder_answer,
    _handle_shooting_star_answer,
    _handle_sorceress_garden_answer,
    _handle_stealing_creation_answer,
    _handle_stronghold_answer,
    _handle_vinesweeper_answer,
    _handle_werewolf_skullball_answer,
    handle_agility_answer,
    handle_barbarian_assault_answer,
    handle_castle_wars_answer,
    handle_clan_wars_answer,
    handle_troll_invasion_answer,
    handle_mage_training_arena_answer,
    handle_ranging_guild_answer,
    handle_temple_trekking_answer,
    handle_mobilising_armies_answer,
    handle_gnome_restaurant_answer,
    handle_dominion_tower_answer,
    handle_dungeoneering_answer,
    handle_crucible_answer,
    handle_goblin_raids_answer,
    handle_flash_powder_factory_answer,
    handle_pest_control_answer,
    handle_conquest_answer,
    handle_shades_of_mortton_answer,
    handle_soul_wars_answer,
    handle_stronghold_player_safety_answer,
    handle_trouble_brewing_answer,
    handle_treasure_trail_answer,
    handle_tzhaar_fight_pit_answer,
    handle_varrock_museum_answer,
)

from .runtime_actions_shared import (  # noqa: F401  (re-export)
    _COMBAT_EXP_SKILLS,
    _admit_live_cadence,
    _apply_farming_queue_result,
    _award_action_xp_rewards,
    _charge_urn_for_action,
    _combat_review_ticks,
    _combined_success_probability,
    _farming_levels_before_answer,
    _record_action,
    _record_cadence_wait,
    _refresh_combat_levels,
    _switch_material_failure_to_bankstanding,
    advance_farming_clock_for_review,
    advance_shared_review_state_for_review,
    fishing_materials_text,
    handle_farming_queue_answer,
    handle_farming_review_answer,
    missing_materials_text,
)

from .runtime_actions_context import (  # noqa: F401  (re-export)
    RuntimeActionContext,
)














































































































































































































































CAN_START_HANDLERS: dict[str, Callable[[RuntimeActionContext], bool]] = {
    "mining": _can_start_mining_action,
    "woodcutting": _can_start_woodcutting_action,
    "smithing": _can_start_smithing_action,
    "crafting": _can_start_crafting_action,
    "fletching": _can_start_fletching_action,
    "firemaking": _can_start_firemaking_action,
    "fishing": _can_start_fishing_action,
    "hunter": _can_start_hunter_action,
    "cooking": _can_start_cooking_action,
    "runecrafting": _can_start_runecrafting_action,
    "herblore": _can_start_herblore_action,
    "prayer": _can_start_prayer_action,
    "magic": _can_start_magic_action,
    "construction": _can_start_construction_action,
    "dungeoneering": _can_start_dungeoneering_action,
    "thieving": _can_start_thieving_action,
    "agility": _can_start_agility_action,
    "summoning": _can_start_summoning_action,
    "combat": _can_start_combat_action,
    "utility": _can_start_utility_action,
    "quest": _can_start_quest_action,
}


ANSWER_HANDLERS: dict[str, Callable[[RuntimeActionContext], bool]] = {
    "mining": handle_mining_answer,
    "woodcutting": handle_woodcutting_answer,
    "smithing": handle_smithing_answer,
    "crafting": handle_crafting_answer,
    "fletching": handle_fletching_answer,
    "firemaking": handle_firemaking_answer,
    "fishing": handle_fishing_answer,
    "hunter": handle_hunter_answer,
    "cooking": handle_cooking_answer,
    "runecrafting": handle_runecrafting_answer,
    "herblore": handle_herblore_answer,
    "prayer": handle_prayer_answer,
    "magic": handle_magic_answer,
    "construction": handle_construction_answer,
    "dungeoneering": handle_dungeoneering_answer,
    "thieving": handle_thieving_answer,
    "agility": handle_agility_answer,
    "summoning": handle_summoning_answer,
    "combat": handle_combat_answer,
    "utility": handle_utility_answer,
    "quest": handle_quest_answer,
}


def can_start_action(ctx: RuntimeActionContext, handler_key: Optional[str]) -> bool:
    checker = CAN_START_HANDLERS.get(str(handler_key or ""))
    return checker(ctx) if checker is not None else True


def answer_handler_for_key(handler_key: Optional[str]) -> Optional[Callable[[RuntimeActionContext], bool]]:
    return ANSWER_HANDLERS.get(str(handler_key or ""))
