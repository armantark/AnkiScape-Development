"""Run one pinned unproductive-activity-selector proof on the owned remote mirror."""

import argparse
import base64
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
import uuid
from unittest.mock import patch

EVIDENCE = Path("memory-bank/evidence/unproductive-activity-selector-2026-09-08")
INVENTORY = EVIDENCE / "source-inventory.json.gz"
INVENTORY_SHA256 = "d39e7269bf2aaab918cb7c6646965bb20df80601fa46342315da24a9c43f85fc"
BASELINE_COMMIT = "6dacde5486c72e73ca170c039bf8207dec22ac81"
SELECTORS = [
    "TestUnproductiveActivitySelector.test_predicates_and_handlers_resolve_after_import_only_when_selected",
    "TestUnproductiveActivitySelector.test_irregular_predicates_keep_their_original_meaning",
    "TestUnproductiveActivitySelector.test_flash_powder_routes_and_sequential_equality",
    "TestUnproductiveActivityCaller.test_failed_review_builds_activity_context_only_for_a_match_and_keeps_tail"
]
CASES = [
    "TROUBLE_BREWING_ACTIVITY_ID:False",
    "TROUBLE_BREWING_ACTIVITY_ID:True",
    "TROUBLE_BREWING_ACTIVITY_ID:predicate-error",
    "CASTLE_WARS_ACTIVITY_ID:False",
    "CASTLE_WARS_ACTIVITY_ID:True",
    "CASTLE_WARS_ACTIVITY_ID:predicate-error",
    "PEST_CONTROL_ACTIVITY_ID:False",
    "PEST_CONTROL_ACTIVITY_ID:True",
    "PEST_CONTROL_ACTIVITY_ID:predicate-error",
    "BARBARIAN_ASSAULT_ACTIVITY_ID:False",
    "BARBARIAN_ASSAULT_ACTIVITY_ID:True",
    "BARBARIAN_ASSAULT_ACTIVITY_ID:predicate-error",
    "SOUL_WARS_ACTIVITY_ID:False",
    "SOUL_WARS_ACTIVITY_ID:True",
    "SOUL_WARS_ACTIVITY_ID:predicate-error",
    "SHADES_OF_MORTTON_ACTIVITY_ID:False",
    "SHADES_OF_MORTTON_ACTIVITY_ID:True",
    "SHADES_OF_MORTTON_ACTIVITY_ID:predicate-error",
    "CLAN_WARS_ACTIVITY_ID:False",
    "CLAN_WARS_ACTIVITY_ID:True",
    "CLAN_WARS_ACTIVITY_ID:predicate-error",
    "TROLL_INVASION_ACTIVITY_ID:False",
    "TROLL_INVASION_ACTIVITY_ID:True",
    "MAGE_TRAINING_ARENA_ACTIVITY_ID:False",
    "MAGE_TRAINING_ARENA_ACTIVITY_ID:True",
    "MAGE_TRAINING_ARENA_ACTIVITY_ID:predicate-error",
    "RANGING_GUILD_ACTIVITY_ID:False",
    "RANGING_GUILD_ACTIVITY_ID:True",
    "RANGING_GUILD_ACTIVITY_ID:predicate-error",
    "MOBILISING_ARMIES_ACTIVITY_ID:False",
    "MOBILISING_ARMIES_ACTIVITY_ID:True",
    "MOBILISING_ARMIES_ACTIVITY_ID:predicate-error",
    "TEMPLE_TREKKING_ACTIVITY_ID:False",
    "TEMPLE_TREKKING_ACTIVITY_ID:True",
    "TEMPLE_TREKKING_ACTIVITY_ID:predicate-error",
    "GNOME_RESTAURANT_ACTIVITY_ID:False",
    "GNOME_RESTAURANT_ACTIVITY_ID:True",
    "GNOME_RESTAURANT_ACTIVITY_ID:predicate-error",
    "CRUCIBLE_ACTIVITY_ID:False",
    "CRUCIBLE_ACTIVITY_ID:True",
    "CRUCIBLE_ACTIVITY_ID:predicate-error",
    "GOBLIN_RAIDS_ACTIVITY_ID:False",
    "GOBLIN_RAIDS_ACTIVITY_ID:True",
    "GOBLIN_RAIDS_ACTIVITY_ID:predicate-error",
    "flash:utility:{'flash_powder_factory': {'active': False}}",
    "flash:utility:{'flash_powder_factory': {}}",
    "flash:utility:['truthy non-dict']",
    "flash:agility:{'flash_powder_factory': {'active': False}}",
    "flash:agility:{'flash_powder_factory': {}}",
    "flash:agility:['truthy non-dict']",
    "no-match:utility:[]",
    "no-match:utility:'unknown'",
    "no-match:other:'flash_powder_factory'",
    "no-match:None:'flash_powder_factory'"
]


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    directory = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def local_sources(root):
    raw = (root / INVENTORY).read_bytes()
    if hashlib.sha256(raw).hexdigest() != INVENTORY_SHA256:
        raise ValueError("source inventory pin mismatch; no remote calls permitted")
    sources = json.loads(gzip.decompress(raw))["files"]
    for name, expected in sources.items():
        source = root / name
        if not source.is_file():
            raise ValueError(f"local source missing: {name}")
        if hashlib.sha256(source.read_bytes()).hexdigest() != expected:
            raise ValueError(f"local source mismatch: {name}")
    return sources


def assert_no_pending(remote):
    pending = remote._pending_path()
    if pending.exists():
        raise RuntimeError(f"existing remote pending work blocks this one-job run: {pending}")


def remote_prefix(remote, lane):
    environment = [
        "env",
        "-u",
        "PYTHONOPTIMIZE",
        "PATH=/opt/homebrew/bin:/usr/bin:/bin",
        f"ANKISCAPE_GAME_MAIN={remote.REMOTE_GAME_MAIN}",
        f"ANKISCAPE_DARKAN_WORLD_SERVER={remote.REMOTE_DARKAN}",
    ]
    if lane == "plain":
        environment += [
            f"PYTHONPATH={remote.REMOTE_PLAIN_SITE}",
            "/opt/homebrew/bin/python3",
        ]
    else:
        environment += [
            "QT_QPA_PLATFORM=offscreen",
            str(remote.REMOTE_VENV / "bin/python"),
        ]
    return shlex.join(environment + ["-B"])


def comparator_command(remote, lane, output, *, preflight=False):
    arguments = [
        "tools/runtime/compare_unproductive_activity_selector.py",
        "--inventory",
        str(remote.REMOTE_REPO / INVENTORY),
        "--inventory-sha256",
        INVENTORY_SHA256,
        "--output",
        str(output),
    ]
    if preflight:
        arguments.append("--preflight")
    return remote_prefix(remote, lane) + " " + shlex.join(arguments)


def expected_guard(sources):
    return {
        "baseline_commit": BASELINE_COMMIT,
        "inventory_sha256": INVENTORY_SHA256,
        "sources_before": sources,
        "status": "PREFLIGHT_PASS",
        "product_imported": False,
        "sources_after": sources,
    }


def capture_guard(remote, lane, remote_output, local_output, sources):
    reader = (
        "import base64,pathlib; print(base64.b64encode(pathlib.Path("
        + repr(str(remote_output))
        + ").read_bytes()).decode())"
    )
    command = (
        f"cd {shlex.quote(str(remote.REMOTE_REPO))} && "
        + comparator_command(remote, lane, remote_output, preflight=True)
        + " && " + remote_prefix(remote, lane) + " -c " + shlex.quote(reader)
    )
    raw = remote._ssh(
        command,
        label="unproductive-activity-selector source guard",
        repeat_safe=True,
    )
    decoded = base64.b64decode(raw.strip(), validate=True)
    local_output.with_suffix(".raw.json.gz").write_bytes(decoded)
    report = json.loads(gzip.decompress(decoded))
    if report != expected_guard(sources):
        raise ValueError("remote source guard did not report the complete pinned inventory")
    save(local_output, report)


def launch_one(args, remote, command):
    original_ssh = remote._ssh

    def launch_ssh(text, *, label, repeat_safe=False):
        if label == "remote lane launch":
            pending_path = remote._pending_path()
            pending = json.loads(pending_path.read_text())
            if set(pending) != {"run_id", "log_path", "report_path"}:
                raise RuntimeError("new pending identity has an unexpected shape")
            save(
                args.output / "identity.json",
                {"lane": args.lane, "kind": args.kind, "pending": pending},
            )
        return original_ssh(text, label=label, repeat_safe=repeat_safe)

    with patch.object(remote, "_remote_lane_command", return_value=command), patch.object(
        remote, "_ssh", side_effect=launch_ssh
    ):
        return remote._stream_remote_run(
            args.lane,
            timeout=args.timeout,
            poll_interval=5,
        )


def retain_interrupted(remote, output, error):
    retained = {"error_type": type(error).__name__, "error": str(error)}
    identity_path = output / "identity.json"
    if identity_path.exists():
        identity = json.loads(identity_path.read_text())["pending"]
        retained["pending"] = identity
        for key, suffix in (("log_path", "interrupted.log"), ("report_path", "interrupted.report")):
            try:
                text = remote._ssh(
                    f"cat {shlex.quote(identity[key])} 2>/dev/null || true",
                    label=f"unproductive-activity-selector interrupted {key}",
                    repeat_safe=True,
                )
            except Exception as inspection_error:
                retained[f"{key}_inspection_error"] = str(inspection_error)
            else:
                (output / suffix).write_text(text)
    save(output / "interrupted.json", retained)


def validate_comparison(report, sources):
    if report.get("status") != "PASS":
        raise ValueError("comparison did not pass")
    if report.get("baseline_commit") != BASELINE_COMMIT:
        raise ValueError("comparison baseline commit differs")
    if report.get("inventory_sha256") != INVENTORY_SHA256:
        raise ValueError("comparison inventory differs")
    if report.get("sources_before") != sources or report.get("sources_after") != sources:
        raise ValueError("comparison source snapshots differ")
    rows = report.get("cases")
    if not isinstance(rows, list) or [row.get("case") for row in rows] != CASES:
        raise ValueError("comparison must contain exactly the 54 named cases in order")
    for row in rows:
        before = base64.b64decode(row["baseline_pickle_base64"], validate=True)
        after = base64.b64decode(row["candidate_pickle_base64"], validate=True)
        if row.get("equal") is not True or row.get("pickle_bytes_equal") is not True or before != after:
            raise ValueError("complete output pickle equality failed")
        observed, expected = row["observed"], row["expected"]
        if row.get("route_pass") is not True or any(observed.get(key) != value for key, value in expected.items()):
            raise ValueError("advertised unproductive activity route was not exercised")


def retain_comparison(remote, lane, remote_path, local_path, sources):
    reader = (
        "import base64,pathlib; print(base64.b64encode(pathlib.Path("
        + repr(str(remote_path))
        + ").read_bytes()).decode())"
    )
    encoded = remote._ssh(
        remote_prefix(remote, lane) + " -c " + shlex.quote(reader),
        label="unproductive-activity-selector comparison bytes",
        repeat_safe=True,
    )
    raw = base64.b64decode(encoded.strip(), validate=True)
    local_path.write_bytes(raw)
    validate_comparison(json.loads(gzip.decompress(raw)), sources)


def run_one(args, remote, sources):
    assert_no_pending(remote)
    if local_sources(args.root) != sources:
        raise ValueError("local source snapshot changed before sync")
    remote._preflight(args.lane)
    with patch.object(
        remote,
        "_reconcile_pending_run",
        side_effect=lambda: assert_no_pending(remote),
    ):
        remote._sync(args.root)
    assert_no_pending(remote)
    session = uuid.uuid4().hex
    stem = remote.REMOTE_ROOT / "reports" / f"unproductive-activity-selector-{session}-{args.lane}-{args.kind}"
    capture_guard(remote, args.lane, str(stem) + "-before.json.gz", args.output / "before.json", sources)
    launch_guard = comparator_command(
        remote,
        args.lane,
        str(stem) + "-launch-preflight.json.gz",
        preflight=True,
    )
    result_path = str(stem) + ".json.gz" if args.kind == "comparison" else None
    if args.kind == "focused":
        product_command = remote_prefix(remote, args.lane) + " " + shlex.join(
            ["run_tests.py", "--verbosity", "2", *SELECTORS]
        )
    else:
        product_command = comparator_command(remote, args.lane, result_path)
    try:
        code, log = launch_one(args, remote, launch_guard + " && " + product_command)
    except BaseException as error:
        retain_interrupted(remote, args.output, error)
        raise
    (args.output / "run.log").write_text(log)
    identity = json.loads((args.output / "identity.json").read_text())["pending"]
    report_text = remote._ssh(
        "cat " + shlex.quote(identity["report_path"]),
        label="unproductive-activity-selector exact-run report",
        repeat_safe=True,
    )
    (args.output / "run.report").write_text(report_text)
    if int(report_text.strip()) != code:
        raise ValueError("completion report changed")
    save(args.output / "completion.json", {"exit_code": code, "pending": identity})
    capture_guard(remote, args.lane, str(stem) + "-after.json.gz", args.output / "after.json", sources)
    save(args.output / "local-after.json", local_sources(args.root))
    if code != 0:
        raise RuntimeError(f"exact run failed with exit {code}; no relaunch permitted")
    if args.kind == "focused":
        summary = remote.parse_unittest_summary(log)
        if summary.tests != len(SELECTORS) or summary.skipped != 0:
            raise ValueError(
                f"expected {len(SELECTORS)} tests and zero skips, got {summary}"
            )
    else:
        retain_comparison(
            remote,
            args.lane,
            result_path,
            args.output / "comparison.json.gz",
            sources,
        )
    save(
        args.output / "accepted.json",
        {
            "status": "PASS",
            "lane": args.lane,
            "kind": args.kind,
            "inventory_sha256": INVENTORY_SHA256,
            "identity": identity,
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lane", choices=("plain", "qt"), required=True)
    parser.add_argument("--kind", choices=("focused", "comparison"), required=True)
    parser.add_argument("--timeout", type=float, default=1800)
    args = parser.parse_args()
    if sys.flags.optimize or "PYTHONOPTIMIZE" in os.environ:
        raise SystemExit("optimized interpreter refused; no remote calls permitted")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    args.root = args.root.resolve()
    args.output = args.output.resolve()
    if args.output.is_relative_to(args.root):
        parser.error("--output must be outside the source tree")
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("--output must be absent or empty; one invocation owns one job")
    if not (args.root / "run_tests.py").is_file():
        parser.error("--root is not an AnkiScape worktree")
    sources = local_sources(args.root)
    forbidden = sorted(
        name
        for name in sys.modules
        if name == "pkg_alias" or name.split(".")[0] in {"ankiscape", "tests"}
    )
    if forbidden:
        raise RuntimeError(f"local product imported before remote setup: {forbidden}")
    args.output.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(args.root))
    from tools import run_remote_tests as remote

    if remote.HOST != "armans-macbook-pro":
        raise ValueError("remote host pin differs")
    if str(remote.REMOTE_REPO) != "/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork":
        raise ValueError("remote repository pin differs")
    remote.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with remote.LOCAL_MIRROR_LOCK_PATH.open("a+") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit(f"remote mirror busy: {remote.LOCAL_MIRROR_LOCK_PATH}")
        run_one(args, remote, sources)


if __name__ == "__main__":
    main()
