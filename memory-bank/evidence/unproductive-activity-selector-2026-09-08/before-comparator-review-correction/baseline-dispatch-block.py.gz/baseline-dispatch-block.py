        activity_state = _state.player_data.get("agility_activity_state") or {}
        if (
            (
                (
                    review_action_handler_key(_state.current_skill) == "utility"
                    and _state.player_data.get("current_utility")
                    == runtime_actions.FLASH_POWDER_FACTORY_ACTIVITY_ID
                )
                or (
                    review_action_handler_key(_state.current_skill) == "agility"
                    and _state.player_data.get("current_agility")
                    == runtime_actions.FLASH_POWDER_FACTORY_ACTIVITY_ID
                )
            )
            and isinstance(activity_state, dict)
            and activity_state.get(
                runtime_actions.FLASH_POWDER_FACTORY_ACTIVITY_ID
            )
        ):
            runtime_actions.handle_flash_powder_factory_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.TROUBLE_BREWING_ACTIVITY_ID
            and runtime_actions.trouble_brewing_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_trouble_brewing_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.CASTLE_WARS_ACTIVITY_ID
            and runtime_actions.castle_wars_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_castle_wars_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.PEST_CONTROL_ACTIVITY_ID
            and runtime_actions.pest_control_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_pest_control_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.BARBARIAN_ASSAULT_ACTIVITY_ID
            and runtime_actions.barbarian_assault_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_barbarian_assault_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.SOUL_WARS_ACTIVITY_ID
            and runtime_actions.soul_wars_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_soul_wars_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.SHADES_OF_MORTTON_ACTIVITY_ID
            and runtime_actions.shades_of_mortton_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_shades_of_mortton_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.CLAN_WARS_ACTIVITY_ID
            and runtime_actions.clan_wars_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_clan_wars_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.TROLL_INVASION_ACTIVITY_ID
            and bool(_state.player_data.get("troll_invasion"))
        ):
            runtime_actions.handle_troll_invasion_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.MAGE_TRAINING_ARENA_ACTIVITY_ID
            and runtime_actions.mage_training_arena_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_mage_training_arena_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.RANGING_GUILD_ACTIVITY_ID
            and runtime_actions.ranging_guild_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_ranging_guild_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.MOBILISING_ARMIES_ACTIVITY_ID
            and runtime_actions.mobilising_armies_can_review_pure(_state.player_data)
        ):
            runtime_actions.handle_mobilising_armies_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.TEMPLE_TREKKING_ACTIVITY_ID
            and runtime_actions.temple_trekking_can_review_pure(_state.player_data)
        ):
            runtime_actions.handle_temple_trekking_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.GNOME_RESTAURANT_ACTIVITY_ID
            and runtime_actions.gnome_restaurant_view_pure(_state.player_data).get("order")
        ):
            runtime_actions.handle_gnome_restaurant_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.CRUCIBLE_ACTIVITY_ID
            and runtime_actions.crucible_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_crucible_answer(
                _runtime_action_context(),
                productive=False,
            )
        elif (
            review_action_handler_key(_state.current_skill) == "utility"
            and _state.player_data.get("current_utility")
            == runtime_actions.GOBLIN_RAIDS_ACTIVITY_ID
            and runtime_actions.goblin_raids_view_pure(_state.player_data).get("active")
        ):
            runtime_actions.handle_goblin_raids_answer(
                _runtime_action_context(),
                productive=False,
            )
