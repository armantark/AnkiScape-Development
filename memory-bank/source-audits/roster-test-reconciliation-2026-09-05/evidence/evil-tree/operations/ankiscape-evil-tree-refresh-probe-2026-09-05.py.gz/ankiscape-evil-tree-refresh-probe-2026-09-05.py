#!/usr/bin/env python3
"""Measure Evil Tree refresh through the unchanged root review callback path."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import traceback

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
REPORTS = ROOT.parent / 'reports'
BINDINGS = Path('/tmp/ankiscape-evil-tree-refresh-bindings-2026-09-05.json')
BINDINGS_SHA256 = 'fcd57b6f4d04bfe6ea36f64dab94c98ce62b1413455467ced8fdef0af3a18351'


class PreconditionFailure(RuntimeError):
    pass


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def source_guard(expected):
    actual = {name: sha(ROOT / name) for name in expected}
    parents = {Path(name).parts[0] for name in expected if name.endswith('.py') and '/' in name}
    inventory = {str(p.relative_to(ROOT)) for parent in parents for p in (ROOT / parent).rglob('*.py')}
    inventory.update(p.name for p in ROOT.glob('*.py'))
    wanted = {name for name, digest in expected.items() if digest is not None and name.endswith('.py')}
    if actual != expected or inventory != wanted:
        raise PreconditionFailure('Source hash or Python inventory mismatch; no runtime callbacks launched')
    return actual


def availability(addon):
    reasons = {target: list(addon.firemaking_target_locked_reasons_pure(
        addon.player_data, target, addon.FIREMAKING_DATA, addon.QUEST_UNLOCK_RULES))
        for target in addon.FIREMAKING_DATA}
    return {'any_firemaking': any(not value for value in reasons.values()),
            'ordinary_logs_reasons': reasons['logs']}


def snapshot(addon):
    player = addon.player_data
    state = player.get('evil_tree', {})
    return {'current_skill': addon.current_skill, 'handler_key': addon.review_action_handler_key(addon.current_skill),
            'current_utility': player.get('current_utility'),
            'evil_phase': state.get('session', {}).get('phase'), 'evil_event': bool(state.get('active_event')),
            'firemaking_exp': player.get('firemaking_exp'), 'firemaking_level': player.get('firemaking_level'),
            'ordinary_logs': player.get('inventory', {}).get('Logs', 0),
            'recovery_keys_present': [key for key in addon._COMBAT_RECOVERY_STATE_KEYS if key in player],
            'combat_rest_reviews': player.get('combat_rest_reviews'),
            'cached_fingerprint': addon._SKILL_AVAILABILITY_CACHE_FINGERPRINT,
            'fresh_fingerprint': addon._skill_availability_fingerprint(), **availability(addon)}


class Recorder:
    def __init__(self, addon, out):
        self.addon = addon
        self.case = 'setup'
        self.phase = 'setup'
        self.events = []
        self.sink_values = None
        self.recovery_inputs = {}
        self.stream = (out / 'trace.jsonl').open('x', encoding='utf-8')
        functions = {
            'root_answer': addon.on_good_answer,
            'utility_handler': addon._registered_answer_handler(addon.UTILITY_REVIEW_ACTION_DISPLAY_NAME),
            'evil_tree_handler': addon.runtime_actions._handle_evil_tree_answer,
            'level_callback': addon.level_up_check,
            'core_level_check': addon._core_level_up_check,
            'achievement_check': addon.check_achievements,
            'recovery_wrapper': addon._apply_safe_combat_recovery_after_review,
            'recovery_pure': addon.apply_safe_combat_recovery_pure,
            'refresh': addon._refresh_skill_availability,
            'ui_projection': addon.refresh_skill_availability,
            'feedback_completion': addon._finish_review_feedback_context,
            'world_clock': addon._advance_world_events_after_review,
            'bankstanding': addon._switch_to_bankstanding,
        }
        self.functions = functions
        self.codes = {function.__code__: label for label, function in functions.items()}
        self.refresh_code = functions['refresh'].__code__
        write_json(out / 'callback-bindings.json', {label: {
            'module': function.__module__, 'qualname': function.__qualname__,
            'file': function.__code__.co_filename, 'line': function.__code__.co_firstlineno,
            'source_sha256': sha(Path(function.__code__.co_filename)),
        } for label, function in functions.items()})

    def append(self, event):
        row = {'sequence': len(self.events), 'case': self.case, 'phase': self.phase, **event}
        self.events.append(row)
        self.stream.write(json.dumps(row, sort_keys=True) + '\n')
        self.stream.flush()

    def profile(self, frame, event, result):
        label = self.codes.get(frame.f_code)
        if label is None or event not in ('call', 'return'):
            return
        call_chain, caller = [], frame.f_back
        while caller is not None:
            if caller.f_code in self.codes:
                call_chain.append(self.codes[caller.f_code])
            caller = caller.f_back
        row = {'function': label, 'event': event, 'call_chain': call_chain, 'state': snapshot(self.addon)}
        if label in ('level_callback', 'core_level_check'):
            row['skill'] = frame.f_locals.get('skill')
        if label == 'recovery_pure':
            if event == 'call':
                self.recovery_inputs[id(frame)] = copy.deepcopy(frame.f_locals['player_data'])
            else:
                before = self.recovery_inputs.pop(id(frame))
                row['changed'] = result != before
                row['rest_before'] = before.get('combat_rest_reviews')
                row['rest_after'] = result.get('combat_rest_reviews') if isinstance(result, dict) else None
        if label in ('evil_tree_handler', 'utility_handler') and event == 'return':
            row['result'] = result
        if label == 'ui_projection' and event == 'call':
            values = [frame.f_locals[name] for name in frame.f_code.co_varnames[:frame.f_code.co_argcount]]
            if len(values) != 7 or any(type(value) is not bool for value in values):
                raise PreconditionFailure('UI projection did not receive seven booleans')
            self.sink_values = values
            row['availability_values'] = values
        self.append(row)

    def trace(self, frame, event, argument):
        if frame.f_code is not self.refresh_code:
            return None
        if event == 'exception':
            kind, error, _traceback = argument
            self.append({'function': 'refresh', 'event': 'caught_exception',
                         'exception_type': kind.__module__ + '.' + kind.__qualname__,
                         'message': str(error), 'line': frame.f_lineno,
                         'traceback': traceback.format_exception(kind, error, _traceback)})
        return self.trace

    def start(self):
        if sys.getprofile() is not None or sys.gettrace() is not None:
            raise PreconditionFailure('Another Python trace is active')
        sys.setprofile(self.profile)
        sys.settrace(self.trace)

    def stop(self):
        sys.setprofile(None)
        sys.settrace(None)
        self.stream.close()


def load_runtime():
    os.environ['QT_QPA_PLATFORM'] = 'offscreen'
    os.environ['ANKISCAPE_DEBUG'] = '0'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT))
    import aqt
    from aqt.qt import QApplication, QMainWindow
    if aqt.mw is not None:
        raise PreconditionFailure('A live Anki main window is present; refusing to use it')
    app = QApplication.instance() or QApplication([])

    class MemoryCollection:
        def __init__(self):
            self.config = {'ankiscape_popups_enabled': False, 'ankiscape_review_hud_enabled': False,
                           'ankiscape_floating_xp_enabled': False, 'ankiscape_review_action_multiplier': 1}
            self.writes = []

        def get_config(self, name, default=None):
            return copy.deepcopy(self.config.get(name, default))

        def set_config(self, name, value):
            self.config[name] = copy.deepcopy(value)
            self.writes.append({'key': name})

        def remove_config(self, name):
            self.config.pop(name, None)
            self.writes.append({'removed_key': name})

    window = QMainWindow()
    window.col = MemoryCollection()
    aqt.mw = window
    name = 'ankiscape_evil_tree_refresh_probe'
    spec = importlib.util.spec_from_file_location(name, ROOT / '__init__.py', submodule_search_locations=[str(ROOT)])
    addon = importlib.util.module_from_spec(spec)
    sys.modules[name] = addon
    spec.loader.exec_module(addon)
    if not addon.ui.HAS_QT or addon.mw is not window:
        raise PreconditionFailure('The native Qt runtime did not bind the isolated window')
    return addon, app, window


def run_cases(addon, recorder, expected, out):
    storage = importlib.import_module(addon.__name__ + '.core.storage_pure')
    tree_data = importlib.import_module(addon.__name__ + '.data.evil_tree_data')
    tree_logic = importlib.import_module(addon.__name__ + '.logic.evil_tree_logic')
    base = storage.default_player_data(addon.ORE_DATA)
    base['inventory'] = {}
    base['shop_market_clock'] = {'answered_cards': tree_data.EVIL_TREE_SPAWN_REVIEWS}
    base, _events = tree_logic.advance_evil_tree_world_clock_pure(base, tier_roll=0.0, location_roll=0.0)
    base['current_utility'] = tree_data.EVIL_TREE_UTILITY_ID
    has_hatchet = addon.runtime_actions.best_woodcutting_axe_pure(
        int(base['woodcutting_level']), base['inventory'], base['toolbelt'], addon.WOODCUTTING_AXE_DATA) is not None
    if (not has_hatchet or base['firemaking_level'] != 1 or base['firemaking_exp'] != 0
            or base['evil_tree']['active_event'].get('tier_id') != 'normal' or base.get('farm_queue')
            or not all(key in base for key in addon._COMBAT_RECOVERY_STATE_KEYS)):
        raise PreconditionFailure('Default seeded fixture does not satisfy the declared tool, level, event, or recovery preconditions')
    mode, reasons = tree_logic.evil_tree_entry_mode_pure(base, has_usable_hatchet=has_hatchet)
    if mode != 'full':
        raise PreconditionFailure('Default seeded fixture is not a full Evil Tree visit: ' + repr((mode, reasons)))
    original_random = addon.random.random
    addon.random.random = lambda: 0.0
    cases = []
    try:
        for case_name in ('seeded', 'stripped-control'):
            source_guard(expected)
            addon.player_data = copy.deepcopy(base)
            if case_name == 'stripped-control':
                for key in addon._COMBAT_RECOVERY_STATE_KEYS:
                    del addon.player_data[key]
            addon.current_skill = addon.UTILITY_REVIEW_ACTION_DISPLAY_NAME
            addon._SKILL_AVAILABILITY_CACHE_FINGERPRINT = None
            addon._PENDING_BANKSTANDING_NOTICE = None
            addon._PENDING_REVIEW_DIALOGS.clear()
            recorder.case, recorder.phase = case_name, 'prime'
            recorder.sink_values = None
            addon._refresh_skill_availability()
            initial = snapshot(addon)
            if initial['any_firemaking'] or recorder.sink_values is None or recorder.sink_values[3]:
                raise PreconditionFailure('Empty-inventory fixture did not start with a measured unavailable Firemaking projection')
            row = {'case': case_name, 'initial': initial, 'phases': []}
            cases.append(row)
            write_json(out / 'cases.json', cases)
            for phase in ('nurture', 'prepare', 'fell'):
                before_sources = source_guard(expected)
                recorder.phase = phase
                before = snapshot(addon)
                event_start = len(recorder.events)
                addon.player_data['shop_market_clock']['answered_cards'] += 1
                addon.exp_awarded = False
                addon.on_good_answer(defer_commit=True)
                after = snapshot(addon)
                expected_before = None if phase == 'nurture' else phase
                expected_after = {'nurture': 'prepare', 'prepare': 'fell', 'fell': None}[phase]
                if before['evil_phase'] != expected_before or after['evil_phase'] != expected_after:
                    raise PreconditionFailure('The real review did not traverse the declared Evil Tree phase')
                events = recorder.events[event_start:]
                phase_row = {'phase': phase, 'before': before, 'after': after,
                             'last_emitted_values': copy.deepcopy(recorder.sink_values),
                             'trace_start': event_start, 'trace_end': len(recorder.events),
                             'source_hashes_before': before_sources, 'source_hashes_after': source_guard(expected)}
                row['phases'].append(phase_row)
                write_json(out / 'cases.json', cases)
                returns = [event for event in events if event['function'] == 'evil_tree_handler' and event['event'] == 'return']
                if len(returns) != 1 or returns[0].get('result') is not True:
                    raise PreconditionFailure('The real dispatcher did not accept exactly one Evil Tree phase')
                if any(event['event'] == 'caught_exception' for event in events):
                    raise RuntimeError('Availability refresh caught an exception; inspect the complete trace')
            final = snapshot(addon)
            if (final['current_utility'] != 'bankstanding' or final['evil_event'] or final['evil_phase'] is not None
                    or final['ordinary_logs'] <= 0 or final['firemaking_exp'] <= initial['firemaking_exp']):
                raise PreconditionFailure('The real visit did not complete with the declared logs and XP')
            if not final['any_firemaking'] or final['ordinary_logs_reasons']:
                raise PreconditionFailure('Ordinary Firemaking remains unavailable after the real reward: ' + repr(final['ordinary_logs_reasons']))
            row['fresh_projection_matches'] = recorder.sink_values[3] == final['any_firemaking']
            row['fingerprint_matches'] = final['cached_fingerprint'] == final['fresh_fingerprint']
            if case_name == 'seeded':
                if not row['fresh_projection_matches']:
                    row['classification'] = 'SEEDED_REGRESSION_REPRODUCED'
                elif not row['fingerprint_matches']:
                    row['classification'] = 'SEEDED_INTERNAL_STATE_OBSERVATION'
                else:
                    fell = row['phases'][-1]
                    projections = [event for event in recorder.events[fell['trace_start']:fell['trace_end']]
                                   if event['function'] == 'ui_projection' and event['event'] == 'call']
                    row['refresh_call_chains'] = [event['call_chain'] for event in projections]
                    row['classification'] = ('SEEDED_INDIRECT_REFRESH_CORRECT'
                        if any('recovery_wrapper' in event['call_chain'] for event in projections)
                        else 'SEEDED_PROJECTION_CORRECT_OTHER_ROUTE')
                for phase in row['phases']:
                    events = recorder.events[phase['trace_start']:phase['trace_end']]
                    recoveries = [event for event in events if event['function'] == 'recovery_pure' and event['event'] == 'return']
                    if len(recoveries) != 1 or not recoveries[0]['changed'] or recoveries[0]['rest_after'] != recoveries[0]['rest_before'] + 1:
                        raise PreconditionFailure('The seeded review did not traverse the expected changing recovery path')
            else:
                recorder.phase = 'explicit-refresh-control'
                before = snapshot(addon)
                addon._refresh_skill_availability()
                after = snapshot(addon)
                row['explicit_refresh'] = {'before': before, 'after': after, 'emitted_values': recorder.sink_values}
                if recorder.sink_values[3] != after['any_firemaking'] or after['cached_fingerprint'] != after['fresh_fingerprint']:
                    raise RuntimeError('The real explicit refresh did not repair the disposable control')
                entries = [event for event in recorder.events if event['case'] == case_name
                           and event['function'] == 'recovery_wrapper' and event['event'] == 'call']
                row['recovery_entry_keys'] = [event['state']['recovery_keys_present'] for event in entries]
                if row['fresh_projection_matches'] and row['fingerprint_matches']:
                    row['classification'] = 'CONTROL_INDIRECT_ROUTE_REMAINED'
                elif len(entries) == 3 and all(not event['state']['recovery_keys_present'] for event in entries):
                    row['classification'] = 'CONTROL_STALE_WITH_OMITTED_RECOVERY_STATE'
                else:
                    raise PreconditionFailure('The stripped control did not isolate absent recovery inputs; inspect its trace')
            write_json(out / 'cases.json', cases)
        return cases
    finally:
        addon.random.random = original_random


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-hash-canary', action='store_true')
    args = parser.parse_args()
    out = Path(tempfile.mkdtemp(prefix='evil-tree-refresh-', dir=REPORTS))
    print(out, flush=True)
    terminal_stdout, terminal_stderr = os.dup(1), os.dup(2)
    stdout = (out / 'runtime.stdout').open('xb')
    stderr = (out / 'runtime.stderr').open('xb')
    os.dup2(stdout.fileno(), 1)
    os.dup2(stderr.fileno(), 2)
    expected, errors, recorder, cases = {}, [], None, []
    callbacks_started = False
    status = 'PASS'
    try:
        if sha(BINDINGS) != BINDINGS_SHA256:
            raise PreconditionFailure('Frozen probe bindings differ')
        bindings = json.loads(BINDINGS.read_text())
        expected = bindings['source_hashes']
        write_json(out / 'source-hashes.json', source_guard(expected))
        write_json(out / 'capture.json', {'bindings_sha256': BINDINGS_SHA256, 'probe_sha256': sha(Path(__file__)),
                                        'interpreter': sys.executable, 'interpreter_sha256': sha(Path(sys.executable)),
                                        'python': sys.version, 'started_utc': datetime.now(timezone.utc).isoformat(),
                                        'baseline_commit': bindings['base_commit'], 'argv': sys.argv})
        if args.source_hash_canary:
            source_guard(dict(expected, **{'pkg_alias.py': '0' * 64}))
            raise RuntimeError('Source canary failed to stop')
        addon, app, window = load_runtime()
        recorder = Recorder(addon, out)
        recorder.start()
        callbacks_started = True
        cases = run_cases(addon, recorder, expected, out)
        if any(event['event'] == 'caught_exception' for event in recorder.events):
            raise RuntimeError('Availability refresh caught an exception')
        write_json(out / 'collection-boundary.json', {'kind': 'process-local in-memory collection', 'writes': window.col.writes})
        if cases[0]['classification'] == 'SEEDED_REGRESSION_REPRODUCED':
            status = 'REGRESSION_REPRODUCED'
        elif cases[0]['classification'] == 'SEEDED_INTERNAL_STATE_OBSERVATION':
            status = 'INTERNAL_STATE_OBSERVATION'
        source_guard(expected)
    except PreconditionFailure as error:
        status = 'PRECONDITION_FAILED'
        errors.append(str(error))
    except Exception as error:
        status = 'FAIL'
        errors.append(repr(error))
        traceback.print_exc()
    finally:
        if recorder is not None:
            recorder.stop()
        sys.stdout.flush()
        sys.stderr.flush()
        os.dup2(terminal_stdout, 1)
        os.dup2(terminal_stderr, 2)
        os.close(terminal_stdout)
        os.close(terminal_stderr)
        stdout.close()
        stderr.close()
        write_json(out / 'source-hashes-after.json', {name: sha(ROOT / name) for name in expected})
        if expected and {name: sha(ROOT / name) for name in expected} != expected:
            status = 'FAIL'
            errors.append('Source files changed during probe')
        if (out / 'cases.json').exists():
            cases = json.loads((out / 'cases.json').read_text())
        verdict = {'status': status, 'errors': errors, 'runtime_callbacks_started': callbacks_started,
                   'completed_cases': sum('classification' in case for case in cases),
                   'classifications': [case.get('classification', 'INCOMPLETE') for case in cases],
                   'source_hash_canary': args.source_hash_canary}
        write_json(out / 'verification.json', verdict)
        write_json(out / 'manifest.json', {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(out.iterdir()) if p.is_file()})
        print(json.dumps(verdict), flush=True)
    return 0 if status == 'PASS' else (2 if status == 'PRECONDITION_FAILED' else 1)


if __name__ == '__main__':
    raise SystemExit(main())
