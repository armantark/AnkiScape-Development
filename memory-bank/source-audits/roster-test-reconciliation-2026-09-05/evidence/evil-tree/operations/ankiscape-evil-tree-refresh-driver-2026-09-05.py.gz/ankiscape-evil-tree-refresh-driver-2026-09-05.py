#!/usr/bin/env python3
"""Run the reviewed Evil Tree probe against the exact archived source."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

CANONICAL = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
BINDINGS = Path('/tmp/ankiscape-evil-tree-refresh-bindings-2026-09-05.json')
PROBE = Path('/tmp/ankiscape-evil-tree-refresh-probe-2026-09-05.py')
UPLOADS = {'/tmp/ankiscape-evil-tree-refresh-bindings-2026-09-05.json': 'fcd57b6f4d04bfe6ea36f64dab94c98ce62b1413455467ced8fdef0af3a18351', '/tmp/ankiscape-evil-tree-refresh-probe-2026-09-05.py': '54db103b725f8fa92e724dc57f2fde697f948b8db52f922df10cc6627be249a1'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

def write_json(path, value):
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def verify_local(bindings, source, expected, phase):
    if {name: sha(source / name) for name in expected} != expected:
        raise RuntimeError('Frozen source bindings changed; no next remote command launched')
    parents = {Path(name).parts[0] for name in expected if name.endswith('.py') and '/' in name}
    actual = {str(p.relative_to(source)) for parent in parents for p in (source / parent).rglob('*.py')}
    actual.update(p.name for p in source.glob('*.py'))
    if actual != {name for name, digest in expected.items() if digest is not None and name.endswith('.py')}:
        raise RuntimeError('Python source inventory changed; no next remote command launched')
    if {name: sha(Path(name)) for name in UPLOADS} != UPLOADS:
        raise RuntimeError('Reviewed capture upload changed')
    if sha(CANONICAL / 'tools/run_remote_tests.py') != bindings['runner_sha256']:
        raise RuntimeError('Canonical runner changed')
    if phase != 'baseline':
        commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
        if commit != bindings['base_commit']:
            raise RuntimeError('Frozen candidate HEAD changed')

def verify_archive(bindings):
    manifest_path = Path(bindings['baseline_manifest_path'])
    if sha(manifest_path) != bindings['baseline_manifest_sha256']:
        raise RuntimeError('Reviewed baseline archive manifest changed')
    manifest = json.loads(manifest_path.read_text())
    source = Path(bindings['baseline_root'])
    if manifest['commit'] != bindings['base_commit'] or manifest['source'] != str(source) or manifest['status'] != 'PASS_EXACT_GIT_ARCHIVE':
        raise RuntimeError('Baseline archive identity changed')
    wanted = {row['path']: row['sha256'] for row in manifest['files']}
    actual = {str(p.relative_to(source)): sha(p) for p in source.rglob('*') if p.is_file()}
    if actual != wanted:
        raise RuntimeError('Complete baseline archive inventory or bytes changed')

def local_canary(bindings, source, expected, phase):
    wrong = dict(expected, **{'pkg_alias.py': '0' * 64})
    try:
        verify_local(bindings, source, wrong, phase)
    except RuntimeError as error:
        if str(error) != 'Frozen source bindings changed; no next remote command launched':
            raise
        verify_local(bindings, source, expected, phase)
        return {'status': 'PASS', 'remote_commands_launched': 0, 'runner_imported': False,
                'message': str(error), 'source_unchanged': True}
    raise RuntimeError('Local source canary failed to stop')

def receive_report(runner, output, destination):
    report = Path(output.splitlines()[0])
    if report.parent != runner.REMOTE_ROOT / 'reports' or not report.name.startswith('evil-tree-refresh-'):
        raise RuntimeError('Unexpected report path: ' + str(report))
    destination.mkdir()
    runner._run_with_retries(('rsync', '-a', '-e', runner.RSYNC_SSH,
                             f'{runner.HOST}:{report}/', str(destination) + '/'), label='retain complete roster capture evidence')
    records = json.loads((destination / 'manifest.json').read_text())
    if {p.name for p in destination.iterdir() if p.is_file()} != set(records) | {'manifest.json'}:
        raise RuntimeError('Retained report inventory differs')
    if any(sha(destination / name) != row['sha256'] or (destination / name).stat().st_size != row['bytes'] for name, row in records.items()):
        raise RuntimeError('Retained report stream binding differs')
    return report, json.loads((destination / 'verification.json').read_text()), sha(destination / 'manifest.json')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-hash-canary', action='store_true')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if sha(BINDINGS) != UPLOADS[str(BINDINGS)]:
        raise RuntimeError('Frozen bindings changed; runner not imported')
    bindings = json.loads(BINDINGS.read_text())
    source, expected = Path(bindings['baseline_root']), bindings['source_hashes']
    verify_local(bindings, source, expected, 'baseline')
    verify_archive(bindings)
    canary = local_canary(bindings, source, expected, 'baseline')
    if args.source_hash_canary:
        print(json.dumps(canary), flush=True)
        return 0
    if not args.execute:
        parser.error('Execution requires --execute after parent review and mirror allocation')
    spec = importlib.util.spec_from_file_location('evil_tree_remote_runner', CANONICAL / 'tools/run_remote_tests.py')
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    directory = Path(tempfile.mkdtemp(prefix='evil-tree-refresh-driver-', dir='/tmp'))
    summary = directory / 'capture.json'
    record = {'status': 'RUNNING', 'local_canary': canary, 'uploads': UPLOADS,
              'runner_sha256': bindings['runner_sha256'], 'driver_sha256': sha(Path(__file__))}
    write_json(summary, record)
    runner.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        with runner.LOCAL_MIRROR_LOCK_PATH.open('a+', encoding='utf-8') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            try:
                runner._reconcile_pending_run()
                runner._preflight('qt')
                verify_local(bindings, source, expected, 'baseline')
                verify_archive(bindings)
                runner._run_with_retries(('rsync', '-a', '-e', runner.RSYNC_SSH, *UPLOADS,
                                         f'{runner.HOST}:/tmp/'), label='upload reviewed Evil Tree probe')
                hashes = runner._ssh('shasum -a 256 ' + ' '.join(shlex.quote(p) for p in UPLOADS),
                                     label='Evil Tree upload verification', repeat_safe=True)
                if {line.split(maxsplit=1)[1].strip(): line.split(maxsplit=1)[0] for line in hashes.splitlines()} != UPLOADS:
                    raise RuntimeError('Uploaded Evil Tree scripts differ')
                verify_local(bindings, source, expected, 'baseline')
                runner._sync(source)
                verify_local(bindings, source, expected, 'baseline')
                environment = ['env', 'PYTHONDONTWRITEBYTECODE=1', 'ANKISCAPE_DEBUG=0', 'QT_QPA_PLATFORM=offscreen',
                               'PATH=/opt/homebrew/bin:/usr/bin:/bin',
                               'ANKISCAPE_GAME_MAIN=' + str(runner.REMOTE_GAME_MAIN),
                               'ANKISCAPE_DARKAN_WORLD_SERVER=' + str(runner.REMOTE_DARKAN)]
                command = shlex.join([*environment, str(runner.REMOTE_VENV / 'bin/python'), str(PROBE)])
                for label, suffix in [('source-canary', ' --source-hash-canary'), ('probe', '')]:
                    verify_local(bindings, source, expected, 'baseline')
                    runner._remote_lane_command = lambda lane: command + suffix
                    code, output = runner._stream_remote_run('evil-tree-refresh-' + label, timeout=600, poll_interval=5)
                    record[label] = {'exit_code': code, 'output': output}
                    write_json(summary, record)
                    verify_local(bindings, source, expected, 'baseline')
                    report, verdict, manifest_sha = receive_report(runner, output, directory / label)
                    record[label].update(report=str(report), manifest_sha256=manifest_sha, verification=verdict)
                    write_json(summary, record)
                    if label == 'source-canary':
                        if (code != 2 or verdict['status'] != 'PRECONDITION_FAILED' or verdict['runtime_callbacks_started']
                                or verdict['completed_cases'] != 0 or verdict['errors'] != [
                                    'Source hash or Python inventory mismatch; no runtime callbacks launched']
                                or (directory / label / 'trace.jsonl').exists()):
                            raise RuntimeError('Remote source canary did not stop at the intended guard')
                    elif code != 0 or verdict['status'] != 'PASS' or verdict['errors'] or verdict['completed_cases'] != 2:
                        raise RuntimeError('Evil Tree probe requires parent review: ' + json.dumps(verdict))
                verify_local(bindings, source, expected, 'baseline')
                verify_archive(bindings)
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        record['status'] = 'PASS'
    except Exception as error:
        record.update(status='FAIL', error=repr(error), pending_record_preserved=runner._pending_path().exists())
        raise
    finally:
        write_json(summary, record)
        print(str(summary), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
