# Evil Tree availability: read-only probe contract

The missing direct refresh call does not establish a bug. The production review path contains an indirect refresh through safe combat recovery. This contract specifies the measurement needed before a defect claim or product edit.

The inspected product source is commit `814b4d591df4525e0bda4a1f858baf6345ed4d38`. All references below are relative to `/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/4/ankiscape_fork`. The adjacent source evidence records bind exact bytes and line ranges. No project import, runtime call, remote operation, or probe execution occurred.

## Confirmed source path

1. `__init__.py:5572-5574` resolves the active review handler. `runtime/runtime_actions_utility.py:579-583` dispatches Evil Tree to its real handler.
2. `runtime/runtime_actions_carried_overlay.py:166-188` calls the Utility handler without a processing overlay. The fixture must contain no requested bank run.
3. `runtime/runtime_actions_activities_distractions.py:74-132` applies the pure phase, updates the live player dictionary, checks levels and achievements, and invokes the save callback. Its completion path uses the shared Bankstanding transition at line 157.
4. The root level callback at `__init__.py:666-668` invokes `core/logic.py:32-58`. That code updates levels and optionally opens the dialog at `ui/ui.py:4513-4547`. Neither implementation refreshes availability.
5. Bankstanding dispatch uses `runtime/runtime_actions_shared.py:406-421` and `__init__.py:1576-1629`. Its menu-visibility function at `ui/ui.py:4691-4693` is a no-op.
6. The root dispatcher then reaches `__init__.py:5690-5691` for a successful Utility review. It calls the real safe-recovery wrapper at `__init__.py:5587-5600`.
7. That wrapper checks six combat-state keys. If recovery changes the dictionary, it calls `_refresh_skill_availability` at line 5596.
8. `logic_pure/logic_pure_combat_engine.py:823-889` performs that recovery. Line 859 increments `combat_rest_reviews` regardless of current health. Thus full health does not imply an unchanged recovery result.
9. New saves seed combat state at `core/storage_pure.py:657-658`. The load path fills missing defaults at lines 1514-1517. The defaults include several wrapper trigger keys at `logic_pure/logic_pure_combat_model.py:600-604`.
10. The root refresh at `__init__.py:863-935` compares its fingerprint, computes seven availability values, calls the UI sink, and stores the new fingerprint. Its exception handler suppresses errors, so a call count alone cannot prove success.

The fingerprint tracks relevant materials and levels. It does not claim to cache Evil Tree's phase or world-event view. Felling adds ordinary logs and Firemaking XP at `logic/evil_tree_logic.py:467-527`, which can affect the Firemaking availability value.

The main menu also computes availability directly from current data at `ui/ui.py:5080-5115` and `ui/ui.py:5193-5218`. Card construction uses that value at `ui/ui.py:22909-22918`. The menu runs with `dialog.exec()` at line 28743. A stale internal fingerprint alone does not establish a visible menu defect.

## Questions for the probe

| Candidate explanation | Distinguishing prediction |
| --- | --- |
| The production path refreshes indirectly. | A seeded save enters safe recovery, changes its rest counter, and emits current availability after felling. |
| A minimal fixture omits the indirect route. | Removing the six wrapper trigger keys prevents recovery and leaves the prior availability value until an explicit refresh. |
| The route runs but fails to refresh correctly. | Recovery and refresh calls occur, but the emitted value or stored fingerprint disagrees with current player data. |

These are measurement questions, not confirmed runtime findings. No red-capable command has run. The diagnosing-bugs skill remains at feedback-loop design.

## Smallest disposable probe

Use one fresh MacBook Python process with the offscreen Qt environment and a frozen copy of main814. Load the real root package with native dependencies. Use a process-local Anki collection fake for configuration and persistence. Do not open or mutate a real collection.

Preserve the actual handler resolver, runtime context, Evil Tree logic, level checks, achievement checks, recovery wrapper, recovery implementation, availability computation, feedback completion, and world-clock callbacks. Use the production `on_good_answer` entry point with `defer_commit=True`. Do not invoke only the Evil Tree leaf handler.

Suppress blocking dialog presentation at the final dialog boundary and record each call. Do not replace level checks or the recovery function with no-ops. Observe refresh calls with wrappers that invoke the original functions. Record the UI sink's seven arguments before invoking its original implementation.

Build a player through `default_player_data` and retain its normal combat defaults. Clear the inventory, keep the real default Bronze hatchet, and select Evil Tree through the exported review-action name. Use the real world-clock function to spawn the normal tree with deterministic zero rolls. Set the shared answered-card clock consistently for each accepted review. Use one action tick per answer and no Farming queue or bank-run request.

The fixture starts at Firemaking level 1 with zero Firemaking XP. The real three-phase visit supplies the XP and logs. Do not patch the XP table or reward function. Assert that ordinary Firemaking is unavailable before the visit and becomes available from the actual felling rewards. Record the measured level transition instead of predicting a hardcoded final level.

Run two cases from independent copies:

1. **Seeded save.** Keep all default combat state and full health. Prime the real availability cache. Perform Nurture, Prepare, and Fell through `on_good_answer`, resetting its normal per-answer flag between reviews. Preserve every real post-handler callback.
2. **Explicit nonproduction control.** Remove exactly the six keys in `_COMBAT_RECOVERY_STATE_KEYS` from the same initial fixture. Perform the same phases. Record key presence at recovery entry. If another real callback restores a key, report that fact; do not patch the callback to force the expected outcome.

After the control, call the real refresh once and record the repaired projection. This is a detector check on disposable state. It is not a proposed product fix.

## Required observations

For each phase and case, retain:

- The root handler key, selected Utility, handler result, and Evil Tree phase before and after the answer.
- The relevant inventory counts, Firemaking XP and level, and the directly computed Firemaking gate reasons for ordinary logs.
- The recovery trigger-key presence at wrapper entry, `combat_rest_reviews` before and after recovery, and the recovery dictionary equality result.
- The ordered call trace for level checks, recovery, refresh, UI projection, feedback completion, and the world-clock callback.
- The cached fingerprint before and after, plus the freshly computed fingerprint after the answer.
- Every emitted seven-value availability tuple, its Firemaking value, and the independent pure availability result.
- Any raised or suppressed exception observed at the refresh boundary.

Bind the source inventory, probe bytes, interpreter, complete stdout/stderr, and exit code. Preserve sources before and after the job. Reuse the canonical mirror lock, preflight, pending-run reconciliation, retry, and single-launch rules when the parent authorizes execution.

## Verdict rules

A seeded-save PASS requires accepted phases, a completed real visit, the expected material gate change, and an emitted post-felling value equal to current pure availability. Its cached fingerprint must match the current fingerprint. The trace must show where the refresh occurred.

If the seeded case passes and the stripped control fails only when its trigger keys remain absent, classify the earlier suspicion as a fixture omission. Do not file a production refresh defect.

If the seeded case has a stale projection despite a changed material gate, the probe has reproduced a candidate regression. Use the trace to distinguish a missing callback from a refresh that failed or reused an incorrect fingerprint. Do not change code in this measurement task.

A cache mismatch without a wrong observable projection remains an internal-state observation. If it survives the seeded case, a separate minimal real-menu check must compare a freshly constructed Firemaking button with the pure gate before a visible-defect claim. The existing widget harness at `tests/test_main_menu_widget.py:693-703` provides a safe dialog subclass; never monkey-patch a PyQt method descriptor.

The parent must review this contract before probe authoring. The parent retains exclusive ownership of the MacBook runtime.
