from pathlib import Path
import gzip,hashlib,json,struct,subprocess
ROOT=Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/4/ankiscape_fork')
AUDIT=ROOT/'memory-bank/source-audits/roster-test-reconciliation-2026-09-05'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
def read(p):return json.loads(p.read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
b=read(Path('/tmp/ankiscape-roster-capture-bindings-2026-09-05.json'));expected=dict(b['source_hashes']['measure']);expected['tests/test_module_surface.py']='058e6eed749ee8a9eb9052e9d3e6dd18fdac2a14e5595bcc18c93bfa1dfa5193'
assert {n:sha(ROOT/n) for n in expected}==expected
records={'roster':[],'evil-tree':[]}
def retain(kind,source,rel):
 raw=source.read_bytes();stored=gzip.compress(raw,compresslevel=9,mtime=0);target=AUDIT/'evidence'/kind/(rel+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==stored
 else:target.write_bytes(stored)
 assert gzip.decompress(target.read_bytes())==raw and struct.unpack('<I',stored[4:8])[0]==0
 records[kind].append({'source_path':str(source),'raw_path':rel,'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'stored_path':str(target.relative_to(AUDIT)),'stored_bytes':len(stored),'stored_sha256':sha(target),'encoding':'gzip','mtime':0})
def retain_tree(kind,source,prefix):
 for p in sorted(source.rglob('*')):
  if p.is_file():retain(kind,p,prefix+'/'+str(p.relative_to(source)))
def verify_report(root,key,driver):
 d=root/key;manifest=read(d/'manifest.json');assert sha(d/'manifest.json')==driver[key]['manifest_sha256']
 assert {str(p.relative_to(d)) for p in d.rglob('*') if p.is_file()}==set(manifest)|{'manifest.json'}
 for name,row in manifest.items():assert sha(d/name)==row['sha256'] and (d/name).stat().st_size==row['bytes']
 assert read(d/'verification.json')==driver[key]['verification']
for phase,name,count in [('baseline','roster-driver-baseline-yuazg3om',4),('measure','roster-driver-measure-qv1xwmzd',64),('final','roster-driver-final-4ex35s0k',16)]:
 root=Path('/tmp')/name;driver=read(root/'capture.json');assert driver['status']=='PASS'
 for key in ['source-canary','capture']:verify_report(root,key,driver)
 assert driver['source-canary']['exit_code']==2 and driver['source-canary']['verification']['subprocess_count']==0
 assert driver['capture']['exit_code']==0 and driver['capture']['verification']['subprocess_count']==count
 retain_tree('roster',root,'reports/'+phase)
root=Path('/tmp/evil-tree-refresh-driver-mbowc_gn');driver=read(root/'capture.json');assert driver['status']=='PASS'
for key in ['source-canary','probe']:verify_report(root,key,driver)
assert driver['source-canary']['exit_code']==2 and driver['source-canary']['verification']['runtime_callbacks_started'] is False
assert driver['probe']['verification']['classifications']==['SEEDED_INDIRECT_REFRESH_CORRECT','CONTROL_STALE_WITH_OMITTED_RECOVERY_STATE']
retain_tree('evil-tree',root,'reports')
for kind,manifestname,expectedsha in [('roster','ankiscape-roster-operational-manifest-2026-09-05.json','2b8d0b728c7067ae6ef3db0033f2667b126ef71256bebec84ae902f777e02828'),('evil-tree','ankiscape-evil-tree-refresh-operational-manifest-2026-09-05.json','c4e21d7b255fb5d37c9228f26255a84b825f830447145d8fc6c4583d097c030b')]:
 p=Path('/tmp')/manifestname;assert sha(p)==expectedsha
 v=read(p);mapping=v['files'] if kind=='evil-tree' else v
 for name,row in mapping.items():assert sha(Path(name))==row['sha256'] and Path(name).stat().st_size==row['bytes'];retain(kind,Path(name),'operations/'+Path(name).name)
 retain(kind,p,'operations/'+p.name)
for name in ['ankiscape-roster-parent-pin-approval-2026-09-05.json']:
 retain('roster',Path('/tmp')/name,'operations/'+name)
for name in ['ankiscape-evil-tree-refresh-probe-contract-2026-09-05.md','ankiscape-evil-tree-refresh-source-evidence-2026-09-05.json']:
 retain('evil-tree',Path('/tmp')/name,'operations/'+name)
retain_tree('roster',Path('/tmp/ankiscape-roster-independent-review-2026-09-05'),'pre-capture-opus-review')
retain('roster',Path('/tmp/ankiscape-roster-reconciliation-opus-review-2026-09-05.txt'),'pre-capture-opus-review/raw-review.txt')
retain('roster',Path(b['baseline_root'])/'tests/test_module_surface.py','pins/before-test_module_surface.py')
retain('roster',ROOT/'tests/test_module_surface.py','pins/after-test_module_surface.py')
retain('roster',Path(b['baseline_manifest_path']),'baseline-archive/manifest.json')
for name in ['report.md','papercuts.md','manifest.json']:
 retain('roster',AUDIT/name,'author-freeze/'+name)
for kind,rows in records.items():
 write(AUDIT/'evidence'/kind/'manifest.json',{'scope':'Lossless immutable report and provenance retention; source directories are not included','files':rows})
 print(kind,'files',len(rows),'raw_bytes',sum(x['raw_bytes'] for x in rows),'stored_bytes',sum(x['stored_bytes'] for x in rows),'manifest_sha256',sha(AUDIT/'evidence'/kind/'manifest.json'))
assert {n:sha(ROOT/n) for n in expected}==expected
write(Path('/tmp/roster-retention-source-freeze-2026-09-05.json'),{'status':'PASS','source_hashes_before_and_after':expected,'measuring_sha256':expected['tests/test_module_surface.py']})
