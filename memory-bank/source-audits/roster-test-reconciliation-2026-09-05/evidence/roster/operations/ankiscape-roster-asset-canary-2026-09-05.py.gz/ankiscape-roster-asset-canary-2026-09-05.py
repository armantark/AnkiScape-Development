#!/usr/bin/env python3
"""Exercise the unchanged asset test against disposable baseline fixtures."""
import argparse
import importlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest


class Result(unittest.TestResult):
    def __init__(self):
        super().__init__()
        self.subtests = []

    def addSubTest(self, test, subtest, error):
        self.subtests.append({
            'target': subtest.params['target'],
            'exception_type': None if error is None else error[0].__name__,
            'message': None if error is None else str(error[1]),
            'assertion': error is not None and issubclass(error[0], test.failureException),
        })
        super().addSubTest(test, subtest, error)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('bindings', type=Path)
    parser.add_argument('case')
    args = parser.parse_args()
    binding = json.loads(args.bindings.read_text())
    pairs, pins = binding['asset_pairs'], binding['timestamp_pins']
    if len(pairs) != 47 or len(pins) != 19:
        raise ValueError('Incomplete baseline fixture contract')
    sys.path.insert(0, str(args.root))
    module = importlib.import_module('tests.combat_roster.test_roster_contract')
    original_alias = module.pkg_alias
    expected_failure = None
    with tempfile.TemporaryDirectory(prefix='roster-assets-fixture-') as directory:
        root = Path(directory)
        (root / 'combatenemies').mkdir()
        provenance = {}
        for target, title in pairs:
            relative = 'combatenemies/' + target + '.png'
            (root / relative).touch()
            provenance[relative] = {'file_title': title, 'timestamp': pins.get(target, '2010-01-01T00:00:00Z')}
        case = args.case
        if case == 'positive':
            pass
        elif case in ('missing-image', 'missing-provenance', 'wrong-title'):
            expected_failure = 'jackal'
            relative = 'combatenemies/jackal.png'
            if case == 'missing-image':
                (root / relative).unlink()
            elif case == 'missing-provenance':
                del provenance[relative]
            else:
                provenance[relative]['file_title'] = 'Deliberately wrong title.png'
        elif case.startswith('timestamp:'):
            expected_failure = case.split(':', 1)[1]
            if expected_failure not in pins:
                raise ValueError('Timestamp target is not a baseline pin')
            provenance['combatenemies/' + expected_failure + '.png']['timestamp'] = '1900-01-01T00:00:00Z'
        elif case == 'steel-at-cutoff':
            expected_failure = 'steel_dragon'
            provenance['combatenemies/steel_dragon.png']['timestamp'] = binding['steel_cutoff']
        elif case == 'steel-before-cutoff':
            provenance['combatenemies/steel_dragon.png']['timestamp'] = '2012-11-19T23:59:59Z'
        else:
            raise ValueError('Unknown canary case')
        (root / 'assets_provenance.json').write_text(json.dumps(provenance))
        if root == args.root.resolve() or root == Path(module.__file__).resolve().parent:
            raise ValueError('Fixture must have an independent repository anchor')
        try:
            module.pkg_alias = SimpleNamespace(__file__=str(root / 'pkg_alias.py'))
            test = module.CombatEnemyRosterDataTest('test_new_slayer_family_assets_are_present_and_provenanced')
            result = Result()
            test.run(result)
        finally:
            module.pkg_alias = original_alias
        failures = [row for row in result.subtests if row['exception_type'] is not None]
        valid = (result.testsRun == 1 and not result.errors and not result.skipped
                 and not result.expectedFailures and not result.unexpectedSuccesses
                 and [row['target'] for row in result.subtests] == [pair[0] for pair in pairs])
        if expected_failure is None:
            valid = valid and result.wasSuccessful() and not failures
        else:
            valid = (valid and len(result.failures) == 1 and len(failures) == 1
                     and failures[0]['target'] == expected_failure and failures[0]['assertion'])
        record = {'status': 'PASS' if valid else 'FAIL', 'case': case,
                  'expected_failure_target': expected_failure, 'tests_run': result.testsRun,
                  'subtests': result.subtests, 'failures': len(result.failures),
                  'errors': [(test.id(), detail) for test, detail in result.errors],
                  'fixture_root': str(root), 'real_test_file': module.__file__,
                  'alias_restored': module.pkg_alias is original_alias}
        print(json.dumps(record, sort_keys=True))
        return 0 if valid else 1


if __name__ == '__main__':
    raise SystemExit(main())
