# Roster capture review

The scripts verify the accepted roster test split on the MacBook test mirror. They do not change product files or measuring pins. No script has run. Static parsing and source comparisons are complete.

The parent owns the MacBook mirror schedule. Do not execute a phase until the parent grants that runtime slot.

## Inputs

The source bindings are in `/tmp/ankiscape-roster-capture-bindings-2026-09-05.json`. They bind 804 file paths or absences. The Python inventory contains 756 paths before phase-specific absences are removed.

The baseline is the exact Git archive at `/var/folders/rt/xd67_cfj3jg9pkgkc0jnhk300000gr/T/ankiscape-main814-baseline-nvurir2v/ankiscape_fork`. Its adjacent manifest has SHA-256 `5fb56f1ca68fc33b314ef74288cbb375916858b64eca0150226fb9befa0c4b77`. The driver verifies every archive file and the complete inventory before baseline sync. The archive needs no `.git` directory.

The candidate is `/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/4/ankiscape_fork`. The driver requires baseline commit `814b4d591df4525e0bda4a1f858baf6345ed4d38` and the frozen source bytes.

The fixture values come from the original roster test at that commit. The bindings retain all 47 image/title pairs, 19 exact timestamps, and the steel-dragon boundary.

## Phases

| Phase | Jobs | Required result |
| --- | ---: | --- |
| `baseline` | 4 | Discover every test ID and run all 36 original roster tests in both lanes. |
| `measure` | 64 | Preserve discovery, run all 36 mapped roster tests, capture five complete module payloads, and run 25 fixture cases per lane. |
| `final` | 16 | Preserve discovery, run the roster and measuring tests, and compare five complete payloads per lane with the initial measurements. |

Each phase first runs a separate remote source canary. That canary must launch zero runtime jobs and return the exact source-guard refusal. These canaries are additional transport launches, not positive jobs in the table.

The initial phase does not run the measuring tests against their obsolete roster pin. The final phase requires a separate parent approval file. The normal promotion gate owns full-suite acceptance. These scripts do not duplicate that gate.

## Execution order

1. Review the scripts and their manifest.
2. Allocate the serialized mirror to this capture.
3. Run the local source canary for the baseline phase.
4. Run the baseline phase and retain its report path and manifest hash.
5. Run the measure phase with those exact baseline report bindings.
6. Review the complete module payloads and measured digests.
7. Author the approved replacement for the single obsolete roster pin.
8. Create the final approval file with the schema below.
9. Run the final phase with the exact approval file hash.
10. Run the required normal promotion gate separately.

The baseline commands are complete:

```sh
python3 /tmp/ankiscape-roster-driver-2026-09-05.py baseline --source-hash-canary
python3 /tmp/ankiscape-roster-driver-2026-09-05.py baseline --execute
```

The `measure` phase requires `--baseline-report` and `--baseline-manifest-sha256`. Use the remote path and hash from the successful baseline driver record. The `final` phase requires the same arguments plus `--approval` and `--approval-sha256`. Every runtime invocation requires `--execute`.

The parent must populate this approval schema after measurement and pin review:

```json
{
  "status": "APPROVED_PIN_ADAPTATION",
  "bindings_sha256": "4de6b4117e0f3571b8d3db61571b9fbad16fe8937eb7f020e85cb1e0d7af0385",
  "baseline_report": "<accepted remote baseline report directory>",
  "baseline_manifest_sha256": "<accepted baseline manifest SHA-256>",
  "measurement_report": "<accepted remote measure report directory>",
  "measurement_manifest_sha256": "<accepted measurement manifest SHA-256>",
  "measuring_module_sha256": "<approved tests/test_module_surface.py SHA-256>"
}
```

The final phase accepts one changed source hash: `tests/test_module_surface.py`. Every other source byte and Python path must match the initial candidate. The scripts never write the approval file or adapt pins themselves.

## Stops and retained evidence

The driver verifies its uploads and canonical runner before it imports that runner. A deliberately wrong local hash must stop before any remote call. The runner supplies the shared lock, pending-run reconciliation, prerequisite checks, safe retries, and one-launch transport. A busy lock stops this driver. An uncertain launch retains the canonical pending record. No script clears that record manually or repeats a launch to recover output.

The capture records every job before launch. Each job retains complete stdout and stderr, stream hashes and lengths, interpreter path and hash, source hashes, command, timestamps, and exit code. Source checks run before and after every job. Each job owns a process group; a timeout kills and reaps only that group. The timeout includes any child interpreter launched by the measuring tests.

Discovery must be nonempty and contain unique IDs. Candidate discovery must equal the baseline after the exact 36-ID rename map. The order of all other IDs must remain unchanged. Roster output must contain exactly 36 named successful tests and no skips. Measuring tests permit only the existing root-initializer skip, with its exact reason, in both outer lanes. That test invokes its own plain interpreter in both lanes. The strict parser rejects extra text or a mismatched summary.

Each lane runs a positive asset fixture first. The other cases remove one image, remove one provenance entry, change one title, alter each exact timestamp, and check both sides of the steel boundary. The real test must visit all 47 targets. Each negative case must produce exactly one assertion failure at its intended target. An unrelated error is a failure. The fixture uses a temporary root through the module-local `pkg_alias` binding, then restores that binding. Real assets and provenance remain untouched.

Each report has a complete file manifest. The driver retrieves all report bytes and checks that manifest locally. The driver persists success or failure before it releases its record. Successful baseline and measurement reports become hash-bound inputs to later phases.

The runtime result remains unverified until the parent executes these scripts and reviews their terminal records.
