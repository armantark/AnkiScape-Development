#!/usr/bin/env python3
"""Run reviewed roster phases through the canonical serialized mirror runner."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

CANONICAL = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
BINDINGS = Path('/tmp/ankiscape-roster-capture-bindings-2026-09-05.json')
UPLOADS = {
    str(BINDINGS): '4de6b4117e0f3571b8d3db61571b9fbad16fe8937eb7f020e85cb1e0d7af0385',
    '/tmp/ankiscape-roster-capture-2026-09-05.py': 'bf90326a39d6f257e9d89cb97b59e750aec04baa9546a3b74fa36e4318324039',
    '/tmp/ankiscape-roster-asset-canary-2026-09-05.py': '785e966dc28173e2cfdf000c5c26965c14a3044be4c8f3b87fceca0b31db5d44',
}
HARNESS = Path('/tmp/ankiscape-roster-capture-2026-09-05.py')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def write_json(path, value):
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def verify_local(bindings, source, expected, phase):
    if {name: sha(source / name) for name in expected} != expected:
        raise RuntimeError('Frozen source bindings changed; no next remote command launched')
    parents = {Path(name).parts[0] for name in expected if name.endswith('.py') and '/' in name}
    actual = {str(p.relative_to(source)) for parent in parents for p in (source / parent).rglob('*.py')}
    actual.update(p.name for p in source.glob('*.py'))
    if actual != {name for name, digest in expected.items() if digest is not None and name.endswith('.py')}:
        raise RuntimeError('Python source inventory changed; no next remote command launched')
    if {name: sha(Path(name)) for name in UPLOADS} != UPLOADS:
        raise RuntimeError('Reviewed capture upload changed')
    if sha(CANONICAL / 'tools/run_remote_tests.py') != bindings['runner_sha256']:
        raise RuntimeError('Canonical runner changed')
    if phase != 'baseline':
        commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
        if commit != bindings['base_commit']:
            raise RuntimeError('Frozen candidate HEAD changed')


def verify_archive(bindings):
    manifest_path = Path(bindings['baseline_manifest_path'])
    if sha(manifest_path) != bindings['baseline_manifest_sha256']:
        raise RuntimeError('Reviewed baseline archive manifest changed')
    manifest = json.loads(manifest_path.read_text())
    source = Path(bindings['baseline_root'])
    if manifest['commit'] != bindings['base_commit'] or manifest['source'] != str(source) or manifest['status'] != 'PASS_EXACT_GIT_ARCHIVE':
        raise RuntimeError('Baseline archive identity changed')
    wanted = {row['path']: row['sha256'] for row in manifest['files']}
    actual = {str(p.relative_to(source)): sha(p) for p in source.rglob('*') if p.is_file()}
    if actual != wanted:
        raise RuntimeError('Complete baseline archive inventory or bytes changed')


def local_canary(bindings, source, expected, phase):
    wrong = dict(expected, **{'pkg_alias.py': '0' * 64})
    try:
        verify_local(bindings, source, wrong, phase)
    except RuntimeError as error:
        if str(error) != 'Frozen source bindings changed; no next remote command launched':
            raise
        verify_local(bindings, source, expected, phase)
        return {'status': 'PASS', 'remote_commands_launched': 0, 'runner_imported': False,
                'message': str(error), 'source_unchanged': True}
    raise RuntimeError('Local source canary failed to stop')


def receive_report(runner, output, destination, phase):
    report = Path(output.splitlines()[0])
    if report.parent != runner.REMOTE_ROOT / 'reports' or not report.name.startswith('roster-' + phase + '-'):
        raise RuntimeError('Unexpected report path: ' + str(report))
    destination.mkdir()
    runner._run_with_retries(('rsync', '-a', '-e', runner.RSYNC_SSH,
                             f'{runner.HOST}:{report}/', str(destination) + '/'), label='retain complete roster capture evidence')
    records = json.loads((destination / 'manifest.json').read_text())
    if {p.name for p in destination.iterdir() if p.is_file()} != set(records) | {'manifest.json'}:
        raise RuntimeError('Retained report inventory differs')
    if any(sha(destination / name) != row['sha256'] or (destination / name).stat().st_size != row['bytes'] for name, row in records.items()):
        raise RuntimeError('Retained report stream binding differs')
    return report, json.loads((destination / 'verification.json').read_text()), sha(destination / 'manifest.json')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('baseline', 'measure', 'final'))
    parser.add_argument('--source-hash-canary', action='store_true')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--baseline-report')
    parser.add_argument('--baseline-manifest-sha256')
    parser.add_argument('--approval', type=Path)
    parser.add_argument('--approval-sha256')
    args = parser.parse_args()
    if sha(BINDINGS) != UPLOADS[str(BINDINGS)]:
        raise RuntimeError('Frozen bindings changed; runner not imported')
    bindings = json.loads(BINDINGS.read_text())
    phase = args.phase
    source = Path(bindings['baseline_root'] if phase == 'baseline' else bindings['candidate_root'])
    expected = dict(bindings['source_hashes']['baseline' if phase == 'baseline' else 'measure'])
    capture_args = [phase]
    if phase != 'baseline':
        if not args.baseline_report or not args.baseline_manifest_sha256:
            parser.error('Candidate phases require the reviewed baseline report path and manifest hash')
        capture_args += ['--baseline-report', args.baseline_report, '--baseline-manifest-sha256', args.baseline_manifest_sha256]
    if phase == 'final':
        if args.approval is None or sha(args.approval) != args.approval_sha256:
            raise RuntimeError('Final phase requires exact parent approval bytes')
        approval = json.loads(args.approval.read_text())
        if (approval['status'] != 'APPROVED_PIN_ADAPTATION' or approval['bindings_sha256'] != UPLOADS[str(BINDINGS)]
                or approval['baseline_report'] != args.baseline_report or approval['baseline_manifest_sha256'] != args.baseline_manifest_sha256):
            raise RuntimeError('Final approval contract differs')
        expected['tests/test_module_surface.py'] = approval['measuring_module_sha256']
        capture_args += ['--approved-pin-sha256', approval['measuring_module_sha256'],
                         '--measurement-report', approval['measurement_report'],
                         '--measurement-manifest-sha256', approval['measurement_manifest_sha256']]
    verify_local(bindings, source, expected, phase)
    if phase == 'baseline':
        verify_archive(bindings)
    canary = local_canary(bindings, source, expected, phase)
    if args.source_hash_canary:
        print(json.dumps(canary), flush=True)
        return 0
    if not args.execute:
        parser.error('Execution requires --execute after parent review and mirror allocation')
    spec = importlib.util.spec_from_file_location('roster_remote_runner', CANONICAL / 'tools/run_remote_tests.py')
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    directory = Path(tempfile.mkdtemp(prefix='roster-driver-' + phase + '-', dir='/tmp'))
    summary = directory / 'capture.json'
    record = {'status': 'RUNNING', 'phase': phase, 'local_canary': canary, 'uploads': UPLOADS,
              'runner_sha256': bindings['runner_sha256'], 'driver_sha256': sha(Path(__file__))}
    write_json(summary, record)
    runner.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        with runner.LOCAL_MIRROR_LOCK_PATH.open('a+', encoding='utf-8') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            try:
                runner._reconcile_pending_run()
                runner._preflight('plain')
                runner._preflight('qt')
                verify_local(bindings, source, expected, phase)
                if phase == 'baseline':
                    verify_archive(bindings)
                runner._run_with_retries(('rsync', '-a', '-e', runner.RSYNC_SSH, *UPLOADS,
                                         f'{runner.HOST}:/tmp/'), label='upload reviewed roster scripts')
                hashes = runner._ssh('shasum -a 256 ' + ' '.join(shlex.quote(p) for p in UPLOADS),
                                     label='roster upload verification', repeat_safe=True)
                if {line.split(maxsplit=1)[1].strip(): line.split(maxsplit=1)[0] for line in hashes.splitlines()} != UPLOADS:
                    raise RuntimeError('Uploaded roster scripts differ')
                verify_local(bindings, source, expected, phase)
                runner._sync(source)
                verify_local(bindings, source, expected, phase)
                command = shlex.join(['/opt/homebrew/bin/python3', str(HARNESS), *capture_args])
                for label, suffix, expected_code in [('source-canary', ' --source-hash-canary', 2), ('capture', '', 0)]:
                    verify_local(bindings, source, expected, phase)
                    runner._remote_lane_command = lambda lane: command + suffix
                    code, output = runner._stream_remote_run('roster-' + phase + '-' + label, timeout=3600, poll_interval=5)
                    record[label] = {'exit_code': code, 'output': output}
                    write_json(summary, record)
                    verify_local(bindings, source, expected, phase)
                    if code != expected_code:
                        raise RuntimeError(label + ': unexpected terminal exit code')
                    report, verdict, manifest_sha = receive_report(runner, output, directory / label, phase)
                    if label == 'source-canary':
                        if (verdict['status'] != 'FAIL' or verdict['subprocess_count'] != 0 or verdict['check_count'] != 0
                                or verdict['errors'] != ['Source hash or Python inventory mismatch; no next job launched']
                                or (directory / label / 'results.json').exists()):
                            raise RuntimeError('Remote source canary did not stop at the intended guard')
                    elif (verdict['status'] != 'PASS' or verdict['errors'] != []
                          or verdict['subprocess_count'] != {'baseline': 4, 'measure': 64, 'final': 16}[phase]
                          or verdict['check_count'] != verdict['subprocess_count']):
                        raise RuntimeError('Roster capture did not complete its exact checks')
                    record[label].update(report=str(report), manifest_sha256=manifest_sha, verification=verdict)
                    write_json(summary, record)
                verify_local(bindings, source, expected, phase)
                if phase == 'baseline':
                    verify_archive(bindings)
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        record['status'] = 'PASS'
    except Exception as error:
        record.update(status='FAIL', error=repr(error), pending_record_preserved=runner._pending_path().exists())
        raise
    finally:
        write_json(summary, record)
        print(str(summary), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
