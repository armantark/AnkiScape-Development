#!/usr/bin/env python3
"""Read frozen roster sources and retain every runtime stream on the MBP mirror."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
REPORTS = ROOT.parent / 'reports'
BINDINGS_PATH = Path('/tmp/ankiscape-roster-capture-bindings-2026-09-05.json')
BINDINGS_SHA256 = '4de6b4117e0f3571b8d3db61571b9fbad16fe8937eb7f020e85cb1e0d7af0385'
CANARY_PATH = Path('/tmp/ankiscape-roster-asset-canary-2026-09-05.py')
CANARY_SHA256 = '785e966dc28173e2cfdf000c5c26965c14a3044be4c8f3b87fceca0b31db5d44'
OPTIONAL_SKIP_ID = 'test_module_surface.ModuleSurfaceTest.test_root_initializer_is_reported_as_unavailable_without_aqt'
OPTIONAL_SKIP_STATUS = "skipped 'root initializer requires aqt; use the offscreen Qt interpreter'"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

def write_json(path, value):
    pending = path.with_suffix(path.suffix + '.tmp')
    pending.write_text(json.dumps(value, indent=2) + '\n')
    pending.replace(path)

def payload(path):
    raw = path.read_bytes()
    body, footer = raw.rsplit(b'MODULE_SURFACE_SHA256: ', 1)
    digest = hashlib.sha256(body).hexdigest()
    if not body.startswith(b'MODULE_SURFACE module=') or footer != (digest + '\n').encode():
        raise ValueError('Incomplete public payload: ' + str(path))
    return {'bytes': len(raw), 'file_sha256': hashlib.sha256(raw).hexdigest(), 'body_sha256': digest}

def environment(lane):
    env = dict(os.environ, PATH='/opt/homebrew/bin:/usr/bin:/bin', QT_QPA_PLATFORM='offscreen',
               ANKISCAPE_GAME_MAIN=str(ROOT.parent / 'sources/game-main'),
               ANKISCAPE_DARKAN_WORLD_SERVER=str(ROOT.parent / 'sources/darkan-world-server'))
    env.pop('PYTHONPATH', None)
    if lane == 'plain':
        env['PYTHONPATH'] = str(ROOT.parent / 'plain-site')
    return env

def passing_tests(text, expected_ids):
    outcomes, cursor, skips = [], 0, 0
    pattern = r'^(test_\S+) \(([^\n]+)\)(?:\n([^\n]*))? \.\.\. (.+)$'
    for match in re.finditer(pattern, text, re.MULTILINE):
        method, test_id, description, status = match.groups()
        if text[cursor:match.start()].strip() or method != test_id.rsplit('.', 1)[-1]:
            raise ValueError('Unexpected test output or mismatched named ID')
        if status != 'ok':
            if not (test_id == OPTIONAL_SKIP_ID and status == OPTIONAL_SKIP_STATUS):
                raise ValueError('Non-passing named test: ' + test_id + ': ' + status)
            skips += 1
        outcomes.append({'id': test_id, 'status': status, 'description': description})
        cursor = match.end()
    ids = [row['id'] for row in outcomes]
    if Counter(ids) != Counter(expected_ids) or len(set(ids)) != len(ids):
        raise ValueError('Executed tests differ from the complete named selection')
    ending = 'OK' + (f' (skipped={skips})' if skips else '')
    summary = re.fullmatch(r'\n\n-{70}\nRan (\d+) tests? in ([0-9]+\.[0-9]+)s\n\n' + re.escape(ending) + r'\n', text[cursor:])
    if summary is None or int(summary.group(1)) != len(expected_ids):
        raise ValueError('Missing exact count and successful summary, or unexpected trailing output')
    return {'status': 'PASS', 'count': len(ids), 'skips': skips,
            'seconds': summary.group(2), 'outcomes': outcomes}


def source_hashes(expected):
    return {name: sha(ROOT / name) for name in expected}


def source_guard(expected):
    actual = source_hashes(expected)
    parents = {Path(name).parts[0] for name in expected if name.endswith('.py') and '/' in name}
    inventory = {str(p.relative_to(ROOT)) for parent in parents for p in (ROOT / parent).rglob('*.py')}
    inventory.update(p.name for p in ROOT.glob('*.py'))
    wanted = {name for name, digest in expected.items() if digest is not None and name.endswith('.py')}
    if actual != expected or inventory != wanted:
        raise ValueError('Source hash or Python inventory mismatch; no next job launched')
    return actual


def capture(out, results, expected, lane, mode, arguments):
    name = lane + '-' + mode
    row = {'lane': lane, 'mode': mode, 'status': 'blocked-before-launch', 'launched': False,
           'argv': [('/opt/homebrew/bin/python3' if lane == 'plain' else str(ROOT.parent / '.venv-qt/bin/python')), *arguments],
           'cwd': str(ROOT), 'exit_code': None, 'stdout': name + '.stdout', 'stderr': name + '.stderr'}
    row['interpreter_path'] = str(Path(row['argv'][0]).resolve())
    row['interpreter_sha256'] = sha(Path(row['argv'][0]))
    results.append(row)
    write_json(out / 'results.json', results)
    row['source_hashes_before'] = source_hashes(expected)
    write_json(out / 'results.json', results)
    source_guard(expected)
    row.update(status='running', launched=True, started_utc=datetime.now(timezone.utc).isoformat())
    write_json(out / 'results.json', results)
    try:
        with (out / row['stdout']).open('xb') as stdout, (out / row['stderr']).open('xb') as stderr:
            child = subprocess.Popen(row['argv'], cwd=ROOT, env=environment(lane), stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                row['exit_code'] = child.wait(timeout=300)
                row['status'] = 'finished'
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
                row.update(status='timeout', exit_code=child.returncode)
    except OSError as error:
        row.update(status='error', error=repr(error))
    finally:
        row['finished_utc'] = datetime.now(timezone.utc).isoformat()
        row['source_hashes_after'] = source_hashes(expected)
        for stream in ('stdout', 'stderr'):
            path = out / row[stream]
            row[stream + '_sha256'] = sha(path)
            row[stream + '_bytes'] = path.stat().st_size if path.exists() else None
        write_json(out / 'results.json', results)
    source_guard(expected)
    if row['status'] != 'finished' or row['exit_code'] != 0:
        raise ValueError(name + ': job did not finish successfully')
    print(name, row['status'], flush=True)
    return row


def prior_report(path, digest, phase):
    path = Path(path)
    if path.parent != REPORTS or not path.name.startswith('roster-' + phase + '-'):
        raise ValueError('Unexpected prior report path')
    manifest = path / 'manifest.json'
    if sha(manifest) != digest:
        raise ValueError('Prior report manifest binding differs')
    records = json.loads(manifest.read_text())
    if {p.name for p in path.iterdir() if p.is_file()} != set(records) | {'manifest.json'}:
        raise ValueError('Prior report inventory differs')
    if any(sha(path / name) != item['sha256'] or (path / name).stat().st_size != item['bytes'] for name, item in records.items()):
        raise ValueError('Prior report payload binding differs')
    verdict = json.loads((path / 'verification.json').read_text())
    metadata = json.loads((path / 'capture.json').read_text())
    if verdict['status'] != 'PASS' or verdict['phase'] != phase or metadata['bindings_sha256'] != BINDINGS_SHA256:
        raise ValueError('Prior report is not accepted source-bound evidence')
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('baseline', 'measure', 'final'))
    parser.add_argument('--source-hash-canary', action='store_true')
    parser.add_argument('--baseline-report')
    parser.add_argument('--baseline-manifest-sha256')
    parser.add_argument('--measurement-report')
    parser.add_argument('--measurement-manifest-sha256')
    parser.add_argument('--approved-pin-sha256')
    args = parser.parse_args()
    out = Path(tempfile.mkdtemp(prefix='roster-' + args.phase + '-', dir=REPORTS))
    print(out, flush=True)
    results, checks, errors, expected = [], [], [], {}
    write_json(out / 'capture.json', {'phase': args.phase, 'bindings_sha256': BINDINGS_SHA256,
                                    'script_sha256': sha(Path(__file__)), 'canary_sha256': CANARY_SHA256,
                                    'arguments': vars(args), 'started_utc': datetime.now(timezone.utc).isoformat()})
    try:
        if sha(BINDINGS_PATH) != BINDINGS_SHA256 or sha(CANARY_PATH) != CANARY_SHA256:
            raise ValueError('Frozen capture dependency differs')
        bindings = json.loads(BINDINGS_PATH.read_text())
        expected = dict(bindings['source_hashes']['baseline' if args.phase == 'baseline' else 'measure'])
        if args.phase == 'final':
            if not re.fullmatch('[0-9a-f]{64}', args.approved_pin_sha256 or ''):
                raise ValueError('Final phase requires the parent-approved measuring-module hash')
            expected['tests/test_module_surface.py'] = args.approved_pin_sha256
        before = source_guard(expected)
        write_json(out / 'source-hashes.json', {'expected': expected, 'actual': before})
        if args.source_hash_canary:
            wrong = dict(expected, **{'pkg_alias.py': '0' * 64})
            write_json(out / 'source-hash-canary.json', {'expected_wrong': wrong['pkg_alias.py'], 'actual': before['pkg_alias.py'], 'file_mutations': []})
            source_guard(wrong)
            raise ValueError('Source canary failed to stop')
        baseline = None
        if args.phase != 'baseline':
            baseline = prior_report(args.baseline_report, args.baseline_manifest_sha256, 'baseline')
        measurement = None
        if args.phase == 'final':
            measurement = prior_report(args.measurement_report, args.measurement_manifest_sha256, 'measure')
        discoveries, surfaces = {}, {}
        for lane in ('plain', 'qt'):
            row = capture(out, results, expected, lane, 'discovery', ['run_tests.py', '--list', '--max-results', '100000'])
            ids = (out / row['stdout']).read_text().splitlines()
            if ((out / row['stderr']).read_bytes() or not ids or len(set(ids)) != len(ids)
                    or any(not re.fullmatch(r'[A-Za-z_][\w.]+' , item) or '._FailedTest.' in item for item in ids)):
                raise ValueError('Incomplete or invalid discovery: ' + lane)
            mapping = bindings['test_id_map']
            roster_ids = list(mapping if args.phase == 'baseline' else mapping.values())
            if not set(roster_ids) <= set(ids):
                raise ValueError('Roster discovery omits mapped IDs')
            if baseline is not None:
                old_ids = (baseline / (lane + '-discovery.stdout')).read_text().splitlines()
                if Counter(ids) != Counter(mapping.get(item, item) for item in old_ids):
                    raise ValueError('Discovery differs beyond the exact roster ID mapping')
                if [item for item in ids if item not in mapping.values()] != [item for item in old_ids if item not in mapping]:
                    raise ValueError('Unrelated discovery order changed')
            discoveries[lane] = ids
            write_json(out / 'discovery.json', discoveries)
            checks.append({'lane': lane, 'mode': 'discovery', 'status': 'PASS', 'count': len(ids)})
            row = capture(out, results, expected, lane, 'roster', ['run_tests.py', *roster_ids, '--verbosity', '2'])
            if (out / row['stdout']).read_bytes():
                raise ValueError('Unexpected roster stdout')
            checks.append({'lane': lane, 'mode': 'roster', **passing_tests((out / row['stderr']).read_text(), roster_ids)})
            if args.phase == 'final':
                row = capture(out, results, expected, lane, 'module-surface-tests', ['run_tests.py', 'test_module_surface.', '--verbosity', '2'])
                if (out / row['stdout']).read_bytes():
                    raise ValueError('Unexpected measuring-test stdout')
                checks.append({'lane': lane, 'mode': 'module-surface-tests', **passing_tests((out / row['stderr']).read_text(), bindings['surface_test_ids'])})
            if args.phase != 'baseline':
                for index, module in enumerate(bindings['modules']):
                    row = capture(out, results, expected, lane, 'surface-' + str(index), ['tools/module_surface.py', module])
                    measured = payload(out / row['stdout'])
                    stderr = (out / row['stderr']).read_text()
                    if not re.fullmatch(r'MODULE_SURFACE_ENV: python=\d+\.\d+\.\d+ hash_seed=0\n', stderr):
                        raise ValueError('Unexpected module surface stderr')
                    if measurement is not None and (out / row['stdout']).read_bytes() != (measurement / row['stdout']).read_bytes():
                        raise ValueError('Split module surface changed after approved pin adaptation')
                    surfaces[lane + ':' + module] = measured
                    checks.append({'lane': lane, 'mode': row['mode'], 'module': module, 'status': 'PASS', **measured})
                if args.phase == 'measure':
                    for index, case in enumerate(bindings['canary_cases']):
                        row = capture(out, results, expected, lane, 'canary-' + str(index), [str(CANARY_PATH), str(ROOT), str(BINDINGS_PATH), case])
                        result = json.loads((out / row['stdout']).read_text())
                        if (out / row['stderr']).read_bytes() or result['status'] != 'PASS' or result['case'] != case or not result['alias_restored']:
                            raise ValueError('Canary result differs from its exact case')
                        checks.append({'lane': lane, 'mode': row['mode'], 'status': 'PASS', 'case': case, 'result': result})
            write_json(out / 'checks.json', checks)
            write_json(out / 'surfaces.json', surfaces)
        expected_jobs = 4 if args.phase == 'baseline' else (64 if args.phase == 'measure' else 16)
        if len(results) != expected_jobs or len(checks) != expected_jobs:
            raise ValueError('Capture job or check count differs')
        source_guard(expected)
        if baseline is not None:
            prior_report(args.baseline_report, args.baseline_manifest_sha256, 'baseline')
        if measurement is not None:
            prior_report(args.measurement_report, args.measurement_manifest_sha256, 'measure')
    except (OSError, ValueError, TypeError, KeyError, RuntimeError) as error:
        errors.append(str(error))
    write_json(out / 'checks.json', checks)
    write_json(out / 'source-hashes-after.json', source_hashes(expected))
    verdict = {'status': 'FAIL' if errors else 'PASS', 'phase': args.phase, 'errors': errors,
               'subprocess_count': sum(row['launched'] for row in results), 'check_count': len(checks)}
    write_json(out / 'verification.json', verdict)
    write_json(out / 'manifest.json', {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(out.iterdir()) if p.is_file()})
    print(json.dumps(verdict), flush=True)
    return 2 if errors and not results else int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
