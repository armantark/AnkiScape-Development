# Review packet friction

2026-09-06T02:16:52.003839+00:00 — Copying the preserved test directory into the author review packet also copied 12 historical Python 3.13/3.14 bytecode files. Removed only those copies from the new review packet; original test-directory caches remain untouched. No project code was imported or executed.
