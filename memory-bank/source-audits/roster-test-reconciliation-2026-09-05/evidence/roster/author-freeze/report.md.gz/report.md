# Roster test split reconciliation

The candidate preserves the complete roster test contract while separating shared checks, dragon families, Slayer families and finishers. The only changed test body uses a literal timestamp table and locates the repository from `pkg_alias.__file__`; all other test methods retain their normalized ASTs.

This is an author freeze for independent review. No project imports, tests, module-surface measurements, full gate, native run or commit has occurred. The old roster entry in `tests/test_module_surface.py` intentionally remains unchanged until parent-approved runtime measurement supplies the replacement module digests. The candidate is not ready for the full gate while that entry points to the deleted file.

## Preservation and ownership

- Branch: `goal/roster-test-reconciliation-2026-09-05`.
- Baseline: `814b4d591df4525e0bda4a1f858baf6345ed4d38`.
- Parent preserved the previous dirty work in stash `1a34588b994e4fead010127412b1b84d57e4f27f`, then applied it after the branch advanced to main. The stash remains intact.
- The sole incoming conflict was `tests/test_module_surface.py`. Its full conflicted text is retained losslessly as `incoming-test-module-surface-conflict.txt.gz`. The measuring module and the historical July audit were restored byte-for-byte from the baseline in both index and worktree. No unrelated digest, assertion or historical result was changed.
- The roster deletion was already staged when ownership transferred. The author did not stage the new tests or the audit. There are no remaining unmerged paths.

## Static preservation proof

`static-preservation-proof.json` records the complete old-to-new test-ID map, source hashes and exact asset expectations. Static AST comparison proves that all 36 test methods are present once, 35 are unchanged, the shared slot helper is unchanged, and all five shared contract constants are unchanged. The changed asset test retains the ordered 47 image/title pairs, 19 exact timestamp pins and the strict steel-dragon timestamp cutoff. The two 2014 elf-image pins are preserved verbatim.

The file layout follows domain boundaries: `contract.py` owns shared data-shape checks; `test_roster_contract.py` owns roster-wide schema, assets, levels and drop checks; the other three modules own dragons, Slayer families and finishers. The empty `__init__.py` keeps the directory discoverable as a package. No forwarding copy or duplicate tests remain at the old path.

The repository anchor follows the existing alias helper's actual contract: `pkg_alias.py` lives at the repository root and derives its own `_ROOT` from its `__file__`. Using that file's parent removes dependence on the depth of the test directory. This conclusion came from reading the helper and checking filesystem paths, not importing it.

All six candidate Python files parse. Their line counts are 0, 183, 336, 186, 364 and 620 in the order recorded by the JSON evidence. Token inspection found no semicolon statement joins. No blank lines were stripped to satisfy a limit. The previous 22/41 gate refusal is historical evidence from owner section 47; current complexity must be measured by the normal gate before any pass claim.

## Pending verification

1. Independently review the complete split diff and the separate asset-test diff against main. Recheck the exact test mapping and all protected baseline hashes.
2. Under the parent's exclusive runtime ownership, measure the split modules' public surfaces in plain and Qt lanes. Only then replace the single old roster pin with measured split-module pins; keep every unrelated measuring-test byte unchanged.
3. Verify discovery preserves every mapped test ID and the baseline suite count. Run all roster tests in both lanes, then the full regression gate.
4. Exercise the real asset test against a disposable positive fixture. Mutate one image, one provenance entry, one title, one exact timestamp, and the steel-dragon cutoff separately; each must fail with the target identified. Include the two retained 2014 pins in the timestamp checks. Prove the root anchor resolves correctly from the nested module, without seeding the real asset directory or mutating real provenance.
5. Run the normal complexity gate and source-preservation checks. No skip, assertion deletion, digest invention, relaxed gate or tolerated failure is permitted.

Owner sections 44, 47 and 48 in `memory-bank/handoffs/design-to-impl-rulings-2026-08-13.md` supply the layout-independent, move-aware and domain-seam constraints. Section 47 permits this one required changed function to be simplified in the split; it does not authorize changes to the remaining moved methods.

## Evidence representation

The complete split patch, asset-test patch and incoming conflict text are stored as deterministic gzip with modification time zero. `retained-evidence.json` binds each original filename, decoded byte count and SHA-256 to the stored filename, byte count and SHA-256. Decoding reproduces the original bytes exactly. The original review packet and `/tmp/ankiscape-roster-test-reconciliation-2026-09-05.diff` remain unchanged. This representation prevents raw diff context and conflict markers in evidence from triggering whitespace or merge-marker checks; it changes no source or test bytes.
