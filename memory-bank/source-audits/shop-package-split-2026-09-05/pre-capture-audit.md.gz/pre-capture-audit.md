# Shop package split: frozen review record

Status: package layout authored; static checks pass. Independent delta review,
fresh MacBook capture, full gates, native acceptance, and a normal commit remain
pending. This pass imported no add-on code and issued no remote command.

The base remains `814b4d591df4525e0bda4a1f858baf6345ed4d38` on
`goal/shop-domain-split-2026-09-05`, in pooled worktree 5.

## Reason and scope

Normal author commit `22501` refused the flat layout because `logic` would grow
from 87 to 89 code files under a directory cap of 40. The exact hook output and
the complete flat-layout evidence remain in `shop-domain-split-2026-09-05/`.
The parent approved a coherent package, with no function-body change.

| File | Role | Functions | Lines |
| --- | --- | ---: | ---: |
| `logic/shop_logic.py` | Existing public facade, views, transactions, and rollback | 14 | 611 |
| `logic/shop/__init__.py` | Empty package initializer | 0 | 0 |
| `logic/shop/state.py` | State, migration, access, stock, history, and counters | 39 | 613 |
| `logic/shop/services.py` | Services, vendor actions, potions, and flasks | 18 | 658 |

The facade imports `.shop.state` and `.shop.services`. The parts use `...` to
reach the same external packages. Services imports `.state`. Neither part
contains a function-local import. The dependency order remains facade to
services to state, with no reverse facade import.

All 71 function bodies and constant expressions remain byte-identical to the
original source. Public metadata assignments are unchanged. Each function must
retain its implementation module's real globals; no rebinding or wrapper exists.
The two tests change only their module-import names and service-owner paths.
No existing digest pin or test ID changes. No UI or source-value change occurs.

## Static proof and retained diff

`shop-package-split-2026-09-05/package-delta-static-proof.json` proves that the
delta from the accepted flat source contains only the approved path/import
substitutions and the empty initializer. `static-author-proof.json` proves all
71 original functions, all constant expressions, public metadata, global names,
proof-writer ownership, and exact reconstruction of the original source bytes.
Both records say `PASS_STATIC_ONLY` and establish no runtime result.

The read-only proof script is
`/tmp/verify-shop-package-split-2026-09-05.py`. Its exact text is retained beside
the proof as `static-proof-script.py.txt`. It reads source and parses Python;
it imports no add-on module.

`module-ownership.json` binds the current files and function locations.
`package-delta.diff.gz` contains the complete delta from the accepted flat
snapshot. `product-and-tests.diff.gz` contains the complete product/test diff
from the original base. Both gzip files were decoded and compared with their
raw input bytes. Gzip preserves blank diff-context lines without whitespace
warnings or alteration of the evidence.

## Fresh capture contract

Flat-layout capture `9829` is historical evidence only. It proved the flat
source, not these package paths. Its raw report, scripts, canary, review, and
static proof remain preserved. Independent Opus review `97188` also applies to
the flat source. A new independent delta review and a fresh capture are required.

The new prepared files are:

```text
/tmp/ankiscape-shop-package-split-bindings-2026-09-05.json
/tmp/ankiscape-shop-package-split-capture-2026-09-05.py
/tmp/ankiscape-shop-package-split-driver-2026-09-05.py
```

Their exact copies and hashes are in `capture-plan.json` and this audit's evidence
directory. The bindings cover 38 source/test files: the two moved paths replace
their flat counterparts, and the empty initializer adds one binding. The original
24 focused IDs, five surface-test IDs, and 23 baseline payloads stay unchanged.
The baseline discovery count remains 5,567; the candidate must contain 5,568,
with only the existing boundary regression added and every old ID in order.

The capture must complete 29 commands. Each environment must pass all 24 focused
tests without skips. Each surface suite can skip only the inner plain-root test
with the exact existing reason. Each of the 23 complete public payloads must
match its original baseline bytes. Source hashes are checked before and after
every command, and the retained baseline evidence is checked at both ends.

The driver retains the approved canonical runner, mirror lock, pending-run
reconciliation, preflights, verified upload, one sync, and one canonical launch.
Only names and frozen hashes changed from the accepted driver. Neither the new
local canary nor the new remote capture has run. The parent must review the files
and transfer mirror ownership before execution. No commit retry is authorized
before the reviewed source is ready.

## Remaining verification and integration

After focused capture, complete the full shop suite, both full lanes, the normal
audits, and the promotion gate. In the parent-owned native environment, open shop
browse/details, buy and undo, and perform and undo a potion exchange. Check exact
inventory restoration and complete visible labels.

The retained-proof repair stays separate. This base keeps the proof-store mention
count at 24; that repair changes it to 25. Parent integration must retain both
the service-owner path change and the repair's count/behavior change, then verify
the composed tree. Pool15 relocation remains frozen and was not changed here.
