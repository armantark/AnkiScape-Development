import importlib.util
import io
import json
import subprocess
import sys
import tempfile
import types
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import Mock, patch

repo = Path(sys.argv[1])
sys.path.insert(0, str(repo))
from tools import worktree_guard

source = subprocess.check_output(['git', '-C', str(repo), 'show', '8898f878:tools/worktree_guard.py'], text=True)
baseline = types.ModuleType('tools.worktree_guard_prefix_baseline')
baseline.__package__ = 'tools'
exec(compile(source, 'baseline', 'exec'), baseline.__dict__)
fixed = source.replace('branch_ref = "refs/heads/" + branch.removeprefix("refs/heads/")', 'branch_ref = "refs/heads/" + branch').replace('def lease_worktree(repo: Path, branch: str, holder: Optional[str], start_point: str) -> None:\n    audit(repo)', 'def lease_worktree(repo: Path, branch: str, holder: Optional[str], start_point: str) -> None:\n    branch = branch.removeprefix("refs/heads/")\n    audit(repo)')
assert source != fixed
candidate = types.ModuleType('tools.worktree_guard_prefix_candidate')
candidate.__package__ = 'tools'
exec(compile(fixed, 'candidate', 'exec'), candidate.__dict__)

def probe(module):
    with tempfile.TemporaryDirectory() as temporary:
        canonical = Path(temporary).resolve() / 'Anki2/addons21/ankiscape_fork'
        qt = canonical / '.venv-qt/bin/python'
        qt.parent.mkdir(parents=True)
        qt.touch()
        pooled = module.pool_root(canonical) / 'slot/ankiscape_fork'
        pooled.mkdir(parents=True)
        calls = []
        def git(_repo, *args, **kwargs):
            calls.append(args)
            if args[0] == 'show-ref':
                return Mock(returncode=0 if args[-1] == 'refs/heads/goal/available' else 1)
            return Mock(returncode=0, stdout='')
        with patch.object(module, 'audit'), patch.object(module, 'canonical_and_paths', return_value=(canonical, (canonical,))), patch.object(module, '_git', side_effect=git), patch.object(module, '_treehouse', return_value=Mock(stdout=json.dumps({'path':str(pooled),'lease_id':'fixture'}))), redirect_stdout(io.StringIO()) as output:
            module.lease_worktree(canonical, 'refs/heads/goal/available', 'fixture', 'main')
        return {'git_calls':calls, 'reported_branch':json.loads(output.getvalue())['branch']}

before, after = probe(baseline), probe(candidate)
assert ('checkout', '-b', 'refs/heads/goal/available', 'main') in before['git_calls']
assert ('checkout', 'goal/available') in after['git_calls']
assert after['reported_branch'] == 'goal/available'
print(json.dumps({'baseline':before,'candidate':after,'passed':True},indent=2))
