import importlib.util
import json
import shutil
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('conditional_slop_gate', '/Users/ArmanTarkhanian1/fleet/config/git/hooks/slop_gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
paths = ('tools/audit_test_quality.py', 'tests/test_test_quality.py', 'tests/skills/test_target_level_order.py')
with tempfile.TemporaryDirectory(prefix='quality-conditional-metrics-') as temp_dir:
    candidate = Path(temp_dir)
    for rel in paths:
        (candidate / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / rel, candidate / rel)
    result = {'limits': {'ccn': gate.CCN_MAX, 'cognitive': gate.COGNITIVE_MAX, 'halstead': gate.HALSTEAD_MAX, 'lines': gate.FILE_LINES_MAX}}
    for metric, fn, cap in (
        ('ccn', gate.ccn_by_function, gate.CCN_MAX),
        ('cognitive', gate.cognitive_by_function, gate.COGNITIVE_MAX),
        ('halstead', gate.halstead_by_function, gate.HALSTEAD_MAX),
    ):
        before, after = fn(root / 'baseline'), fn(candidate)
        result[metric] = {
            'violations': gate.ratchet(after, before, cap),
            'changed': [{'path': path, 'name': name, 'before': before.get((path, name)), 'after': value} for (path, name), value in after.items() if before.get((path, name)) != value],
        }
    result['lines'] = {'before': gate.line_counts(root / 'baseline', paths), 'after': gate.line_counts(candidate, paths)}
    result['new_dead_code'] = sorted(gate.dead_code_findings(candidate) - gate.dead_code_findings(root / 'baseline'))
    result['new_layout_issues'] = gate.layout_ratchet(gate.pep8_layout_findings(candidate), gate.pep8_layout_findings(root / 'baseline'))
    (root / 'metrics.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    assert all(not result[metric]['violations'] for metric in ('ccn', 'cognitive', 'halstead'))
    assert all(count <= gate.FILE_LINES_MAX for count in result['lines']['after'].values())
    assert not result['new_dead_code'] and not result['new_layout_issues']
