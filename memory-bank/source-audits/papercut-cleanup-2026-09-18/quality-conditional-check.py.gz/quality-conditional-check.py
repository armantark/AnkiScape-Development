import ast
import difflib
import hashlib
import importlib.util
import json
import shutil
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/4/ankiscape_fork')
PATHS = ('tools/audit_test_quality.py', 'tests/test_test_quality.py', 'tests/skills/test_target_level_order.py')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


before = load('quality_conditional_before', ROOT / 'baseline/tools/audit_test_quality.py')
after = load('tools.audit_test_quality', ROOT / 'tools/audit_test_quality.py')
tests = load('quality_conditional_tests', ROOT / 'tests/test_test_quality.py')
for rel in PATHS[1:]:
    shutil.copyfile(ROOT / rel, ROOT / 'suite' / rel)
tests.ROOT = ROOT / 'suite'
regression_name = 'test_audit_follows_unique_try_imports_but_rejects_alternate_bindings'
tests.audit_test_suite = before.audit_test_suite
with (ROOT / 'before-regression.log').open('w') as log:
    regression = unittest.TextTestRunner(stream=log, verbosity=2).run(
        unittest.TestSuite([tests.TestTestQuality(regression_name)])
    )
assert len(regression.failures) == 3 and not regression.errors
review_before = load('quality_review_before', ROOT / 'review-baseline/tools/audit_test_quality.py')
tests.audit_test_suite = review_before.audit_test_suite
with (ROOT / 'review-before-regression.log').open('w') as log:
    review_regression = unittest.TextTestRunner(stream=log, verbosity=2).run(
        unittest.TestSuite([tests.TestTestQuality('test_audit_rejects_exception_aliases_and_match_captures')])
    )
assert len(review_regression.failures) == 4 and not review_regression.errors
tests.audit_test_suite = after.audit_test_suite
scan_tests = load('quality_conditional_scan_tests', ROOT / 'suite/tests/promotion/test_vacuous_source_scan_audit.py')
suite = unittest.TestSuite([
    unittest.defaultTestLoader.loadTestsFromModule(tests),
    unittest.defaultTestLoader.loadTestsFromModule(scan_tests),
])
with (ROOT / 'tooling-tests.log').open('w') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
assert result.wasSuccessful() and not result.skipped

source_tree = ast.parse((ROOT / 'tests/skills/test_target_level_order.py').read_text())
widget = next(node for node in source_tree.body if isinstance(node, ast.ClassDef) and node.name == 'TargetLevelOrderWidgetTest')
assert [ast.unparse(base) for base in widget.bases] == ['MainMenuWidgetTest']
methods = [node.name for node in widget.body if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
module_name = 'tests.skills.test_target_level_order'
resolver_before = before._TestCaseResolver(before._test_module_index(ROOT / 'suite/tests'))
resolver_after = after._TestCaseResolver(after._test_module_index(ROOT / 'suite/tests'))
recognized_before = widget.name in resolver_before.class_names(module_name)
recognized_after = widget.name in resolver_after.class_names(module_name)
assert not recognized_before and recognized_after
reports = {}
for label, module in (('before', before), ('after', after)):
    report = module.audit_test_suite(ROOT / 'suite/tests')
    reports[label] = {
        'test_files': report.test_files,
        'test_methods': report.test_methods,
        'hard_issues': [vars(issue) for issue in report.hard_issues],
        'structural_clone_groups': len(report.structural_clones),
    }
assert {issue['name'] for issue in reports['before']['hard_issues']} == {f'{widget.name}.{method}' for method in methods}
assert not reports['after']['hard_issues']
assert reports['after']['test_methods'] - reports['before']['test_methods'] == len(methods)
assert not any(name == 'pkg_alias' or name.startswith(('ankiscape', 'aqt', 'PyQt')) for name in sys.modules)

patch = ''.join(
    ''.join(difflib.unified_diff(
        (ROOT / 'baseline' / rel).read_text().splitlines(keepends=True),
        (ROOT / rel).read_text().splitlines(keepends=True),
        fromfile=f'a/{rel}', tofile=f'b/{rel}',
    )) for rel in PATHS
)
(ROOT / 'conditional-import.patch').write_text(patch)
source_hashes = json.loads((ROOT / 'source-hashes-before.json').read_text())
assert source_hashes == {rel: hashlib.sha256((SOURCE / rel).read_bytes()).hexdigest() for rel in PATHS}
evidence = {
    'tooling_tests': {'run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped)},
    'before_regression': {'failures': len(regression.failures), 'errors': len(regression.errors)},
    'review_before_regression': {'failures': len(review_regression.failures), 'errors': len(review_regression.errors)},
    'real_caller': {'bases': [ast.unparse(base) for base in widget.bases], 'methods': methods, 'before_recognized': recognized_before, 'after_recognized': recognized_after},
    'audits': reports,
    'repository_source_unchanged': True,
    'candidate_sha256': {rel: hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() for rel in PATHS},
}
(ROOT / 'evidence.json').write_text(json.dumps(evidence, indent=2))
print(json.dumps(evidence, indent=2))
