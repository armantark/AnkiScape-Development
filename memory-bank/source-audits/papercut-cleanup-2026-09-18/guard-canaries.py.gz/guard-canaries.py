"""Inert differential worktree canaries; all mutation adapters are fake."""

import fcntl
import io
import json
import os
import subprocess
import sys
import types
from contextlib import ExitStack, redirect_stdout
from dataclasses import asdict, replace
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import Mock, patch

BASELINE = "ff44ddf641abdc7b7325c97351744972e9592b4d"
REPO = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(REPO))
from tools import worktree_guard as current
from tools.promotion import locking

baseline = types.ModuleType("tools.guard_baseline")
baseline.__package__ = "tools"
source = subprocess.run(
    ["git", "-C", str(REPO), "show", f"{BASELINE}:tools/worktree_guard.py"],
    check=True, capture_output=True, text=True,
).stdout
exec(compile(source, f"{BASELINE}:tools/worktree_guard.py", "exec"), baseline.__dict__)


def probe(module, case):
    with TemporaryDirectory() as temporary, ExitStack() as stack:
        root = Path(temporary).resolve()
        canonical = root / "Anki2/addons21/ankiscape_fork"
        pooled = current.pool_root(canonical) / "slot/ankiscape_fork"
        pooled.mkdir(parents=True)
        interpreter = canonical / ".venv-qt/bin/python"
        interpreter.parent.mkdir(parents=True)
        interpreter.touch()
        common = root / "git-common"
        common.mkdir()
        markers = common / "ankiscape-promotion-gates"
        markers.mkdir()
        stack.enter_context(patch.object(locking, "git_common_dir", return_value=common))
        stack.enter_context(patch.object(
            module, "canonical_and_paths", return_value=(canonical, (canonical, pooled)),
        ))
        stack.enter_context(patch.object(module, "audit"))
        stack.enter_context(patch.object(
            subprocess, "run", side_effect=AssertionError("unexpected actual subprocess"),
        ))
        stack.enter_context(patch.object(os, "kill", side_effect=AssertionError("unexpected signal")))
        kill = stack.enter_context(patch.object(
            locking, "kill_process_tree", side_effect=AssertionError("unexpected process-tree signal"),
        ))
        events = []
        row = {"path": str(pooled), "status": "leased", "lease_id": "lease-1"}
        status = [row]
        requested = "lease-1"
        dirty = ""
        marker_path = markers / "gate.json"
        before = None
        if case in ("fresh_marker", "stale_marker", "malformed_marker", "unreadable_marker"):
            record = locking._new_lock_record("gate", pooled, "head")
            if case == "stale_marker":
                record = replace(record, started_at="2000-01-01T00:00:00+00:00",
                                 heartbeat_at="2000-01-01T00:00:00+00:00")
            before = b"{broken" if case == "malformed_marker" else json.dumps(asdict(record)).encode()
            marker_path.write_bytes(before)
            if case == "fresh_marker":
                held_stream = stack.enter_context(marker_path.open("r+"))
                fcntl.flock(held_stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            if case == "unreadable_marker":
                original_read = Path.read_text

                def read_text(path, *args, **kwargs):
                    if path == marker_path:
                        raise PermissionError("inert marker read denied")
                    return original_read(path, *args, **kwargs)

                stack.enter_context(patch.object(Path, "read_text", read_text))
        if case == "contended_coordination":
            held = locking.claim_landing_lock(canonical, operation="gate", worktree=pooled, commit="head")
            stack.callback(held.release)
            held.stream.seek(0)
            held.stream.truncate()
            held.stream.write("{unreadable")
            held.stream.flush()
            marker_path = held.path
            before = b"{unreadable"
        if case == "dirty":
            dirty = "?? untracked-work.py\n"
        if case == "wrong_lease":
            requested = "wrong-lease"
        elif case == "empty_lease":
            requested = ""
        elif case == "missing_lease":
            status = []
        elif case == "missing_lease_id":
            status = [{key: value for key, value in row.items() if key != "lease_id"}]
        elif case == "duplicate_lease":
            status = [row, row]
        elif case == "relative_status_path":
            status = [{**row, "path": "relative/path"}]
        elif case == "missing_marker_directory":
            markers.rmdir()
        elif case == "dangling_marker_directory":
            markers.rmdir()
            markers.symlink_to(root / "missing-dir", target_is_directory=True)

        def git(repo, *args, **kwargs):
            events.append(("git", args))
            output = "head\n" if args[0] == "rev-parse" else dirty if args[0] == "status" else ""
            if args[0] == "worktree":
                output = (f"worktree {canonical}\nbranch refs/heads/main\n\n"
                          f"worktree {pooled}\nbranch refs/heads/goal/occupied\n\n")
            return Mock(stdout=output, returncode=0)

        def treehouse(repo, *args):
            events.append(("pool", args))
            output = json.dumps(row) if args[0] == "get" else json.dumps(status) if args[0] == "status" else ""
            return Mock(stdout=output, returncode=0)

        stack.enter_context(patch.object(module, "_git", side_effect=git))
        stack.enter_context(patch.object(module, "_treehouse", side_effect=treehouse))
        error = None
        with redirect_stdout(io.StringIO()):
            try:
                if case == "duplicate_branch":
                    module.lease_worktree(canonical, "goal/occupied", "inert-checker", "main")
                else:
                    module.release_worktree(canonical, pooled, requested)
            except (RuntimeError, ValueError, OSError) as exc:
                error = f"{type(exc).__name__}: {exc}"
        mutations = [kind + ":" + args[0] for kind, args in events if args[0] in ("get", "checkout", "return")]
        preserved = before is None or marker_path.read_bytes() == before
        assert preserved, (module.__name__, case, "marker bytes changed")
        kill.assert_not_called()
        return {"refused": error is not None, "fake_mutation_calls": mutations, "marker_preserved": preserved}


cases = (
    "duplicate_branch", "fresh_marker", "stale_marker", "malformed_marker", "unreadable_marker",
    "contended_coordination", "dirty", "wrong_lease", "empty_lease", "missing_lease", "missing_lease_id",
    "duplicate_lease", "relative_status_path", "dangling_marker_directory", "missing_marker_directory", "valid_return",
)
results = []
for case in cases:
    old, new = probe(baseline, case), probe(current, case)
    positive = case in ("valid_return", "missing_marker_directory")
    assert new["refused"] != positive, (case, new)
    assert new["fake_mutation_calls"] == (["git:checkout", "pool:return"] if positive else []), (case, new)
    results.append({"case": case, "baseline": old, "current": new})
print(json.dumps({"baseline_commit": BASELINE, "case_count": len(cases), "passed": True, "results": results}, indent=2))
