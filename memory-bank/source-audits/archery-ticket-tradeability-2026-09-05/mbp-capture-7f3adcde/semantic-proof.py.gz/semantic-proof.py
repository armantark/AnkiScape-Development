#!/usr/bin/env python3
"""Verify retained payloads without importing or executing AnkiScape code."""
import ast
from collections import Counter
import copy
import gzip
import hashlib
import json
from pathlib import Path

BASELINE = Path('/tmp/cut-gem-baseline-6438d422')
CANDIDATE = Path('/tmp/archery-verification-pze6k46e')
CAPTURE_SCRIPT = Path('/tmp/ankiscape-archery-capture-2026-09-05.py')
DISCOVERY = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/14/ankiscape_fork/memory-bank/source-audits/cut-gem-tradeability-implementation-2026-09-05/mbp/repair/discovery')
OUTPUT = Path('/tmp/ankiscape-archery-semantic-proof-pze6k46e.json')
MODULES = (
    'core/constants.py', 'data/quest_data.py', 'data/combat_data.py',
    'data/slayer_data.py', 'logic_pure/logic_pure_combat_engine.py',
    'tests/test_combat_enemy_roster.py', 'logic/shop_logic.py',
    'ui/ui_tab_shop.py', 'data/achievement_diary_catalog.py',
    'runtime/runtime_actions_carried.py', 'runtime/runtime_actions_activities.py',
)
NEW_TEST = 'test_ranging_guild.RangingGuildPureMechanicsTests.test_earned_tickets_can_be_traded_and_spent_on_guild_rewards'
EXPECTED_ROW = {'asset_path': '<repo>/activityicons/ranging_guild.png',
 'buy_limit': 5000,
 'buy_limit_source': {'oldid': 6457777,
                      'timestamp': '2012-10-23T03:28:03Z',
                      'title': 'Calculator:Grand Exchange buying limits'},
 'cache_value': 25,
 'category': 'material',
 'exchangeable': True,
 'guide_price': 25,
 'guide_price_provenance': {},
 'guide_price_source': 'cache_value_fallback',
 'high_alchemy_value': 15,
 'item_id': 'material_archery_ticket',
 'item_name': 'Archery ticket',
 'low_alchemy_value': 10,
 'required_level': 1,
 'source_item_id': 1464,
 'source_role': 'general',
 'tradeable': True}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def binding(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def read_payload(path):
    raw = path.read_bytes()
    body, footer = raw.rsplit(b'MODULE_SURFACE_SHA256: ', 1)
    digest = sha(body)
    assert footer == (digest + '\n').encode(), ('invalid footer', str(path))
    lines = body.decode().splitlines(keepends=True)
    pairs = [line[5:].rstrip('\n').split(' = ', 1) for line in lines if line.startswith('NAME ')]
    assert len(pairs) == len(dict(pairs)), ('duplicate exported name', str(path))
    return raw, body, lines, {key: json.loads(value) for key, value in pairs}, digest


def mapping(value, class_name='builtins.dict'):
    assert set(value) == {'class', 'items', 'type'}
    assert value['type'] == 'mapping' and value['class'] == class_name
    assert all(isinstance(pair, list) and len(pair) == 2 for pair in value['items'])
    result = dict(value['items'])
    assert len(result) == len(value['items']), 'Duplicate mapping key'
    return result


def decode_row(value):
    if not isinstance(value, dict):
        return value
    return {key: decode_row(item) for key, item in mapping(value).items()}


def reverse_mapping_flag(old, new):
    before, after = mapping(old), mapping(new)
    assert before.keys() == after.keys()
    assert [key for key in before if before[key] != after[key]] == ['Archery ticket']
    old_row, new_row = mapping(before['Archery ticket']), mapping(after['Archery ticket'])
    assert old_row['source_item_id'] == new_row['source_item_id'] == 1464
    assert old_row['tradeable'] is False and new_row['tradeable'] is True
    for pair in after['Archery ticket']['items']:
        if pair[0] == 'tradeable':
            pair[1] = False
    assert new == old, 'Unexpected metadata or mapping-order change'


def reverse_definition_flag(old, new):
    assert set(old) == set(new) == {'class', 'items', 'type'}
    assert old['class'] == new['class'] == 'builtins.tuple'
    assert old['type'] == new['type'] == 'sequence'
    assert len(old['items']) == len(new['items'])
    before = [row for row in old['items'] if row['fields']['storage_key'] == 'Archery ticket']
    after = [row for row in new['items'] if row['fields']['storage_key'] == 'Archery ticket']
    assert len(before) == len(after) == 1
    a, b = before[0], after[0]
    assert a['class'] == b['class'] == 'ankiscape.core.item_registry.ItemDefinition'
    assert a['type'] == b['type'] == 'dataclass'
    assert a['fields']['source_item_id'] == b['fields']['source_item_id'] == 1464
    assert a['fields']['id'] == b['fields']['id'] == 'material_archery_ticket'
    assert a['fields']['tradeable'] is False and b['fields']['tradeable'] is True
    b['fields']['tradeable'] = False
    assert new == old, 'Unexpected definition field or sequence-order change'


def reverse_catalog_row(old, new):
    before = mapping(old, 'builtins.mappingproxy')
    after = mapping(new, 'builtins.mappingproxy')
    assert after.keys() - before.keys() == {'Archery ticket'} and not before.keys() - after.keys()
    assert json.dumps(decode_row(after['Archery ticket']), sort_keys=True) == json.dumps(EXPECTED_ROW, sort_keys=True), 'Unexpected Archery ticket catalog row'
    new['items'] = [pair for pair in new['items'] if pair[0] != 'Archery ticket']
    assert new == old, 'An existing catalog row or its ordering changed'
    return {'before_count': len(before), 'after_count': len(after), 'added_row': EXPECTED_ROW}


def main(proof):
    script_raw = CAPTURE_SCRIPT.read_bytes()
    assert sha(script_raw) == 'd12adb12bfde0b88416af2d8d05a7fb302bc8ac747884323bb42d531bc0fdf74'
    tree = ast.parse(script_raw)
    expected = next(ast.literal_eval(node.value) for node in tree.body
                    if isinstance(node, ast.Assign) and any(
                        isinstance(target, ast.Name) and target.id == 'EXPECTED' for target in node.targets))
    source = json.loads((CANDIDATE / 'source-hashes.json').read_bytes())
    after_source = json.loads((CANDIDATE / 'source-hashes-after.json').read_bytes())
    assert source['expected'] == source['actual'] == after_source == expected
    proof['source_binding'] = {'capture_script': binding(CAPTURE_SCRIPT), 'hashes': expected,
                               'before': binding(CANDIDATE / 'source-hashes.json'),
                               'after': binding(CANDIDATE / 'source-hashes-after.json')}
    required = [lane + '-' + module.replace('/', '_') + '.stdout'
                for lane in ('plain', 'qt') for module in (*MODULES, *(('__init__.py',) if lane == 'qt' else ()))]
    assert len(required) == len(set(required)) == 23
    assert {path.name for path in CANDIDATE.glob('*.py.stdout')} == set(required)
    assert {path.name for path in BASELINE.glob('*.py.stdout')} == set(required) | {'plain-__init__.py.stdout'}
    control = BASELINE / 'plain-__init__.py.stdout'
    assert control.read_bytes() == b''
    proof['extra_baseline_control'] = {**binding(control), 'role': 'Unavailable plain root control; outside the required 23 payloads'}
    expected_exports = {
        'core_constants.py': {'RANGING_GUILD_EXTRA_ITEM_DATA', 'EXTRA_ITEM_DATA', 'ITEM_DEFINITIONS'},
        'logic_shop_logic.py': {'EXTRA_ITEM_DATA'},
        'runtime_runtime_actions_carried.py': {'ITEM_DEFINITIONS'},
        'runtime_runtime_actions_activities.py': {'ITEM_DEFINITIONS'},
        '__init__.py': {'GE_ITEM_CATALOG'},
    }
    proof['payloads'] = []
    for filename in required:
        old_raw, old_body, old_lines, old, old_digest = read_payload(BASELINE / filename)
        new_raw, new_body, new_lines, new, new_digest = read_payload(CANDIDATE / filename)
        assert list(old) == list(new), ('Changed exported names/order', filename)
        assert [line for line in old_lines if not line.startswith('NAME ')] == [line for line in new_lines if not line.startswith('NAME ')]
        changed = {key for key in old if old[key] != new[key]}
        assert changed == expected_exports.get(filename.split('-', 1)[1].removesuffix('.stdout'), set()), filename
        fixed = copy.deepcopy(new)
        catalog = None
        for key in changed:
            if key in {'RANGING_GUILD_EXTRA_ITEM_DATA', 'EXTRA_ITEM_DATA'}:
                reverse_mapping_flag(old[key], fixed[key])
            elif key == 'ITEM_DEFINITIONS':
                reverse_definition_flag(old[key], fixed[key])
            elif key == 'GE_ITEM_CATALOG':
                assert filename == 'qt-__init__.py.stdout'
                catalog = reverse_catalog_row(old[key], fixed[key])
            else:
                raise AssertionError(('Unknown difference', filename, key))
        assert fixed == old
        rebuilt = ''.join(
            'NAME ' + line[5:].split(' = ', 1)[0] + ' = ' + json.dumps(
                fixed[line[5:].split(' = ', 1)[0]], ensure_ascii=True, separators=(',', ':'), sort_keys=True) + '\n'
            if line.startswith('NAME ') else line for line in new_lines).encode()
        assert rebuilt == old_body, ('Reversed full body differs', filename)
        if not changed:
            assert new_raw == old_raw, ('Unchanged payload bytes differ', filename)
        proof['payloads'].append({
            'file': filename, 'baseline': {**binding(BASELINE / filename), 'body_sha256': old_digest},
            'candidate': {**binding(CANDIDATE / filename), 'body_sha256': new_digest},
            'changed_exports': sorted(changed), 'reversed_body_sha256': sha(rebuilt),
            'reversed_body_byte_equal': True, 'catalog': catalog,
        })
    assert sum(bool(row['changed_exports']) for row in proof['payloads']) == 9
    proof['discovery'] = []
    for lane in ('plain', 'qt'):
        baseline_path = DISCOVERY / f'baseline-{lane}.stdout.gz'
        old_raw = gzip.decompress(baseline_path.read_bytes())
        assert sha(old_raw) == 'da52c1f1ad36b961d1958b87ca5d310803a08e8131dd587f147d3cbba53e1cfa'
        candidate_path = CANDIDATE / f'{lane}-discovery.stdout'
        new_raw = candidate_path.read_bytes()
        old_ids, new_ids = old_raw.decode().splitlines(), new_raw.decode().splitlines()
        assert Counter(new_ids) == Counter(old_ids) + Counter({NEW_TEST: 1})
        assert [test_id for test_id in new_ids if test_id != NEW_TEST] == old_ids
        assert (CANDIDATE / f'{lane}-discovery.stderr').read_bytes() == b''
        proof['discovery'].append({'lane': lane, 'baseline': binding(baseline_path),
                                   'baseline_raw_sha256': sha(old_raw), 'candidate': binding(candidate_path),
                                   'before_count': len(old_ids), 'after_count': len(new_ids),
                                   'added': {NEW_TEST: 1}, 'removed': {}})
    results = json.loads((CANDIDATE / 'results.json').read_bytes())
    assert len(results) == 27
    assert all(row['exit_code'] == 0 for row in results)
    proof['capture_verification'] = binding(CANDIDATE / 'verification.json')
    proof.update(status='PASS', required_payloads=23, changed_payloads=9, byte_identical_payloads=14,
                 scope='Captured semantic delta and discovery proof only; full gates and native acceptance remain separate')


if __name__ == '__main__':
    result = {'status': 'FAIL', 'baseline_directory': str(BASELINE), 'candidate_directory': str(CANDIDATE)}
    try:
        main(result)
    except (AssertionError, OSError, ValueError, KeyError, TypeError) as error:
        result['error'] = repr(error)
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'proof_path': str(OUTPUT),
                      'proof_sha256': sha(OUTPUT.read_bytes()), 'error': result.get('error')}))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)
