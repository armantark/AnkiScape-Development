#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <directory-containing-unchanged-cache-binding-json-files>" >&2
  exit 2
fi

crayfish_scratch=$(mktemp -d /tmp/ankiscape-crayfish-cache.XXXXXX)
printf '%s\n' "$crayfish_scratch"

/opt/homebrew/bin/python3 - "$1" "$crayfish_scratch" "$0" <<'PY'
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

bindings, scratch, script = map(Path, sys.argv[1:])
java = Path('/opt/homebrew/opt/openjdk@25/bin/java')
gradle = Path('/Users/armantarkhanian/.gradle/caches/modules-2/files-2.1')
core = gradle / 'rs.darkan/core/2.0.5/5a13ad7bada8a9b1587bfa72fb013283102c6b7d/core-2.0.5.jar'
source = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork/tools/OpenRs2CacheItemSearch.java')
cache_root = Path('/Users/armantarkhanian/Library/Caches/codex/2012scape-openrs2/extracted')
binding_hashes = {
    727: '63beff9f4072a9e8ed6ca9357cae44f47dad2dec0c6948cdc3679ce621eb2d38',
    742: 'cef8ef9cd26bbab386f1c0fe58916faf71c925b2f7fca014604b8c4cd451856e',
}

def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

report = {
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'scratch': str(scratch),
    'script_path': str(script.resolve()),
    'script_sha256': sha256(script),
    'status': 'validating_inputs',
    'scope_ids': [13431, 13433, 13434, 13435],
    'ordinary_cooked_item_id': 13433,
    'not_emitted_by_decoder': ['value', 'certificate IDs', 'noted flag'],
    'qualification': 'Client identity and flags only; no direct player-tradeability predicate is decoded.',
    'input_bindings': [],
    'queries': [],
}

def checkpoint():
    report['files'] = [
        {'path': path.name, 'bytes': path.stat().st_size, 'sha256': sha256(path)}
        for path in sorted(scratch.iterdir())
        if path.is_file() and path.name != 'manifest.json'
    ]
    (scratch / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')

checkpoint()
try:
    assert sha256(core) == 'bfaf99f7bb04a55418a9aeb07a01f2724034692637b435a87df4f3f4b029e3fe', core
    assert sha256(source) == '0265f583670dea0a3486652b1e19b30fad778e658fea82df39ce892b7cddb26b', source
    local_source = scratch / source.name
    local_source.write_bytes(source.read_bytes())
    assert sha256(local_source) == sha256(source)
    report['decoder'] = {
        'java': str(java), 'java_sha256': sha256(java),
        'source_path': str(source), 'source_sha256': sha256(source),
        'selected_core': str(core), 'selected_core_sha256': sha256(core),
    }

    # Both complete extracted trees must pass before any Java invocation.
    for revision, expected_hash in binding_hashes.items():
        supplied = bindings / f'cache-{revision}-input-binding.json'
        assert sha256(supplied) == expected_hash, supplied
        retained = scratch / supplied.name
        retained.write_bytes(supplied.read_bytes())
        binding = json.loads(retained.read_text())
        assert binding['revision'] == revision
        revision_root = cache_root / f"{revision}-{binding['date']}"
        cache = revision_root / 'cache'
        expected = {member['zip_member'] for member in binding['members']}
        assert len(expected) == len(binding['members'])
        actual = {str(path.relative_to(revision_root)) for path in cache.rglob('*') if path.is_file()}
        assert actual == expected, {'missing': sorted(expected - actual), 'extra': sorted(actual - expected)}
        verified = []
        for member in binding['members']:
            path = revision_root / member['zip_member']
            assert path.resolve().is_relative_to(cache.resolve()), path
            before = path.stat()
            digest = sha256(path)
            after = path.stat()
            assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), path
            assert after.st_size == member['bytes'], path
            assert digest == member['zip_member_sha256'] == member['extracted_sha256'], path
            verified.append({'path': str(path), 'resolved_path': str(path.resolve()), 'bytes': after.st_size,
                             'mtime_ns': after.st_mtime_ns, 'sha256': digest})
        report['input_bindings'].append({
            'revision': revision, 'cache': str(cache), 'binding_sha256': expected_hash,
            'retained_archive_sha256': binding['archive_sha256'],
            'archive_rehashed_on_mbp': False,
            'all_actual_files_match_retained_archive_member_hashes': True,
            'verified_at_utc': datetime.now(timezone.utc).isoformat(), 'members': verified,
        })
        checkpoint()

    dependencies = sorted(path for path in gradle.rglob('*.jar')
                          if not path.is_relative_to(gradle / 'rs.darkan/core'))
    classpath = ':'.join(map(str, [core, *dependencies]))
    (scratch / 'classpath.txt').write_text(classpath + '\n')
    report['classpath_jars'] = [{'path': str(path), 'sha256': sha256(path)} for path in [core, *dependencies]]
    report['status'] = 'inputs_verified_querying'
    checkpoint()

    version = subprocess.run([str(java), '-version'], capture_output=True)
    (scratch / 'java-version.stdout').write_bytes(version.stdout)
    (scratch / 'java-version.stderr').write_bytes(version.stderr)
    report['java_version_exit_code'] = version.returncode
    checkpoint()
    version.check_returncode()

    for binding in report['input_bindings']:
        revision = binding['revision']
        stem = f'cache-{revision}'
        argv = [str(java), f'-Xlog:class+load=info:file={scratch / (stem + "-class-load.log")}',
                '--class-path', classpath, str(local_source), binding['cache'],
                '--id', '13431', '13433', '13434', '13435']
        (scratch / f'{stem}-argv.json').write_text(json.dumps(argv, indent=2) + '\n')
        started = datetime.now(timezone.utc).isoformat()
        result = subprocess.run(argv, cwd=scratch, capture_output=True)
        (scratch / f'{stem}.stdout').write_bytes(result.stdout)
        (scratch / f'{stem}.stderr').write_bytes(result.stderr)
        (scratch / f'{stem}.exit').write_text(str(result.returncode) + '\n')
        report['queries'].append({'revision': revision, 'argv': argv, 'cwd': str(scratch),
                                  'started_at_utc': started,
                                  'finished_at_utc': datetime.now(timezone.utc).isoformat(),
                                  'exit_code': result.returncode})
        checkpoint()
        result.check_returncode()
        origins = [line for line in (scratch / f'{stem}-class-load.log').read_text().splitlines()
                   if '] com.rs.cache.loaders.ItemDefinitions source: ' in line]
        report['queries'][-1]['item_definition_class_origin_lines'] = origins
        checkpoint()
        assert len(origins) == 1 and str(core) in origins[0], origins
        for member in binding['members']:
            path = Path(member['path'])
            stat = path.stat()
            assert (stat.st_size, stat.st_mtime_ns) == (member['bytes'], member['mtime_ns']), path
            assert sha256(path) == member['sha256'], path
        report['queries'][-1]['input_hashes_unchanged_after_query'] = True
        checkpoint()

    report['status'] = 'queries_completed_parent_assessment_pending'
    report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    checkpoint()
except BaseException as error:
    report['status'] = 'failed'
    report['error'] = f'{type(error).__name__}: {error}'
    checkpoint()
    raise
PY
