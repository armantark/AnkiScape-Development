#!/usr/bin/env python3
"""Capture Crayfish verification evidence after the driver has synced the mirror."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
BASELINE = ROOT.parent / 'reports/cut-gem-baseline-6438d422'
SELECTORS = [
    'test_cooking_data.TestCookingData.test_extra_items_use_food_category_and_burnt_junk_tradeability',
    'test_grand_exchange_data.GrandExchangeDataTest.test_live_catalog_uses_period_prices_and_limits_when_the_identity_is_exact',
    'item_tradeability.test_crayfish_tradeability.CrayfishTradeabilityTest.test_cooked_crayfish_retains_custody_through_ge_round_trip',
]
EXPECTED = {
    'data/cooking_data.py': '022ffb22ea1fb7b539fcc441329ec83ae2f92f2cc36c9527c47413c3f4b8fa2f',
    'generated/grand_exchange_period_generated.py': 'e1fba441493eab3cb643d7af0ff3409f7deddeffb517e92cdc6b265a9f67828f',
    'tests/test_cooking_data.py': '306d489cec6829948b91f1e7e2793239e3f99527cec8e82834166f0aeea6cbfb',
    'tests/test_grand_exchange_data.py': '5a35f94c2bf74a383aa3902ff8585f0ed91fc110d8d4c588b0486c04ec20b90f',
    'tests/item_tradeability/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    'tests/item_tradeability/test_crayfish_tradeability.py': 'f52bc5cbcffe8877fa4176cf8f72123f7cd2fd65b72f9b39157559ac37a34334',
    'tests/test_module_surface.py': 'ba48d8b3afbfd957a1298846b263eb9358e5ebf3415d93be1adf76262a65c25f',
    'tools/module_surface.py': 'a66948b912691279dc951ac9e5aa0c144b75a351c9b1bb46b88f67d85ebcf1e5',
    'run_tests.py': '4ce89f5dd8c70693977140fbc42bef571cdcada3d97e61671d0e873f0653bb33',
}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def source_hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            if (ROOT / name).is_file() else None for name in EXPECTED}


def payload_integrity(path):
    record = {'path': str(path), 'valid': False}
    try:
        raw = path.read_bytes()
        record.update(bytes=len(raw), file_sha256=hashlib.sha256(raw).hexdigest())
        body, footer = raw.rsplit(b'MODULE_SURFACE_SHA256: ', 1)
        digest = hashlib.sha256(body).hexdigest()
        recorded = footer.decode('ascii').strip()
        record.update(body_sha256=digest, footer_sha256=recorded,
                      valid=digest == recorded)
        if not record['valid']:
            record['error'] = 'Body digest does not match footer'
    except (OSError, ValueError, UnicodeError) as error:
        record['error'] = repr(error)
    return record


def main():
    out = Path(tempfile.mkdtemp(prefix='crayfish-verification-', dir=ROOT.parent / 'reports'))
    print(str(out), flush=True)
    started = datetime.now(timezone.utc).isoformat()
    actual = source_hashes()
    write_json(out / 'source-hashes.json', {'expected': EXPECTED, 'actual': actual})
    write_json(out / 'capture.json', {
        'started_utc': started, 'repo': str(ROOT), 'baseline': str(BASELINE),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'selectors': SELECTORS, 'timeout_seconds_per_process': 300,
    })
    if actual != EXPECTED:
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': ['Source hash mismatch; no runtime commands launched']})
        return 2
    tree = ast.parse((ROOT / 'tests/test_module_surface.py').read_text())
    modules = list(next(ast.literal_eval(node.value) for node in tree.body
                        if isinstance(node, ast.Assign) and any(
                            isinstance(target, ast.Name) and target.id == 'FIRST_WAVE_DIGESTS'
                            for target in node.targets)))
    if len(modules) != 11:
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': ['FIRST_WAVE_DIGESTS does not contain 11 modules']})
        return 2
    baseline_files = sorted(BASELINE.glob('*.py.stdout'))
    write_json(out / 'baseline-files.json', [str(path) for path in baseline_files])
    baseline_integrity = [payload_integrity(path) for path in baseline_files]
    write_json(out / 'baseline-integrity.json', baseline_integrity)
    errors = []
    if len(baseline_files) != 23 or not all(row['valid'] for row in baseline_integrity):
        errors.append('Baseline must contain 23 complete payloads with valid footers')
    results = []
    surfaces = []
    focus_checks = []
    for lane, python in [('plain', '/opt/homebrew/bin/python3'),
                         ('qt', str(ROOT.parent / '.venv-qt/bin/python'))]:
        env = {**os.environ, 'PATH': '/opt/homebrew/bin:/usr/bin:/bin',
               'QT_QPA_PLATFORM': 'offscreen',
               'ANKISCAPE_GAME_MAIN': str(ROOT.parent / 'sources/game-main'),
               'ANKISCAPE_DARKAN_WORLD_SERVER': str(ROOT.parent / 'sources/darkan-world-server')}
        env.pop('PYTHONPATH', None)
        if lane == 'plain':
            env['PYTHONPATH'] = str(ROOT.parent / 'plain-site')
        jobs = [('focus', ['run_tests.py', *SELECTORS, '--verbosity', '2']),
                ('discovery', ['run_tests.py', '--list', '--max-results', '10000'])]
        jobs += [(module.replace('/', '_'), ['tools/module_surface.py', module])
                 for module in [*modules, *(['__init__.py'] if lane == 'qt' else [])]]
        for mode, args in jobs:
            name = lane + '-' + mode
            argv = [python, *args]
            record = {'lane': lane, 'mode': mode, 'argv': argv, 'exit_code': None,
                      'stdout': name + '.stdout', 'stderr': name + '.stderr', 'status': 'running'}
            results.append(record)
            write_json(out / 'results.json', results)
            with (out / record['stdout']).open('wb') as stdout, (out / record['stderr']).open('wb') as stderr:
                try:
                    record['exit_code'] = subprocess.run(argv, cwd=ROOT, env=env,
                                                        stdout=stdout, stderr=stderr,
                                                        timeout=300).returncode
                    record['status'] = 'finished'
                except (OSError, subprocess.TimeoutExpired) as error:
                    record.update(status='error', error=repr(error))
            write_json(out / 'results.json', results)
            if record['exit_code'] != 0:
                errors.append(name + ': subprocess did not exit successfully')
            if mode == 'focus':
                stderr_text = (out / record['stderr']).read_text(errors='replace')
                outcomes = re.findall(r'^test_\S+ \(([^\n]+)\) \.\.\. (.+)$', stderr_text, re.MULTILINE)
                check = {'lane': lane, 'outcomes': outcomes,
                         'valid': Counter(test_id for test_id, _ in outcomes) == Counter(SELECTORS)
                         and all(status == 'ok' for _, status in outcomes)
                         and re.search(r'^Ran 3 tests in .+s$', stderr_text, re.MULTILINE) is not None
                         and re.search(r'^OK$', stderr_text, re.MULTILINE) is not None
                         and record['exit_code'] == 0}
                focus_checks.append(check)
                write_json(out / 'focused-verification.json', focus_checks)
                if not check['valid']:
                    errors.append(name + ': expected exactly three named passing tests with no skips')
            elif mode != 'discovery':
                integrity = payload_integrity(out / record['stdout'])
                surfaces.append(integrity)
                write_json(out / 'surface-integrity.json', surfaces)
                if not integrity['valid']:
                    errors.append(name + ': invalid surface payload')
            print(name, record['exit_code'], record['status'], flush=True)
    candidate_names = {Path(row['path']).name for row in surfaces}
    if len(surfaces) != 23 or candidate_names != {path.name for path in baseline_files}:
        errors.append('Candidate and baseline must have the same 23 payload filenames')
    final_hashes = source_hashes()
    write_json(out / 'source-hashes-after.json', final_hashes)
    if final_hashes != actual:
        errors.append('Source files changed during capture')
    verdict = {'status': 'FAIL' if errors else 'PASS', 'errors': errors,
               'finished_utc': datetime.now(timezone.utc).isoformat(),
               'scope': 'Capture integrity and focused tests only; semantic reversal and discovery comparison are pending',
               'surface_count': len(surfaces), 'subprocess_count': len(results)}
    write_json(out / 'verification.json', verdict)
    print(json.dumps(verdict), flush=True)
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
