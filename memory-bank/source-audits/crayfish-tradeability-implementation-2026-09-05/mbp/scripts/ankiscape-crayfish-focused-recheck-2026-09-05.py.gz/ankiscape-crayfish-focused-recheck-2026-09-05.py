#!/usr/bin/env python3
"""Capture the three corrected Crayfish checks and discovery in both MBP lanes."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path('/Users/armantarkhanian/ankiscape-remote-test-host/ankiscape_fork')
SELECTORS = [
    'test_cooking_data.TestCookingData.test_extra_items_use_food_category_and_burnt_junk_tradeability',
    'test_grand_exchange_data.GrandExchangeDataTest.test_live_catalog_uses_period_prices_and_limits_when_the_identity_is_exact',
    'item_tradeability.test_crayfish_tradeability.CrayfishTradeabilityTest.test_cooked_crayfish_retains_custody_through_ge_round_trip',
]
EXPECTED = {
    'data/cooking_data.py': '022ffb22ea1fb7b539fcc441329ec83ae2f92f2cc36c9527c47413c3f4b8fa2f',
    'generated/grand_exchange_period_generated.py': 'e1fba441493eab3cb643d7af0ff3409f7deddeffb517e92cdc6b265a9f67828f',
    'tests/test_cooking_data.py': '306d489cec6829948b91f1e7e2793239e3f99527cec8e82834166f0aeea6cbfb',
    'tests/test_grand_exchange_data.py': 'cd819e5a29dabbfa068f286cbb6535bc21fad9a9206ba3b74ceccd3c55ea00eb',
    'tests/item_tradeability/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    'tests/item_tradeability/test_crayfish_tradeability.py': 'f52bc5cbcffe8877fa4176cf8f72123f7cd2fd65b72f9b39157559ac37a34334',
    'run_tests.py': '4ce89f5dd8c70693977140fbc42bef571cdcada3d97e61671d0e873f0653bb33',
}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def source_hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            if (ROOT / name).is_file() else None for name in EXPECTED}


def main():
    out = Path(tempfile.mkdtemp(prefix='crayfish-focused-recheck-', dir=ROOT.parent / 'reports'))
    print(str(out), flush=True)
    actual = source_hashes()
    write_json(out / 'source-hashes.json', {'expected': EXPECTED, 'actual': actual})
    write_json(out / 'capture.json', {
        'started_utc': datetime.now(timezone.utc).isoformat(), 'repo': str(ROOT),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'selectors': SELECTORS, 'timeout_seconds_per_process': 300,
    })
    if actual != EXPECTED:
        write_json(out / 'verification.json', {'status': 'FAIL', 'errors': ['Source hash mismatch; no runtime commands launched']})
        return 2
    errors = []
    results = []
    focus_checks = []
    for lane, python in [('plain', '/opt/homebrew/bin/python3'),
                         ('qt', str(ROOT.parent / '.venv-qt/bin/python'))]:
        env = {**os.environ, 'PATH': '/opt/homebrew/bin:/usr/bin:/bin',
               'QT_QPA_PLATFORM': 'offscreen',
               'ANKISCAPE_GAME_MAIN': str(ROOT.parent / 'sources/game-main'),
               'ANKISCAPE_DARKAN_WORLD_SERVER': str(ROOT.parent / 'sources/darkan-world-server')}
        env.pop('PYTHONPATH', None)
        if lane == 'plain':
            env['PYTHONPATH'] = str(ROOT.parent / 'plain-site')
        for mode, args in [('focus', ['run_tests.py', *SELECTORS, '--verbosity', '2']),
                           ('discovery', ['run_tests.py', '--list', '--max-results', '10000'])]:
            name = lane + '-' + mode
            record = {'lane': lane, 'mode': mode, 'argv': [python, *args],
                      'exit_code': None, 'stdout': name + '.stdout',
                      'stderr': name + '.stderr', 'status': 'running',
                      'started_utc': datetime.now(timezone.utc).isoformat()}
            results.append(record)
            write_json(out / 'results.json', results)
            with (out / record['stdout']).open('wb') as stdout, (out / record['stderr']).open('wb') as stderr:
                try:
                    record['exit_code'] = subprocess.run(record['argv'], cwd=ROOT, env=env,
                                                        stdout=stdout, stderr=stderr,
                                                        timeout=300).returncode
                    record['status'] = 'finished'
                except (OSError, subprocess.TimeoutExpired) as error:
                    record.update(status='error', error=repr(error))
            record['finished_utc'] = datetime.now(timezone.utc).isoformat()
            for stream in ('stdout', 'stderr'):
                raw = (out / record[stream]).read_bytes()
                record[stream + '_bytes'] = len(raw)
                record[stream + '_sha256'] = hashlib.sha256(raw).hexdigest()
            write_json(out / 'results.json', results)
            if record['exit_code'] != 0:
                errors.append(name + ': subprocess did not exit successfully')
            if mode == 'focus':
                stderr_text = (out / record['stderr']).read_text(errors='replace')
                outcomes = re.findall(r'^test_\S+ \(([^\n]+)\) \.\.\. (.+)$', stderr_text, re.MULTILINE)
                check = {'lane': lane, 'outcomes': outcomes,
                         'valid': Counter(test_id for test_id, _ in outcomes) == Counter(SELECTORS)
                         and all(status == 'ok' for _, status in outcomes)
                         and re.search(r'^Ran 3 tests in .+s$', stderr_text, re.MULTILINE) is not None
                         and re.search(r'^OK$', stderr_text, re.MULTILINE) is not None
                         and record['exit_code'] == 0}
                focus_checks.append(check)
                write_json(out / 'focused-verification.json', focus_checks)
                if not check['valid']:
                    errors.append(name + ': expected exactly three named passing tests with no skips')
            print(name, record['exit_code'], record['status'], flush=True)
    final_hashes = source_hashes()
    write_json(out / 'source-hashes-after.json', final_hashes)
    if final_hashes != actual:
        errors.append('Source files changed during capture')
    verdict = {'status': 'FAIL' if errors else 'PASS', 'errors': errors,
               'finished_utc': datetime.now(timezone.utc).isoformat(),
               'scope': 'Focused tests and discovery capture only; discovery comparison and full gates are pending',
               'subprocess_count': len(results)}
    write_json(out / 'verification.json', verdict)
    print(json.dumps(verdict), flush=True)
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
