#!/usr/bin/env python3
"""Run the Crayfish focused recheck through the canonical remote-run guard."""
import fcntl
import importlib.util
import json
from pathlib import Path
import sys

CANONICAL = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/addons21/ankiscape_fork')
CANDIDATE = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/2/ankiscape_fork')
COMMAND = '/opt/homebrew/bin/python3 /tmp/ankiscape-crayfish-focused-recheck-2026-09-05.py'


def main():
    spec = importlib.util.spec_from_file_location('crayfish_recheck_remote_runner', CANONICAL / 'tools/run_remote_tests.py')
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    runner._remote_lane_command = lambda lane: COMMAND
    lane = 'crayfish-focused-recheck-2026-09-05'
    runner.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with runner.LOCAL_MIRROR_LOCK_PATH.open('a+', encoding='utf-8') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            runner._reconcile_pending_run()
            runner._preflight('plain')
            runner._preflight('qt')
            runner._sync(CANDIDATE)
            returncode, _ = runner._stream_remote_run(lane, timeout=1800, poll_interval=5)
            print(json.dumps({'lane': lane, 'returncode': returncode,
                              'scope': 'Focused tests and discovery capture; not full-gate evidence'}), flush=True)
            return returncode
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


if __name__ == '__main__':
    raise SystemExit(main())
