import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

repo, evidence = map(Path, sys.argv[1:])
expected = json.loads((evidence / 'frozen-source-hashes.json').read_text())
selection = json.loads((evidence / 'expected-selection.json').read_text())
paths = ('tools/memory_bank_queue_packet.py', 'tests/test_memory_bank_queue_packet.py')
source_hashes = lambda: {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in paths}
before = source_hashes()
(evidence / 'source-hashes-before.json').write_text(json.dumps(before, indent=2) + '\n')
assert before == {name: expected[name] for name in paths}, 'candidate source hash mismatch'
assert hashlib.sha256((repo / 'memory-bank/papercuts.md').read_bytes()).hexdigest() == selection['ledger_sha256']
baseline = evidence / 'baseline-tool.py.txt'
assert hashlib.sha256(baseline.read_bytes()).hexdigest() == expected['baseline_518a_tool']
results = {}

def run(label, command, cwd, env=None):
    with (evidence / f'{label}.stdout').open('w') as out, (evidence / f'{label}.stderr').open('w') as err:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=out, stderr=err, check=False, timeout=120)
    record = {'command': command, 'cwd': str(cwd), 'exit_code': result.returncode}
    (evidence / f'{label}.status.json').write_text(json.dumps(record, indent=2) + '\n')
    results[label] = record
    return result.returncode

plain = '/opt/homebrew/bin/python3'
qt = '/Users/armantarkhanian/ankiscape-remote-test-host/.venv-qt/bin/python'
module = 'tests.test_memory_bank_queue_packet'
assert run('candidate-plain', [plain, '-m', 'unittest', '-v', module], repo) == 0
qt_env = dict(os.environ, QT_QPA_PLATFORM='offscreen')
assert run('candidate-qt', [qt, '-m', 'unittest', '-v', module], repo, qt_env) == 0
selectors = [module + '.MemoryBankQueuePacketTest.' + name for name in (
    'test_papercuts_select_recent_dates_then_later_lines_with_exact_context',
    'test_papercut_context_limit_stops_at_plain_and_bulleted_records',
)]
for label, tool in [('baseline-canary', baseline), ('candidate-canary', repo / paths[0])]:
    scratch = evidence / label
    for package in ('tools', 'tests'):
        (scratch / package).mkdir(parents=True)
        (scratch / package / '__init__.py').write_text('')
    shutil.copyfile(tool, scratch / paths[0])
    shutil.copyfile(repo / paths[1], scratch / paths[1])
    code = run(label, [plain, '-m', 'unittest', '-v', *selectors], scratch)
    stderr = (evidence / f'{label}.stderr').read_text()
    if label == 'baseline-canary':
        assert code == 1 and 'FAILED (failures=2)' in stderr, stderr
        assert len(re.findall(r'^FAIL: ', stderr, re.MULTILINE)) == 2
        assert not re.search(r'^ERROR: ', stderr, re.MULTILINE)
        for selector in selectors:
            assert 'FAIL: ' + selector.rsplit('.', 1)[1] + ' (' in stderr
    else:
        assert code == 0 and '\nOK\n' in stderr, stderr
assert run('actual-cli', [plain, 'tools/memory_bank_queue_packet.py', '.'], repo) == 0
packet_path = evidence / 'actual-cli.stdout'
packet = packet_path.read_text()
assert len(packet_path.read_bytes()) <= 32768, 'CLI exceeded default byte cap'
ledger = (repo / 'memory-bank/papercuts.md').read_text().splitlines()
refs = []
for line in packet.splitlines():
    match = re.match(r'^root\[1\]/memory-bank/papercuts\.md:(\d+): (.*)$', line)
    if match:
        number, text = int(match.group(1)), match.group(2)
        assert ledger[number - 1] == text, f'changed ledger line {number}'
        refs.append(number)
assert refs, 'papercuts omitted from actual CLI packet; source binding not proved'
selected_lines = [row['line'] for row in selection['selected']]
assert [number for number in refs if number in selected_lines] == selected_lines
for number in refs:
    text = ledger[number - 1].removeprefix('- ')
    if re.match(r'^\d{4}-\d{2}-\d{2}(?:T|\s|:|$)', text):
        assert number in selected_lines, f'unexpected selected incident {number}'
after = source_hashes()
(evidence / 'source-hashes-after.json').write_text(json.dumps(after, indent=2) + '\n')
assert after == before, 'candidate source changed during verification'
assert hashlib.sha256((repo / 'memory-bank/papercuts.md').read_bytes()).hexdigest() == selection['ledger_sha256']
summary = {'status': 'PASS', 'packet_bytes': len(packet_path.read_bytes()), 'papercut_source_lines': refs,
           'selected_start_lines': selected_lines, 'source_hashes_unchanged': True, 'checks': results}
(evidence / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'packet_bytes': summary['packet_bytes'], 'checks': len(results), 'evidence': str(evidence)}))
