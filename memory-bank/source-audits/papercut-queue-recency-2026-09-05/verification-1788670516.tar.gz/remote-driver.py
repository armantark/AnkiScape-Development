import fcntl
import importlib.util
import json
from pathlib import Path
import shlex
import shutil
import sys
import tempfile
import time

source = Path('/Users/ArmanTarkhanian1/Library/Application Support/Anki2/ankiscape_worktrees/pool/.treehouse/ankiscape_fork-091389/8/ankiscape_fork')
spec = importlib.util.spec_from_file_location('papercut_remote_helper', source / 'tools/run_remote_tests.py')
helper = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = helper
spec.loader.exec_module(helper)
run_id = 'papercut-queue-recency-' + str(int(time.time()))
remote = helper.REMOTE_ROOT / 'reports' / run_id
local = Path(tempfile.mkdtemp(prefix=run_id + '-'))
for name, original in {
    'verify.py': '/tmp/ankiscape-papercut-queue-verify.py',
    'baseline-tool.py.txt': '/tmp/ankiscape-papercut-queue-baseline-518a651d.py.txt',
    'frozen-source-hashes.json': '/tmp/ankiscape-papercut-queue-frozen-source-hashes.json',
    'expected-selection.json': '/tmp/ankiscape-papercut-queue-expected-selection.json',
}.items():
    shutil.copyfile(original, local / name)
Path('/tmp/ankiscape-papercut-queue-current-run.json').write_text(json.dumps({'run_id': run_id, 'remote': str(remote), 'local': str(local)}) + '\n')
helper.LOCAL_MIRROR_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
with helper.LOCAL_MIRROR_LOCK_PATH.open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    helper._sync(source)
    helper._ssh('mkdir -p ' + shlex.quote(str(remote)), label='papercut evidence directory', repeat_safe=True)
    helper._run_with_retries(('rsync', '-a', '-e', helper.RSYNC_SSH, str(local) + '/', f'{helper.HOST}:{remote}/'), label='papercut verification upload')
    log = str(remote / 'job.log')
    report = str(remote / 'job.exit')
    pending = {'run_id': run_id, 'log_path': log, 'report_path': report}
    helper._pending_path().write_text(json.dumps(pending) + '\n')
    shell = shlex.join(('/opt/homebrew/bin/python3', str(remote / 'verify.py'), str(helper.REMOTE_REPO), str(remote))) + '\ncode=$?\nprintf "%s\\n" "$code" > ' + shlex.quote(report)
    launch = 'nohup /bin/sh -c ' + shlex.quote(shell) + ' </dev/null > ' + shlex.quote(log) + ' 2>&1 &'
    helper._ssh(launch, label='papercut verification launch')
    deadline = time.monotonic() + 180
    code = None
    while time.monotonic() < deadline:
        code = helper._completion_report(report)
        if code is not None:
            break
        time.sleep(1)
    if code is None:
        raise RuntimeError('verification still active; retain pending record and reconcile before any next sync')
    helper._run_with_retries(('rsync', '-a', '-e', helper.RSYNC_SSH, f'{helper.HOST}:{remote}/', str(local) + '/'), label='papercut raw evidence retrieval')
    helper._reconcile_pending_run()
    fcntl.flock(lock, fcntl.LOCK_UN)
print(json.dumps({'exit_code': code, 'local_evidence': str(local), 'remote_evidence': str(remote), 'mirror_released': True}))
sys.exit(code)
